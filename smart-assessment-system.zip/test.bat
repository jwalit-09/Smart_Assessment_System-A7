@echo off
setlocal enabledelayedexpansion

set JAVA_CMD=java
where java >nul 2>nul
if %errorlevel% neq 0 (
    if exist "C:\Program Files\JetBrains\PyCharm 2026.2.1\jbr\bin\java.exe" (
        set JAVA_CMD="C:\Program Files\JetBrains\PyCharm 2026.2.1\jbr\bin\java.exe"
    )
)

if not exist bin\smartsassessment\test\TestRunner.class (
    echo [INFO] Binaries not found. Triggering compilation first...
    call compile.bat
    if %errorlevel% neq 0 exit /b 1
)

%JAVA_CMD% -Dfile.encoding=UTF-8 -cp bin smartsassessment.test.TestRunner
