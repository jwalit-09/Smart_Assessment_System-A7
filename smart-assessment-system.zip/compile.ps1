# PowerShell Compilation Script for Smart Assessment System
$ErrorActionPreference = "Stop"

Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "Compiling Smart Assessment and Question Bank System..." -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan

# Locate javac
$javac = $null
$cmd = Get-Command javac -ErrorAction SilentlyContinue
if ($cmd) {
    $javac = $cmd.Source
} else {
    $jbrPath = "C:\Program Files\JetBrains\PyCharm 2026.2.1\jbr\bin\javac.exe"
    if (Test-Path $jbrPath) {
        $javac = $jbrPath
    } else {
        Write-Error "javac could not be located in PATH or PyCharm JBR."
        exit 1
    }
}

Write-Host "Using compiler: $javac" -ForegroundColor Green

if (-not (Test-Path "bin")) { New-Item -ItemType Directory -Path "bin" | Out-Null }
if (-not (Test-Path "data")) { New-Item -ItemType Directory -Path "data" | Out-Null }

$sources = Get-ChildItem -Path "src" -Recurse -Filter "*.java" | ForEach-Object { '"' + $_.FullName.Replace('\', '/') + '"' }
$sourcesFile = "sources.txt"
[System.IO.File]::WriteAllLines($sourcesFile, $sources, [System.Text.Encoding]::ASCII)

& $javac --release 8 -encoding UTF-8 -d "bin" "@$sourcesFile"
$compileExit = $LASTEXITCODE
Remove-Item $sourcesFile -Force

if ($compileExit -eq 0) {
    Write-Host "`n[SUCCESS] Compilation complete. Classes placed in bin/" -ForegroundColor Green
} else {
    Write-Host "`n[ERROR] Compilation failed with exit code $compileExit" -ForegroundColor Red
    exit $compileExit
}
