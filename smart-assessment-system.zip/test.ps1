# PowerShell Test Runner Script for Smart Assessment System
$java = $null
$cmd = Get-Command java -ErrorAction SilentlyContinue
if ($cmd) {
    $java = $cmd.Source
} else {
    $jbrPath = "C:\Program Files\JetBrains\PyCharm 2026.2.1\jbr\bin\java.exe"
    if (Test-Path $jbrPath) {
        $java = $jbrPath
    }
}

if (-not (Test-Path "bin\smartsassessment\test\TestRunner.class")) {
    Write-Host "Binaries not found. Compiling first..." -ForegroundColor Yellow
    & ".\compile.ps1"
}

& $java "-Dfile.encoding=UTF-8" -cp "bin" smartsassessment.test.TestRunner
