# Smart Assessment and Question Bank System

A complete, working **Smart Assessment and Question Bank System** written in **pure Core Java** with zero external dependencies and zero frontend frameworks. Designed as an academic project demonstrating advanced algorithms, dynamic programming, string algorithms, data structures, and pedagogical measurement techniques.

---

## Project

* **Project Title**: Smart Assessment and Question Bank System
* **Implementation Language**: Core Java (Java 8 through Java 25 compatible)
* **Architecture**: Object-Oriented Console-Based Architecture
* **Persistence**: Flat-file structured storage (`questions.txt`, `students.txt`, `assessments.txt`, `results.txt`, `content.txt`)
* **Algorithmic Focus**: TextHack, String Matching, Multi-Pattern Automata, Dynamic Programming, Graph Algorithms, and Randomised Testing.

---

## Description

The system empowers educators to manage rich question banks, automatically generate novel questions using rule-based templates, classify cognitive levels according to Bloom's Revised Taxonomy, predict question difficulty, detect near-duplicate and semantically identical questions, assemble constraint-satisfying examination papers, conduct interactive terminal assessments for students, automatically grade multi-tier responses (MCQs, Short Answers, and Descriptive Questions), and generate diagnostic performance analytics that pinpoint cohort weak spots.

Furthermore, the system includes a dedicated interactive **Algorithm Lab** offering step-by-step demonstrations and complexity cards for 18 core algorithms implemented manually from first principles without library replacements.

---

## Objectives

1. **Question Bank Management**: Full CRUD operations, multi-attribute filtering, and linear-time pattern search using Knuth-Morris-Pratt (KMP).
2. **Rule-Based Question Generation**: Template engine generating varied MCQs, short answers, and descriptive questions with correct answers, options, and explanations.
3. **Bloom's Taxonomy Classification**: Keyword-based and action-verb heuristic classifier categorizing questions into REMEMBER, UNDERSTAND, APPLY, ANALYZE, EVALUATE, and CREATE.
4. **Multi-Factor Difficulty Prediction**: Composite scoring model evaluating cognitive level, question format, concept density, and calculation requirements into EASY, MEDIUM, and HARD.
5. **Duplicate & Similarity Detection**: Manual TF-IDF vectorization and Cosine Similarity to detect duplicates ($\ge 0.85$) and similar questions ($0.70 - 0.84$).
6. **Smart Assessment Generation**: Exact constraint satisfaction engine ensuring balanced distributions of difficulty, Bloom levels, marks, and modules, with full diagnostic error breakdown if constraints cannot be met.
7. **Interactive Student Examination**: Console-based exam engine supporting navigation (Next, Previous), review sheets, and live submission.
8. **Automated Multi-Format Evaluation**:
   * MCQ: Exact option verification.
   * Short Answer: Levenshtein edit distance and keyword overlap.
   * Descriptive: Concept coverage and TF-IDF semantic similarity with rubric-based partial marking.
9. **Diagnostic Performance Analytics**: Cohort and student-level metrics across modules, topics, difficulties, and cognitive levels with automatic detection of weak areas ($< 65\%$).
10. **Advanced Algorithm Implementations**: 18 manual algorithm implementations free of library shortcuts.

---

## Features

* **Zero External Dependencies**: Operates on pure Core Java standard runtime.
* **Resilient Console I/O**: `InputUtil` prevents invalid input crashes, handles scanner buffer overflows, and validates number ranges.
* **Persistent Flat-File Storage**: Pipe-delimited records with escaping for seamless save and load without databases.
* **Comprehensive Pre-Loaded Dataset**: 60+ pre-seeded Advanced Algorithms questions across Modules 1, 2, and 3 covering all difficulty levels and Bloom levels.
* **Extensive Automated Verification**: Built-in test runner (`TestRunner.java`) validating all 18 algorithms, question bank search, duplicate detection, and assessment workflows.

---

## Modules & Course Syllabus

### Module 1: TextHack as a System
* Pattern search lower bounds
* Fuzzy matching & distance tolerances
* Cosine document similarity
* Citation-flow DAG analysis
* Project scheduling via topological DP
* Large-prime primality testing (Miller-Rabin)
* Network maximum flow (Edmonds-Karp)
* Approximation algorithms & randomized algorithms

### Module 2: String Algorithms
* Naive Pattern Matching
* Knuth-Morris-Pratt (KMP) & Prefix Failure Function ($\pi$)
* Z-Algorithm with $[L, R]$ sliding interval
* Rabin-Karp with Polynomial Rolling Hash & Collision Verification
* Double Hashing principles
* Aho-Corasick Multi-Pattern Search Automaton (Trie + BFS Failure Links + Output Links)
* Suffix Arrays via $O(n \log^2 n)$ Prefix Doubling & Binary Search
* Kasai's Linear-Time $O(n)$ LCP Algorithm
* Suffix Trees & Conceptual Linear SA-IS (Suffix Array by Induced Sorting)

### Module 3: Advanced Dynamic Programming
* Overlapping Subproblems & Optimal Substructure
* Wagner-Fischer Levenshtein Edit Distance & DP Table Traceback
* Damerau-Levenshtein with Adjacent Transpositions ($CA \to AC$ distance = 1)
* Weighted Edit Distance with custom Insertion, Deletion, and Substitution penalties
* Needleman-Wunsch Global Alignment & Smith-Waterman Local Alignment concepts
* Matrix-Chain Multiplication Interval DP & Parenthesization
* Optimal Binary Search Trees
* Travelling Salesperson Problem (TSP) using Held-Karp Bitmask DP ($DP[mask][u]$)
* Hamiltonian Path existence and path reconstruction
* Tree DP (Diameter, Subtree sizes, and 2-pass Rerooting technique)
* Sum Over Subsets (SOS) DP in $O(n \cdot 2^n)$
* Principle of Inclusion-Exclusion over bitmasks

---

## Java Concepts Used

* **Object-Oriented Programming (OOP)**: Encapsulation, abstraction, polymorphic representations, and domain entities (`Question`, `Student`, `Assessment`, `Answer`, `Performance`).
* **Enums**: Strong type safety for `QuestionType`, `DifficultyLevel`, and `BloomLevel`.
* **Dynamic Programming Tabulation**: Multi-dimensional memoization tables for string distances, matrix parenthesizations, tree metrics, and bitmask state spaces.
* **Bit Manipulation**: State compression using integer bitmasks (`mask | (1 << v)`, `mask ^ (1 << u)`, submask checks).
* **Recursion & Tree Traversals**: Post-order and pre-order DFS traversals for tree dynamic programming and rerooting.
* **Automata & Trie Graphs**: Pointer structures with BFS queue propagation for Aho-Corasick failure transitions.
* **File I/O**: `BufferedReader`, `PrintWriter`, `InputStreamReader`, and `OutputStreamWriter` with explicit UTF-8 character encoding and escaping.
* **Mathematics & Modular Arithmetic**: Manual modular exponentiation (`powerMod`), overflow-safe modular multiplication, and BigInteger arithmetic for primality testing.

---

## Algorithms Used

1. **Knuth-Morris-Pratt (KMP)**: Computes prefix function $\pi[i]$ in $O(m)$ and finds text occurrences in $O(n + m)$ without rewinding text pointers.
2. **Z-Algorithm**: Computes $Z[i]$ (longest substring matching prefix) in strictly linear $O(n)$ time using an active $[L, R]$ window.
3. **Rabin-Karp**: Computes rolling polynomial hashes with prime modulus $10^9+7$, rolling window hashes in $O(1)$ time, and verifying character collisions.
4. **Wagner-Fischer Edit Distance**: Computes minimum insertions, deletions, and substitutions in $O(nm)$ time with full matrix traceback.
5. **Damerau-Levenshtein Distance**: Evaluates insertions, deletions, substitutions, and adjacent transpositions (e.g. $CA \to AC$ distance = 1).
6. **Weighted Edit Distance**: Parameterized dynamic programming allowing custom penalty weights for insertion, deletion, and substitution operations.
7. **TF-IDF (Term Frequency - Inverse Document Frequency)**: Manual document vectorizer computing normalized term frequencies and inverse corpus frequencies.
8. **Cosine Similarity**: Manual vector dot-product normalized by Euclidean magnitudes, computing similarity $\in [0, 1]$.
9. **Suffix Array Construction**: Prefix doubling algorithm sorting suffix ranks in $O(n \log^2 n)$ using custom merge-sort and binary search queries in $O(m \log n)$.
10. **Kasai's LCP Algorithm**: Computes the Longest Common Prefix array between adjacent sorted suffixes in $O(n)$ time using the property $LCP[rank[i]] \ge LCP[rank[i-1]] - 1$.
11. **Aho-Corasick Automaton**: Multi-pattern search trie with BFS failure links and dictionary output links searching all patterns simultaneously in $O(n + \sum m + z)$ time.
12. **Matrix-Chain Multiplication**: Interval dynamic programming computing minimum scalar multiplications in $O(n^3)$ time and optimal parenthesization.
13. **TSP Bitmask DP (Held-Karp)**: Solves the Travelling Salesperson Problem over subsets of cities in $O(n^2 2^n)$ time.
14. **Hamiltonian Path**: Bitmask DP discovering whether a directed/undirected graph contains a path visiting all vertices exactly once.
15. **Tree DP & Rerooting**: Single-pass DFS computing tree diameter and subtree sizes, followed by a second DFS pass updating sum of distances for all nodes in $O(N)$ total time.
16. **Sum Over Subsets (SOS DP)**: Computes subset sums $F[mask] = \sum_{sub \subseteq mask} A[sub]$ in $O(n \cdot 2^n)$ time by prefix dimension relaxation.
17. **Edmonds-Karp Maximum Flow**: BFS-based implementation of Ford-Fulkerson finding shortest augmenting paths on residual capacity graphs in $O(V E^2)$ time.
18. **Miller-Rabin Primality Test**: Randomized Monte Carlo algorithm with modular exponentiation determining primality with error probability $\le (1/4)^k$.

---

## Algorithm Complexity Table

| # | Algorithm | Time Complexity (Best/Avg) | Time Complexity (Worst) | Space Complexity | Description / Core Mechanism |
|---|---|---|---|---|---|
| 1 | **KMP** | $O(n + m)$ | $O(n + m)$ | $O(m)$ | Longest proper prefix suffix ($\pi$) failure table |
| 2 | **Z-Algorithm** | $O(n)$ | $O(n)$ | $O(n)$ | Linear $[L, R]$ prefix match segment |
| 3 | **Rabin-Karp** | $O(n + m)$ | $O(n \cdot m)$ | $O(1)$ | Polynomial rolling hash with collision verification |
| 4 | **Wagner-Fischer** | $O(n \cdot m)$ | $O(n \cdot m)$ | $O(n \cdot m)$ | 2D dynamic programming edit distance |
| 5 | **Damerau-Levenshtein** | $O(n \cdot m)$ | $O(n \cdot m)$ | $O(n \cdot m)$ | Optimal string alignment with adjacent transpositions |
| 6 | **Weighted Edit Distance** | $O(n \cdot m)$ | $O(n \cdot m)$ | $O(n \cdot m)$ | Parameterized penalty dynamic programming |
| 7 | **TF-IDF Vectorizer** | $O(D \cdot L)$ | $O(D \cdot L)$ | $O(V)$ | Term frequency and inverse document frequency |
| 8 | **Cosine Similarity** | $O(V)$ | $O(V)$ | $O(1)$ | Normalized dot product of numerical vectors |
| 9 | **Suffix Array** | $O(n \log^2 n)$ | $O(n \log^2 n)$ | $O(n)$ | Prefix doubling with custom merge-sort |
| 10 | **Kasai's LCP** | $O(n)$ | $O(n)$ | $O(n)$ | Linear LCP computation via height amortized drop |
| 11 | **Aho-Corasick** | $O(n + \sum m + z)$ | $O(n + \sum m + z)$ | $O(\sum m \cdot \Sigma)$ | Multi-pattern trie with BFS failure and output links |
| 12 | **Matrix Chain DP** | $O(n^3)$ | $O(n^3)$ | $O(n^2)$ | Interval dynamic programming with split table |
| 13 | **TSP Bitmask DP** | $O(n^2 2^n)$ | $O(n^2 2^n)$ | $O(n 2^n)$ | Held-Karp dynamic programming over city subsets |
| 14 | **Hamiltonian Path** | $O(n^2 2^n)$ | $O(n^2 2^n)$ | $O(n 2^n)$ | Bitmask state dynamic programming |
| 15 | **Tree DP & Rerooting** | $O(N)$ | $O(N)$ | $O(N)$ | Two-pass DFS tree property computation |
| 16 | **SOS DP** | $O(n \cdot 2^n)$ | $O(n \cdot 2^n)$ | $O(2^n)$ | Sum Over Subsets prefix dimension relaxation |
| 17 | **Edmonds-Karp Max Flow** | $O(V E^2)$ | $O(V E^2)$ | $O(V^2)$ or $O(V + E)$ | BFS shortest augmenting paths on residual graph |
| 18 | **Miller-Rabin** | $O(k \log^3 n)$ | $O(k \log^3 n)$ | $O(\log n)$ | Randomized witness modular exponentiation |

---

## Project Structure

```
smart-assessment-system/
├── src/
│   └── smartsassessment/
│       ├── Main.java                        # Master CLI application controller
│       │
│       ├── model/
│       │   ├── Question.java                # Encapsulates assessment questions & metadata
│       │   ├── Student.java                 # Student entity & assessment history
│       │   ├── Assessment.java              # Structured examination paper
│       │   ├── Answer.java                  # Individual student question responses & scores
│       │   ├── Subject.java                 # Course curriculum container
│       │   ├── Module.java                  # Course syllabus module
│       │   ├── Performance.java             # Comprehensive student examination report
│       │   ├── QuestionType.java            # MCQ, SHORT_ANSWER, DESCRIPTIVE
│       │   ├── DifficultyLevel.java         # EASY, MEDIUM, HARD
│       │   └── BloomLevel.java              # REMEMBER, UNDERSTAND, APPLY, ANALYZE, EVALUATE, CREATE
│       │
│       ├── service/
│       │   ├── QuestionBank.java            # CRUD, KMP search, and multi-filter queries
│       │   ├── QuestionGenerator.java       # Rule-based algorithmic question generation
│       │   ├── AssessmentGenerator.java     # Constraint-satisfaction paper generator
│       │   ├── AssessmentEvaluator.java     # Multi-tier auto-evaluator (MCQ, Short, Descriptive)
│       │   ├── AnalyticsService.java        # Cohort statistics & diagnostic weak-area analysis
│       │   ├── BloomClassifier.java         # Keyword & cognitive verb taxonomy classifier
│       │   ├── DifficultyClassifier.java    # Multi-factor difficulty prediction
│       │   └── DuplicateDetector.java       # TF-IDF & Cosine Similarity deduplication engine
│       │
│       ├── algorithms/
│       │   ├── KMP.java                     # Knuth-Morris-Pratt pattern matcher
│       │   ├── ZAlgorithm.java              # Linear-time Z array string matcher
│       │   ├── RabinKarp.java               # Polynomial rolling hash matcher
│       │   ├── EditDistance.java            # Wagner-Fischer Levenshtein distance
│       │   ├── DamerauLevenshtein.java      # Optimal string alignment with transposition
│       │   ├── WeightedEditDistance.java    # Parameterized cost edit distance
│       │   ├── TFIDF.java                   # Manual TF-IDF vectorizer
│       │   ├── CosineSimilarity.java        # Manual Cosine similarity calculation
│       │   ├── SuffixArray.java             # Prefix doubling suffix array construction
│       │   ├── LCPKasai.java                # Kasai's linear-time LCP array construction
│       │   ├── AhoCorasick.java             # Multi-pattern search automaton
│       │   ├── MatrixChainDP.java           # Interval DP matrix chain multiplication
│       │   ├── TSPBitmaskDP.java            # Held-Karp bitmask TSP solver
│       │   ├── HamiltonianPath.java         # Bitmask DP Hamiltonian path finder
│       │   ├── TreeDP.java                  # Tree diameter & rerooting distance sums
│       │   ├── SOSDP.java                   # Sum Over Subsets dynamic programming
│       │   ├── MaxFlow.java                 # Edmonds-Karp maximum network flow
│       │   └── PrimalityTest.java           # Miller-Rabin randomised primality tester
│       │
│       ├── storage/
│       │   ├── FileManager.java             # Flat-file pipe-delimited persistence
│       │   └── DataManager.java             # In-memory repository & 60+ sample questions seeder
│       │
│       ├── util/
│       │   ├── InputUtil.java               # Safe, non-crashing console Scanner reader
│       │   ├── ValidationUtil.java          # Input sanitization and percentage checks
│       │   └── IdGenerator.java             # Sequential identifier generator
│       │
│       └── test/
│           └── TestRunner.java              # Full automated test suite
│
├── data/
│   ├── questions.txt                        # Persistent questions file
│   ├── students.txt                         # Persistent students file
│   ├── assessments.txt                      # Persistent assessments file
│   ├── results.txt                          # Persistent results file
│   └── content.txt                          # Topic reference content
│
├── compile.bat                              # Windows batch compiler
├── run.bat                                  # Windows batch runner
├── test.bat                                 # Windows batch test runner
├── compile.ps1                              # PowerShell compiler
├── run.ps1                                  # PowerShell runner
├── test.ps1                                 # PowerShell test runner
└── README.md                                # Complete system documentation
```

---

## How to Compile

### Option A: Using Provided Batch Scripts (Windows Command Prompt)
```cmd
compile.bat
```

### Option B: Using Provided PowerShell Scripts
```powershell
.\compile.ps1
```

### Option C: Standard javac Command Line
```powershell
mkdir bin
javac -encoding UTF-8 -d bin (Get-ChildItem -Path src -Recurse -Filter *.java).FullName
```

---

## How to Run

### Run the Main Application
```cmd
run.bat
```
or via PowerShell:
```powershell
.\run.ps1
```
or directly via java:
```cmd
java -Dfile.encoding=UTF-8 -cp bin smartsassessment.Main
```

### Run the Automated Test Suite
```cmd
test.bat
```
or via PowerShell:
```powershell
.\test.ps1
```

---

## Sample Input & Output Sessions

### 1. Main Menu
```
========================================
   SMART ASSESSMENT AND QUESTION BANK   
========================================
 1. Question Bank
 2. Generate Questions
 3. Search Questions
 4. Classify Questions
 5. Detect Duplicate Questions
 6. Create Smart Assessment
 7. Student Assessment
 8. Evaluate Assessment
 9. Performance Analytics
10. Algorithm Lab
11. Load Sample Data
12. Save Data
13. Exit
========================================
Select an option (1-13): 1
```

### 2. Question Bank Search (KMP Pattern Search)
```
--- SEARCH QUESTIONS (KMP SEARCH ENGINE) ---
Enter search keyword or phrase: failure function

Search Results (4 matches found using KMP):
========================================
Question ID: Q202
Subject:     Advanced Algorithms
Module:      Module 2
Topic:       KMP
Type:        MCQ
Difficulty:  EASY
Bloom Level: REMEMBER
Marks:       2

Question:
What does the failure function array pi[i] in KMP represent?

Options:
  A. The length of the longest proper prefix of pattern[0..i] that is also a suffix
  B. The index of the first character mismatch in text
  C. The ASCII sum of characters in pattern[0..i]
  D. The number of distinct substrings in pattern[0..i]

Correct Answer: A
Explanation:    pi[i] stores the length of the longest proper prefix that matches a suffix of pattern[0..i].
========================================
```

### 3. Duplicate Question Detection
```
--- DUPLICATE QUESTION DETECTOR (TF-IDF & COSINE SIMILARITY) ---
Comparison: [Custom-A] vs [Custom-B]
Question A: What is the time complexity of the KMP algorithm?
Question B: What is the asymptotic time complexity of KMP algorithm?
Cosine Similarity: 91.45%
Decision:          DUPLICATE
```

### 4. Smart Assessment Generation with Constraint Satisfaction
```
--- CREATE SMART ASSESSMENT ---
Enter Assessment Title: Midterm Exam 1
Enter Module filter (e.g. Module 2, or 'ALL'): Module 2
Enter total number of questions: 5
Enter duration in minutes (10-180): 45

Specify Difficulty Distribution (Percentages must sum to 100%):
  Easy %:   40
  Medium %: 40
  Hard %:   20

Specify Bloom Taxonomy Distribution (Percentages must sum to 100%):
  REMEMBER %:   40
  UNDERSTAND %: 40
  APPLY %:      20
  ANALYZE %:    0
  EVALUATE %:   0
  CREATE %:     0

Select option (1-4): 1

  SUCCESS! Assessment generated and saved.
  [A103] Midterm Exam 1 | Module 2 (5 Qs, 13 Marks, 45 mins)
```

### 5. Automated Evaluation & Scorecard
```
========================================================================
                        ASSESSMENT EVALUATION REPORT                    
========================================================================
Result ID:     R102
Student:       A Sai Charan Reddy (S101)
Assessment ID: A101
Date:          2026-09-17
Score:         16 / 17  (94.1%)
Accuracy:      100.0%
------------------------------------------------------------------------

Detailed Question Breakdown:

[Q1] What is the worst-case time complexity of the Naive Pattern Matching algorithm? (EASY, REMEMBER, 2 Marks)
  Student Answer:  A
  Correct Answer:  A
  Marks Awarded:   2 / 2
  Feedback:        Correct choice selected.

[Q2] Explain the amortized complexity argument proving that KMP pattern searching executes in strictly linear time O(n). (MEDIUM, UNDERSTAND, 5 Marks)
  Student Answer:  Text pointer i advances by 1 each step. Pattern pointer j cannot decrement more than it incremented.
  Correct Answer:  The text pointer i advances once in each outer loop step...
  Marks Awarded:   4 / 5
  Feedback:        Score: 4/5 based on keyword matching and term similarity.
========================================================================
```

---

## Future Enhancements

1. **LaTeX Math Rendering in Terminal**: Formatting mathematical formulas via ANSI mathematical Unicode blocks.
2. **SA-IS Direct In-Place Execution**: Upgrading the suffix array engine to linear SA-IS for gigabyte-scale genomic sequence alignment.
3. **Plagiarism Graph Clustering**: Integrating disjoint-set (Union-Find) and community detection across student cohort submissions to flag collusion.
4. **Adaptive Computerized Testing (CAT)**: Dynamic Item Response Theory (IRT) adjusting question difficulty in real-time based on live student answers.

---

## Premium Desktop UI (Swing)

Launch with `run-ui.bat` (Windows) or `java -cp bin smartsassessment.ui.SmartAssessmentUI`. Pure Swing, no extra libraries.

| Screen | What it does |
|---|---|
| **Dashboard** | Animated KPIs, difficulty donut, Bloom coverage, module coverage, auto-generated smart insights, background duplicate audit, recent submissions |
| **Question Generator** | Rule-based generation, Bloom + difficulty auto-classification with rationale, duplicate check, one-click *Add to bank* |
| **Question Bank** | KMP-powered live search, 4 filters, sortable table with colour badges, detail panel, delete, duplicate scan, CSV export |
| **Assessment Builder** | Difficulty sliders + presets, Bloom auto-balance, exact deficit report if unsatisfiable, save, export paper + answer key |
| **Exam Mode** | Timed exam, question palette, MCQ / short / descriptive input, auto-grading, answer review with feedback, results saved |
| **Analytics** | Gauge, module / difficulty / Bloom / topic charts, weak-area detection, leaderboard, CSV export |
| **Algorithm Lab** | Run KMP, Z, Rabin-Karp, Edit Distance, Aho-Corasick, Miller-Rabin, Matrix Chain and TF-IDF live with visualisations |

Light / dark theme toggle in the top bar. UI code lives in `src/smartsassessment/ui/` (`SmartAssessmentUI`, `ExamPage`, `AlgorithmLab`, `Widgets`, `Kit`, `Theme`).
