@echo off
setlocal enabledelayedexpansion

echo =======================================================
echo Compiling Smart Assessment and Question Bank System...
echo =======================================================

:: Locate javac
set JAVAC_CMD=javac
where javac >nul 2>nul
if %errorlevel% neq 0 (
    if exist "C:\Program Files\JetBrains\PyCharm 2026.2.1\jbr\bin\javac.exe" (
        set JAVAC_CMD="C:\Program Files\JetBrains\PyCharm 2026.2.1\jbr\bin\javac.exe"
    ) else (
        echo [ERROR] javac was not found in PATH or standard JDK directories.
        echo Please ensure a Java JDK is installed and javac is available.
        exit /b 1
    )
)

if not exist bin mkdir bin
if not exist data mkdir data

if exist sources.txt del sources.txt
for /R src %%F in (*.java) do (
    set "fpath=%%F"
    set "fpath=!fpath:\=/!"
    echo "!fpath!" >> sources.txt
)

%JAVAC_CMD% --release 8 -encoding UTF-8 -d bin @sources.txt
set COMPILE_STATUS=%errorlevel%
if exist sources.txt del sources.txt

if %COMPILE_STATUS% equ 0 (
    echo.
    echo [SUCCESS] Compilation complete. Classes placed in bin/
) else (
    echo.
    echo [ERROR] Compilation failed with error code %COMPILE_STATUS%.
)

exit /b %COMPILE_STATUS%
