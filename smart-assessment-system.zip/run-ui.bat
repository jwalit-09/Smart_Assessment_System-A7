@echo off
setlocal
call compile.bat
if errorlevel 1 (echo [ERROR] Compilation failed.&pause&exit /b 1)
java -cp bin smartsassessment.ui.SmartAssessmentUI
pause
