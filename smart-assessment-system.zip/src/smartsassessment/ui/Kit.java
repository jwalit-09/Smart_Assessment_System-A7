package smartsassessment.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

/** Small layout / text helpers shared by every page. */
public final class Kit {
    private Kit() {}

    public static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    public static JLabel label(String t, int style, float size, Color c) {
        JLabel l = new JLabel(t); l.setFont(Theme.font(style, size)); l.setForeground(c); return l;
    }
    public static JLabel muted(String t) { return label(t, Font.PLAIN, 12.5f, Theme.MUTED); }

    /** Wrapped text that really honours its pixel width (JTextArea based, so layout height is exact). */
    public static class Wrap extends JTextArea {
        private final int w;
        Wrap(String text, int w) {
            super(); this.w = w;
            ((DefaultCaret) getCaret()).setUpdatePolicy(DefaultCaret.NEVER_UPDATE); setText(text); setCaretPosition(0);
            setLineWrap(true); setWrapStyleWord(true); setEditable(false); setFocusable(false);
            setOpaque(false); setBorder(null); setCursor(Cursor.getDefaultCursor());
        }
        @Override public Dimension getPreferredSize() {
            setSize(w, Short.MAX_VALUE); Dimension d = super.getPreferredSize(); return new Dimension(w, d.height);
        }
        @Override public Dimension getMaximumSize() { return getPreferredSize(); }
        @Override public Dimension getMinimumSize() { return getPreferredSize(); }
    }

    public static JComponent wrap(String text, int width, int style, float size, Color c) {
        Wrap t = new Wrap(text == null ? "" : text, width); t.setFont(Theme.font(style, size)); t.setForeground(c); return t;
    }

    public static JPanel vbox() {
        JPanel p = new JPanel(); p.setOpaque(false); p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS)); return p;
    }
    public static JPanel flow(int hgap, int vgap, Component... cs) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, hgap, vgap)); p.setOpaque(false);
        for (Component c : cs) p.add(c); return p;
    }
    public static <T extends JComponent> T left(T c) { c.setAlignmentX(Component.LEFT_ALIGNMENT); return c; }

    /** Equal-height columns with relative widths. */
    public static JPanel cols(double[] weights, int gap, JComponent... comps) {
        JPanel p = new JPanel(new GridBagLayout()); p.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints(); g.fill = GridBagConstraints.BOTH; g.weighty = 1;
        for (int i = 0; i < comps.length; i++) {
            g.gridx = i; g.weightx = weights[i]; g.insets = new Insets(0, 0, 0, i == comps.length - 1 ? 0 : gap);
            p.add(comps[i], g);
        }
        return p;
    }
    public static JPanel even(int n, int gap, JComponent... comps) {
        double[] w = new double[comps.length]; java.util.Arrays.fill(w, 1.0 / n); return cols(w, gap, comps);
    }

    /** Titled card. */
    public static Widgets.Card section(String title, String subtitle, JComponent body) {
        Widgets.Card c = new Widgets.Card(); c.setLayout(new BorderLayout(0, 14));
        JPanel head = vbox(); head.add(left(label(title, Font.BOLD, 16f, Theme.TEXT)));
        if (subtitle != null) { head.add(Box.createVerticalStrut(2)); head.add(left(muted(subtitle))); }
        c.add(head, BorderLayout.NORTH); c.add(body, BorderLayout.CENTER); return c;
    }

    public static void formRow(JPanel form, String label, JComponent field) {
        JLabel l = label(label, Font.BOLD, 12f, Theme.MUTED); l.setAlignmentX(Component.LEFT_ALIGNMENT);
        form.add(l); form.add(Box.createVerticalStrut(5));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, Math.max(38, field.getPreferredSize().height)));
        form.add(field); form.add(Box.createVerticalStrut(14));
    }

    public static JPanel statCard(String icon, String name, JLabel value, Color accent, String caption) {
        Widgets.Card c = new Widgets.Card(); c.setLayout(new BorderLayout(14, 0));
        JLabel chip = new JLabel(icon, SwingConstants.CENTER) {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
                g.setPaint(new GradientPaint(0, 0, accent, getWidth(), getHeight(), Theme.mix(accent, Theme.PRIMARY2, .5f)));
                g.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16)); g.dispose(); super.paintComponent(g0);
            }
        };
        chip.setFont(Theme.font(Font.PLAIN, 20f)); chip.setForeground(Color.WHITE); chip.setPreferredSize(new Dimension(48, 48)); chip.setOpaque(false);
        JPanel chipWrap = new JPanel(new GridBagLayout()); chipWrap.setOpaque(false); chipWrap.add(chip);
        JPanel txt = vbox();
        txt.add(left(label(name, Font.BOLD, 12f, Theme.MUTED))); txt.add(left(value));
        txt.add(left(label(caption, Font.PLAIN, 11.5f, Theme.MUTED)));
        JPanel txtWrap = new JPanel(new GridBagLayout()); txtWrap.setOpaque(false);
        GridBagConstraints gc = new GridBagConstraints(); gc.anchor = GridBagConstraints.WEST; gc.weightx = 1; txtWrap.add(txt, gc);
        c.add(chipWrap, BorderLayout.WEST); c.add(txtWrap, BorderLayout.CENTER); return c;
    }

    public static JComponent chip(String label, String value, Color color) {
        JPanel p = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
                g.setColor(Theme.alpha(color, Theme.dark ? 40 : 24)); g.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 14, 14)); g.dispose();
            }
        };
        p.setOpaque(false); p.setBorder(new EmptyBorder(8, 14, 8, 14));
        p.add(label(label, Font.BOLD, 11f, Theme.MUTED), BorderLayout.NORTH);
        p.add(label(value, Font.BOLD, 17f, color), BorderLayout.CENTER); return p;
    }

    /** Page container that scrolls vertically only. */
    public static class Page extends JPanel implements Scrollable {
        public Page() { setOpaque(false); setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); setBorder(new EmptyBorder(8, 28, 28, 28)); }
        public void addRow(JComponent c) { addRow(c, 18); }
        public void addRow(JComponent c, int gapAfter) { c.setAlignmentX(Component.LEFT_ALIGNMENT); add(c); add(Box.createVerticalStrut(gapAfter)); }
        public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 20; }
        public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return 120; }
        public boolean getScrollableTracksViewportWidth() { return true; }
        public boolean getScrollableTracksViewportHeight() { return false; }
    }

    // ------------------------------------------------------------- Matrix
    public static class Grid extends JComponent {
        private final String[] rows, cols; private final String[][] cells; private final boolean[][] hot; private final int cw, ch;
        public Grid(String[] rows, String[] cols, String[][] cells, boolean[][] hot, int cw) {
            this.rows = rows; this.cols = cols; this.cells = cells; this.hot = hot; this.cw = cw; this.ch = 32;
            setPreferredSize(new Dimension((cols.length + 1) * cw + 2, (rows.length + 1) * ch + 2));
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
            for (int r = 0; r <= rows.length; r++) for (int c = 0; c <= cols.length; c++) {
                int x = c * cw, y = r * ch; String t = ""; boolean hd = r == 0 || c == 0; boolean h = false;
                if (r == 0 && c > 0) t = cols[c - 1]; else if (c == 0 && r > 0) t = rows[r - 1];
                else if (r > 0) { t = cells[r - 1][c - 1]; h = hot != null && hot[r - 1][c - 1]; }
                g.setColor(h ? Theme.alpha(Theme.PRIMARY, 200) : hd ? Theme.SURFACE_ALT : Theme.INPUT_BG);
                g.fill(new RoundRectangle2D.Float(x + 2, y + 2, cw - 3, ch - 3, 8, 8));
                g.setFont(Theme.font(hd || h ? Font.BOLD : Font.PLAIN, 12.5f));
                g.setColor(h ? Color.WHITE : hd ? Theme.PRIMARY : Theme.TEXT);
                FontMetrics fm = g.getFontMetrics();
                g.drawString(t, x + (cw - fm.stringWidth(t)) / 2, y + (ch + fm.getAscent() - fm.getDescent()) / 2);
            }
            g.dispose();
        }
    }

    /** Monospace text with highlighted ranges {start, length}. */
    public static JTextPane highlight(String text, List<int[]> ranges, Color color) {
        JTextPane tp = new JTextPane(); tp.setEditable(false); tp.setOpaque(true); tp.setBackground(Theme.INPUT_BG);
        tp.setBorder(new EmptyBorder(12, 14, 12, 14));
        StyledDocument doc = tp.getStyledDocument();
        SimpleAttributeSet base = new SimpleAttributeSet(); StyleConstants.setFontFamily(base, "Consolas"); StyleConstants.setFontSize(base, 16); StyleConstants.setForeground(base, Theme.TEXT);
        SimpleAttributeSet hl = new SimpleAttributeSet(base); StyleConstants.setBackground(hl, color); StyleConstants.setForeground(hl, Color.WHITE); StyleConstants.setBold(hl, true);
        try {
            doc.insertString(0, text, base);
            for (int[] r : ranges) if (r[0] >= 0 && r[0] + r[1] <= text.length()) doc.setCharacterAttributes(r[0], r[1], hl, false);
        } catch (BadLocationException ignored) {}
        return tp;
    }

    // -------------------------------------------------------------- Toast
    public static class ToastLayer extends JPanel {
        private String msg = ""; private Color accent = Theme.GOOD; private float alpha = 0; private javax.swing.Timer timer;
        public ToastLayer() { setOpaque(false); setLayout(null); }
        @Override public boolean contains(int x, int y) { return false; }
        public void show(String m, Color a) {
            msg = m; accent = a; alpha = 0; setVisible(true);
            if (timer != null) timer.stop();
            final long start = System.currentTimeMillis();
            timer = new javax.swing.Timer(20, e -> {
                long t = System.currentTimeMillis() - start;
                alpha = t < 250 ? t / 250f : t < 2600 ? 1f : Math.max(0, 1 - (t - 2600) / 400f);
                repaint(); if (t > 3000) { alpha = 0; ((javax.swing.Timer) e.getSource()).stop(); repaint(); }
            });
            timer.start();
        }
        @Override protected void paintComponent(Graphics g0) {
            if (alpha <= 0) return;
            Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
            g.setComposite(AlphaComposite.SrcOver.derive(alpha));
            g.setFont(Theme.font(Font.BOLD, 13.5f)); FontMetrics fm = g.getFontMetrics();
            int w = fm.stringWidth(msg) + 64, h = 46, x = getWidth() - w - 30, y = getHeight() - h - 30 + (int) ((1 - alpha) * 14);
            g.setColor(new Color(0, 0, 0, 40)); g.fill(new RoundRectangle2D.Float(x, y + 4, w, h, 16, 16));
            g.setColor(Theme.dark ? new Color(40, 50, 78) : new Color(24, 31, 55)); g.fill(new RoundRectangle2D.Float(x, y, w, h, 16, 16));
            g.setColor(accent); g.fillOval(x + 16, y + h / 2 - 5, 10, 10);
            g.setColor(Color.WHITE); g.drawString(msg, x + 38, y + (h + fm.getAscent() - fm.getDescent()) / 2);
            g.dispose();
        }
    }
    public static void toast(Component src, String msg, Color accent) {
        JRootPane rp = SwingUtilities.getRootPane(src);
        if (rp != null && rp.getGlassPane() instanceof ToastLayer) ((ToastLayer) rp.getGlassPane()).show(msg, accent);
    }
}
