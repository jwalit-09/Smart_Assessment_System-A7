package smartsassessment.ui;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.Map;


/** Reusable custom-painted Swing components that give the app its premium look. */
public final class Widgets {
    private Widgets() {}

    static void quality(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }

    static double ease(double t) { t = Math.max(0, Math.min(1, t)); return 1 - Math.pow(1 - t, 3); }

    /** Drives a 0..1 progress animation and repaints the owner. */
    public abstract static class Animated extends JPanel {
        protected double progress = 0;
        private Timer timer;
        public Animated() { setOpaque(false); }
        public void play() {
            progress = 0;
            if (timer != null) timer.stop();
            final long start = System.currentTimeMillis();
            timer = new Timer(16, e -> {
                progress = ease((System.currentTimeMillis() - start) / 800.0);
                repaint();
                if (progress >= 1) ((Timer) e.getSource()).stop();
            });
            timer.start();
        }
        @Override public void addNotify() { super.addNotify(); play(); }
    }

    // ---------------------------------------------------------------- Card
    public static class Card extends JPanel {
        private final int arc;
        public Card() { this(18); }
        public Card(int arc) {
            this.arc = arc; setOpaque(false); setBorder(new EmptyBorder(18, 20, 18, 20));
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); quality(g);
            int w = getWidth() - 3, h = getHeight() - 4;
            for (int i = 3; i >= 1; i--) {
                g.setColor(new Color(15, 23, 42, Theme.dark ? 22 : 7));
                g.fill(new RoundRectangle2D.Float(1 - i * 0.4f, 2 + i, w + i * 0.8f, h, arc, arc));
            }
            g.setColor(Theme.SURFACE);
            g.fill(new RoundRectangle2D.Float(0, 0, w, h, arc, arc));
            g.setColor(Theme.BORDER);
            g.draw(new RoundRectangle2D.Float(0, 0, w - 1, h - 1, arc, arc));
            g.dispose();
        }
        @Override public Insets getInsets() { Insets i = super.getInsets(); return new Insets(i.top, i.left, i.bottom + 4, i.right + 3); }
    }

    // ------------------------------------------------------------ Gradient
    public static class GradientPanel extends JPanel {
        private final Color c1, c2; private final int arc;
        public GradientPanel(Color c1, Color c2, int arc) { this.c1 = c1; this.c2 = c2; this.arc = arc; setOpaque(false); }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); quality(g);
            int w = getWidth(), h = getHeight();
            Shape clip = new RoundRectangle2D.Float(0, 0, w, h, arc, arc);
            g.setClip(clip);
            g.setPaint(new GradientPaint(0, 0, c1, w, h, c2));
            g.fillRect(0, 0, w, h);
            g.setColor(new Color(255, 255, 255, 22)); g.fillOval(w - 260, -120, 380, 380);
            g.setColor(new Color(255, 255, 255, 16)); g.fillOval(w - 120, h - 100, 260, 260);
            g.setColor(new Color(255, 255, 255, 12)); g.fillOval(w / 2 - 40, -90, 180, 180);
            g.dispose();
        }
    }

    // ---------------------------------------------------------------- Pill
    public static class Pill extends JLabel {
        private final Color color;
        public Pill(String text, Color color) {
            super(text, CENTER); this.color = color;
            setFont(Theme.font(Font.BOLD, 11f)); setForeground(color);
            setBorder(new EmptyBorder(3, 10, 3, 10)); setOpaque(false);
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); quality(g);
            g.setColor(Theme.alpha(color, Theme.dark ? 45 : 28));
            g.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), getHeight(), getHeight()));
            g.dispose(); super.paintComponent(g0);
        }
    }

    // -------------------------------------------------------------- Button
    public static class Btn extends JButton {
        public enum Kind { PRIMARY, GHOST, DANGER, SUCCESS, LIGHT }
        private final Kind kind; private boolean hover, press;
        public Btn(String text) { this(text, Kind.PRIMARY); }
        public Btn(String text, Kind kind) {
            super(text); this.kind = kind;
            setContentAreaFilled(false); setFocusPainted(false); setBorderPainted(false);
            setOpaque(false); setFont(Theme.font(Font.BOLD, 13f));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setBorder(new EmptyBorder(10, 20, 10, 20));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; press = false; repaint(); }
                @Override public void mousePressed(MouseEvent e) { press = true; repaint(); }
                @Override public void mouseReleased(MouseEvent e) { press = false; repaint(); }
            });
        }
        @Override public Dimension getPreferredSize() { Dimension d = super.getPreferredSize(); return new Dimension(d.width, Math.max(d.height, 38)); }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); quality(g);
            int w = getWidth(), h = getHeight(); float arc = 12;
            Shape s = new RoundRectangle2D.Float(0, 0, w - 1, h - 1, arc, arc);
            Color fg;
            if (!isEnabled()) {
                g.setColor(Theme.BORDER); g.fill(s); fg = Theme.MUTED;
            } else if (kind == Kind.LIGHT) {
                g.setColor(hover ? new Color(240, 238, 255) : Color.WHITE); g.fill(s); fg = new Color(55, 48, 163);
            } else if (kind == Kind.GHOST) {
                g.setColor(hover ? Theme.HOVER : Theme.SURFACE); g.fill(s);
                g.setColor(Theme.BORDER); g.draw(s); fg = Theme.TEXT;
            } else {
                Color a = kind == Kind.DANGER ? Theme.BAD : kind == Kind.SUCCESS ? Theme.GOOD : Theme.PRIMARY;
                Color b = kind == Kind.DANGER ? new Color(244, 114, 94) : kind == Kind.SUCCESS ? Theme.ACCENT : Theme.PRIMARY2;
                if (hover) { a = Theme.mix(a, Color.WHITE, .12f); b = Theme.mix(b, Color.WHITE, .12f); }
                if (press) { a = Theme.mix(a, Color.BLACK, .12f); b = Theme.mix(b, Color.BLACK, .12f); }
                if (hover && !press) { g.setColor(Theme.alpha(a, 50)); g.fill(new RoundRectangle2D.Float(2, 4, w - 5, h - 3, arc, arc)); }
                g.setPaint(new GradientPaint(0, 0, a, w, h, b)); g.fill(s); fg = Color.WHITE;
            }
            g.setFont(getFont()); FontMetrics fm = g.getFontMetrics();
            g.setColor(fg);
            g.drawString(getText(), (w - fm.stringWidth(getText())) / 2, (h - fm.getHeight()) / 2 + fm.getAscent() + (press ? 1 : 0));
            g.dispose();
        }
    }

    // ------------------------------------------------------------ Nav item
    public static class NavItem extends JButton {
        private boolean hover, active; private final String icon;
        public NavItem(String icon, String text) {
            super(text); this.icon = icon;
            setContentAreaFilled(false); setFocusPainted(false); setBorderPainted(false); setOpaque(false);
            setHorizontalAlignment(LEFT); setFont(Theme.font(Font.PLAIN, 14f));
            setForeground(new Color(190, 198, 225));
            setBorder(new EmptyBorder(0, 48, 0, 4));
            setAlignmentX(LEFT_ALIGNMENT); setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
            setPreferredSize(new Dimension(200, 44));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }
        public void setActive(boolean a) { active = a; setForeground(a ? Color.WHITE : new Color(190, 198, 225)); setFont(Theme.font(a ? Font.BOLD : Font.PLAIN, 14f)); repaint(); }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); quality(g);
            int w = getWidth(), h = getHeight();
            if (active) {
                g.setPaint(new GradientPaint(0, 0, new Color(99, 102, 241, 190), w, 0, new Color(139, 92, 246, 90)));
                g.fill(new RoundRectangle2D.Float(0, 0, w, h, 14, 14));
                g.setColor(Color.WHITE); g.fill(new RoundRectangle2D.Float(0, 10, 4, h - 20, 4, 4));
            } else if (hover) {
                g.setColor(new Color(255, 255, 255, 16)); g.fill(new RoundRectangle2D.Float(0, 0, w, h, 14, 14));
            }
            g.setFont(Theme.font(Font.PLAIN, 17f)); g.setColor(active ? Color.WHITE : new Color(160, 170, 205));
            FontMetrics fm = g.getFontMetrics();
            g.drawString(icon, 18, (h - fm.getHeight()) / 2 + fm.getAscent());
            g.dispose(); super.paintComponent(g0);
        }
    }

    // ------------------------------------------------------------ Donut
    public static class Donut extends Animated {
        private final Map<String, Double> data; private final Map<String, Color> colors; private final String centerLabel;
        public Donut(Map<String, Double> data, Map<String, Color> colors, String centerLabel) {
            this.data = data; this.colors = colors; this.centerLabel = centerLabel;
            setPreferredSize(new Dimension(300, 190));
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); quality(g);
            int w = getWidth(), h = getHeight(); int d = Math.min(h - 10, w / 2); int x = 10, y = (h - d) / 2;
            double total = 0; for (double v : data.values()) total += v;
            if (total == 0) { g.setColor(Theme.MUTED); g.setFont(Theme.font(0, 13f)); g.drawString("No data", x, h / 2); g.dispose(); return; }
            double start = 90; float stroke = d * 0.17f;
            g.setStroke(new BasicStroke(stroke, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND));
            g.setColor(Theme.SURFACE_ALT); g.draw(new Ellipse2D.Float(x + stroke / 2, y + stroke / 2, d - stroke, d - stroke));
            for (Map.Entry<String, Double> e : data.entrySet()) {
                double sweep = -360.0 * e.getValue() / total * progress;
                g.setColor(colors.get(e.getKey()));
                g.draw(new Arc2D.Double(x + stroke / 2, y + stroke / 2, d - stroke, d - stroke, start, sweep + (sweep < -3 ? 1.5 : 0), Arc2D.OPEN));
                start += sweep;
            }
            g.setColor(Theme.TEXT); g.setFont(Theme.font(Font.BOLD, d * 0.22f));
            String big = String.valueOf((int) Math.round(total * progress)); FontMetrics fm = g.getFontMetrics();
            g.drawString(big, x + (d - fm.stringWidth(big)) / 2, y + d / 2 - 2);
            g.setColor(Theme.MUTED); g.setFont(Theme.font(0, 11f)); fm = g.getFontMetrics();
            g.drawString(centerLabel, x + (d - fm.stringWidth(centerLabel)) / 2, y + d / 2 + fm.getAscent() + 12);
            int ly = h / 2 - data.size() * 13; int lx = x + d + 24;
            for (Map.Entry<String, Double> e : data.entrySet()) {
                g.setColor(colors.get(e.getKey())); g.fill(new RoundRectangle2D.Float(lx, ly, 11, 11, 4, 4));
                g.setColor(Theme.TEXT); g.setFont(Theme.font(Font.BOLD, 12f));
                g.drawString(pretty(e.getKey()), lx + 20, ly + 10);
                g.setColor(Theme.MUTED); g.setFont(Theme.font(0, 12f));
                String v = String.valueOf(e.getValue().intValue()); g.drawString(v + "  (" + Math.round(100 * e.getValue() / total) + "%)", lx + 20 + 82, ly + 10);
                ly += 26;
            }
            g.dispose();
        }
    }

    static String pretty(String s) {
        if (s == null || s.isEmpty()) return s;
        if (s.equals("MCQ")) return "MCQ";
        return s.charAt(0) + s.substring(1).toLowerCase().replace('_', ' ');
    }

    // ------------------------------------------------------------ Bar chart
    public static class Bars extends Animated {
        private final Map<String, Double> data; private final double max; private final boolean pct; private final Function colorFn;
        public interface Function { Color color(String key, double value); }
        public Bars(Map<String, Double> data, double max, boolean pct, Function colorFn) {
            this.data = data; this.max = max; this.pct = pct; this.colorFn = colorFn;
            setPreferredSize(new Dimension(300, Math.max(60, data.size() * 34 + 6)));
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); quality(g);
            int w = getWidth(); int labelW = 120, valW = 52; int y = 2;
            if (data.isEmpty()) { g.setColor(Theme.MUTED); g.setFont(Theme.font(0, 13f)); g.drawString("No data yet", 0, 20); }
            for (Map.Entry<String, Double> e : data.entrySet()) {
                g.setFont(Theme.font(0, 12f)); g.setColor(Theme.TEXT);
                String label = e.getKey().equals(e.getKey().toUpperCase()) && e.getKey().length() > 3 && !e.getKey().contains(" ") ? pretty(e.getKey()) : e.getKey(); FontMetrics fm = g.getFontMetrics();
                while (fm.stringWidth(label) > labelW - 8 && label.length() > 3) label = label.substring(0, label.length() - 2);
                if (label.length() < (e.getKey().equals(e.getKey().toUpperCase()) ? pretty(e.getKey()).length() : e.getKey().length())) label += "…";
                g.drawString(label, 0, y + 17);
                int bx = labelW, bw = w - labelW - valW; if (bw < 10) bw = 10;
                g.setColor(Theme.SURFACE_ALT); g.fill(new RoundRectangle2D.Float(bx, y + 6, bw, 12, 12, 12));
                double frac = Math.min(1, e.getValue() / max) * progress; Color c = colorFn.color(e.getKey(), e.getValue());
                if (frac > 0) {
                    g.setPaint(new GradientPaint(bx, 0, Theme.mix(c, Color.WHITE, .25f), bx + bw, 0, c));
                    g.fill(new RoundRectangle2D.Float(bx, y + 6, Math.max(12, (float) (bw * frac)), 12, 12, 12));
                }
                g.setColor(Theme.TEXT); g.setFont(Theme.font(Font.BOLD, 12f));
                String v = pct ? String.format("%.0f%%", e.getValue() * progress) : String.valueOf((int) Math.round(e.getValue() * progress));
                g.drawString(v, w - valW + 10, y + 17);
                y += 34;
            }
            g.dispose();
        }
    }

    // ------------------------------------------------------------ Gauge
    public static class Gauge extends Animated {
        private final double value; private final String label;
        public Gauge(double value, String label) { this.value = value; this.label = label; setPreferredSize(new Dimension(170, 170)); }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); quality(g);
            int d = Math.min(getWidth(), getHeight()) - 20; int x = (getWidth() - d) / 2, y = 10; float st = 14;
            g.setStroke(new BasicStroke(st, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(Theme.SURFACE_ALT); g.draw(new Arc2D.Double(x + st / 2, y + st / 2, d - st, d - st, 225, -270, Arc2D.OPEN));
            Color c = Theme.scoreColor(value);
            g.setPaint(new GradientPaint(x, y, Theme.mix(c, Color.WHITE, .3f), x + d, y + d, c));
            g.draw(new Arc2D.Double(x + st / 2, y + st / 2, d - st, d - st, 225, -270 * Math.min(1, value / 100) * progress, Arc2D.OPEN));
            g.setColor(Theme.TEXT); g.setFont(Theme.font(Font.BOLD, d * 0.24f)); FontMetrics fm = g.getFontMetrics();
            String t = String.format("%.0f%%", value * progress); g.drawString(t, x + (d - fm.stringWidth(t)) / 2, y + d / 2 + fm.getAscent() / 3);
            g.setColor(Theme.MUTED); g.setFont(Theme.font(0, 12f)); fm = g.getFontMetrics();
            g.drawString(label, x + (d - fm.stringWidth(label)) / 2, y + d / 2 + fm.getAscent() + 14);
            g.dispose();
        }
    }

    // ---------------------------------------------------- Count-up number
    public static class CountLabel extends JLabel {
        private final double target; private final String suffix;
        public CountLabel(double target, String suffix, Color color) {
            super("0" + suffix); this.target = target; this.suffix = suffix;
            setFont(Theme.font(Font.BOLD, 30f)); setForeground(color);
        }
        @Override public void addNotify() {
            super.addNotify();
            final long start = System.currentTimeMillis();
            new Timer(16, e -> {
                double p = ease((System.currentTimeMillis() - start) / 900.0);
                setText((target == Math.floor(target) ? String.valueOf((int) Math.round(target * p)) : String.format("%.1f", target * p)) + suffix);
                if (p >= 1) ((Timer) e.getSource()).stop();
            }).start();
        }
    }

    // ------------------------------------------------------ Input styling
    public static class RoundBorder extends AbstractBorder {
        private final Color color; private final int arc; private final Insets in;
        public RoundBorder(Color color, int arc, Insets in) { this.color = color; this.arc = arc; this.in = in; }
        @Override public void paintBorder(Component c, Graphics g0, int x, int y, int w, int h) {
            Graphics2D g = (Graphics2D) g0.create(); quality(g);
            g.setColor(c.hasFocus() || (c instanceof JComponent && ((JComponent) c).getClientProperty("focus") == Boolean.TRUE) ? Theme.PRIMARY : color);
            g.draw(new RoundRectangle2D.Float(x + .5f, y + .5f, w - 1, h - 1, arc, arc)); g.dispose();
        }
        @Override public Insets getBorderInsets(Component c) { return in; }
    }

    public static <T extends javax.swing.text.JTextComponent> T field(T t) {
        t.setFont(Theme.font(0, 13.5f)); t.setForeground(Theme.TEXT); t.setBackground(Theme.INPUT_BG);
        t.setCaretColor(Theme.PRIMARY); t.setSelectionColor(Theme.alpha(Theme.PRIMARY, 90)); t.setSelectedTextColor(Theme.TEXT);
        t.setBorder(new RoundBorder(Theme.BORDER, 12, new Insets(9, 12, 9, 12)));
        t.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) { t.repaint(); }
            @Override public void focusLost(FocusEvent e) { t.repaint(); }
        });
        return t;
    }

    public static <T> JComboBox<T> combo(JComboBox<T> c) {
        c.setFont(Theme.font(0, 13.5f)); c.setForeground(Theme.TEXT); c.setBackground(Theme.INPUT_BG);
        c.setBorder(new RoundBorder(Theme.BORDER, 12, new Insets(5, 8, 5, 4)));
        c.setUI(new BasicComboBoxUI() {
            @Override protected JButton createArrowButton() {
                JButton b = new JButton() {
                    @Override protected void paintComponent(Graphics g0) {
                        Graphics2D g = (Graphics2D) g0.create(); quality(g);
                        g.setColor(Theme.MUTED); g.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                        int cx = getWidth() / 2, cy = getHeight() / 2; g.drawLine(cx - 4, cy - 2, cx, cy + 2); g.drawLine(cx, cy + 2, cx + 4, cy - 2); g.dispose();
                    }
                };
                b.setBorder(BorderFactory.createEmptyBorder()); b.setContentAreaFilled(false); b.setFocusPainted(false);
                return b;
            }
            @Override public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) {
                g.setColor(Theme.INPUT_BG); g.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
            }
        });
        c.setRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean sel, boolean foc) {
                JLabel x = (JLabel) super.getListCellRendererComponent(l, v, i, sel, foc);
                x.setBorder(new EmptyBorder(6, 10, 6, 10)); x.setFont(Theme.font(0, 13.5f));
                x.setBackground(sel ? Theme.alpha(Theme.PRIMARY, 60) : Theme.SURFACE); x.setForeground(Theme.TEXT); return x;
            }
        });
        c.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return c;
    }

    public static JSpinner spinner(SpinnerModel m) {
        JSpinner s = new JSpinner(m); s.setFont(Theme.font(0, 13.5f)); s.setBorder(new RoundBorder(Theme.BORDER, 12, new Insets(3, 4, 3, 4)));
        JComponent ed = s.getEditor();
        if (ed instanceof JSpinner.DefaultEditor) {
            JTextField tf = ((JSpinner.DefaultEditor) ed).getTextField();
            tf.setBackground(Theme.INPUT_BG); tf.setForeground(Theme.TEXT); tf.setBorder(new EmptyBorder(4, 8, 4, 8)); tf.setFont(Theme.font(0, 13.5f));
        }
        ed.setBackground(Theme.INPUT_BG);
        for (Component c : s.getComponents()) if (c instanceof JButton) { ((JButton) c).setBackground(Theme.SURFACE_ALT); ((JButton) c).setBorder(new EmptyBorder(0, 6, 0, 6)); }
        return s;
    }

    public static JScrollPane scroll(Component c) {
        JScrollPane sp = new JScrollPane(c); sp.setBorder(BorderFactory.createEmptyBorder());
        sp.getViewport().setOpaque(false); sp.getViewport().setScrollMode(JViewport.SIMPLE_SCROLL_MODE); sp.setOpaque(false); sp.getVerticalScrollBar().setUnitIncrement(18);
        sp.getVerticalScrollBar().setUI(new ThinScroll()); sp.getHorizontalScrollBar().setUI(new ThinScroll());
        sp.getVerticalScrollBar().setPreferredSize(new Dimension(10, 0)); sp.getHorizontalScrollBar().setPreferredSize(new Dimension(0, 10));
        return sp;
    }

    static class ThinScroll extends BasicScrollBarUI {
        @Override protected void configureScrollBarColors() { thumbColor = Theme.alpha(Theme.MUTED, 110); }
        @Override protected JButton createDecreaseButton(int o) { return zero(); }
        @Override protected JButton createIncreaseButton(int o) { return zero(); }
        private JButton zero() { JButton b = new JButton(); b.setPreferredSize(new Dimension(0, 0)); return b; }
        @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) {}
        @Override protected void paintThumb(Graphics g0, JComponent c, Rectangle r) {
            if (r.isEmpty()) return; Graphics2D g = (Graphics2D) g0.create(); quality(g);
            g.setColor(thumbColor); g.fill(new RoundRectangle2D.Float(r.x + 2, r.y + 2, r.width - 4, r.height - 4, 8, 8)); g.dispose();
        }
    }

    // ----------------------------------------------------------- Tables
    public static void styleTable(JTable t) {
        t.setRowHeight(42); t.setShowGrid(false); t.setIntercellSpacing(new Dimension(0, 0));
        t.setFont(Theme.font(0, 13f)); t.setForeground(Theme.TEXT); t.setBackground(Theme.SURFACE);
        t.setSelectionBackground(Theme.alpha(Theme.PRIMARY, Theme.dark ? 70 : 35)); t.setSelectionForeground(Theme.TEXT);
        t.setFillsViewportHeight(true); t.setFocusable(true);
        JTableHeader h = t.getTableHeader(); h.setReorderingAllowed(false); h.setPreferredSize(new Dimension(100, 38));
        h.setDefaultRenderer(new TableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tb, Object v, boolean s, boolean f, int r, int c) {
                JLabel l = new JLabel(v == null ? "" : v.toString().toUpperCase()); l.setOpaque(true); l.setBackground(Theme.SURFACE_ALT);
                l.setForeground(Theme.MUTED); l.setFont(Theme.font(Font.BOLD, 11f)); l.setBorder(new EmptyBorder(0, 14, 0, 8)); return l;
            }
        });
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tb, Object v, boolean sel, boolean foc, int r, int c) {
                String s = v == null ? "" : v.toString(); String name = tb.getColumnName(c).toLowerCase();
                Color badge = null;
                if (name.equals("difficulty")) badge = Theme.difficulty(s);
                else if (name.equals("bloom")) badge = Theme.bloom(s);
                else if (name.equals("type")) badge = Theme.PRIMARY;
                else if (name.equals("score") || name.equals("percentage") || name.equals("pct")) { try { badge = Theme.scoreColor(Double.parseDouble(s.replace("%", ""))); } catch (Exception ignored) {} }
                JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0) {
                    @Override public void layoutContainer(Container pr) { super.layoutContainer(pr); }
                });
                p.setOpaque(true); p.setBackground(sel ? t.getSelectionBackground() : (r % 2 == 0 ? Theme.SURFACE : Theme.SURFACE_ALT));
                JComponent comp;
                if (badge != null) {
                    String txt = s;
                    if (name.equals("type")) txt = s.equals("SHORT_ANSWER") ? "Short" : s.equals("DESCRIPTIVE") ? "Essay" : pretty(s);
                    else if (name.equals("difficulty") || name.equals("bloom")) txt = pretty(s);
                    Pill pl = new Pill(txt, badge); pl.setBorder(new EmptyBorder(2, 8, 2, 8)); pl.setFont(Theme.font(Font.BOLD, 10.5f)); comp = pl; }
                else { JLabel l = new JLabel(s); l.setFont(Theme.font(name.equals("id") ? Font.BOLD : 0, 13f)); l.setForeground(name.equals("id") ? Theme.PRIMARY : Theme.TEXT); comp = l; }
                p.setLayout(new BorderLayout()); p.setBorder(new EmptyBorder(8, 14, 8, 8));
                JPanel wrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0)); wrap.setOpaque(false); wrap.add(comp);
                if (badge == null) { p.add(comp, BorderLayout.CENTER); } else { p.add(wrap, BorderLayout.WEST); }
                return p;
            }
        });
    }
}
