package smartsassessment.ui;

import java.awt.*;

/** Central design tokens (colors, fonts) with light / dark mode support. */
public final class Theme {
    private Theme() {}

    public static boolean dark = false;

    public static Color BG, SURFACE, SURFACE_ALT, BORDER, TEXT, MUTED, INPUT_BG, HOVER;

    public static final Color PRIMARY  = new Color(99, 102, 241);
    public static final Color PRIMARY2 = new Color(139, 92, 246);
    public static final Color ACCENT   = new Color(6, 182, 212);
    public static final Color GOOD     = new Color(16, 185, 129);
    public static final Color WARN     = new Color(245, 158, 11);
    public static final Color BAD      = new Color(239, 68, 68);
    public static final Color PINK     = new Color(236, 72, 153);

    public static final Color SIDE_TOP = new Color(15, 23, 42);
    public static final Color SIDE_BOT = new Color(37, 28, 92);

    public static final Color[] PALETTE = {
        PRIMARY, ACCENT, GOOD, WARN, PINK, PRIMARY2, BAD, new Color(14, 165, 233)
    };

    static { apply(false); }

    public static void apply(boolean isDark) {
        dark = isDark;
        if (isDark) {
            BG = new Color(11, 15, 26);       SURFACE = new Color(21, 27, 43);
            SURFACE_ALT = new Color(28, 36, 56); BORDER = new Color(40, 50, 74);
            TEXT = new Color(235, 240, 250);  MUTED = new Color(142, 154, 178);
            INPUT_BG = new Color(15, 20, 34); HOVER = new Color(34, 44, 68);
        } else {
            BG = new Color(243, 245, 251);    SURFACE = Color.WHITE;
            SURFACE_ALT = new Color(247, 248, 253); BORDER = new Color(226, 230, 241);
            TEXT = new Color(23, 29, 48);     MUTED = new Color(105, 116, 140);
            INPUT_BG = new Color(248, 249, 253); HOVER = new Color(238, 240, 252);
        }
    }

    public static Font font(int style, float size) {
        return new Font("Segoe UI", style, 12).deriveFont(style, size);
    }

    public static Color alpha(Color c, int a) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, a)));
    }

    public static Color mix(Color a, Color b, float t) {
        return new Color(
            (int) (a.getRed() + (b.getRed() - a.getRed()) * t),
            (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t),
            (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * t));
    }

    public static Color difficulty(String d) {
        if (d == null) return MUTED;
        switch (d.toUpperCase()) {
            case "EASY":   return GOOD;
            case "MEDIUM": return WARN;
            case "HARD":   return BAD;
            default:       return MUTED;
        }
    }

    public static Color bloom(String b) {
        if (b == null) return MUTED;
        switch (b.toUpperCase()) {
            case "REMEMBER":   return new Color(14, 165, 233);
            case "UNDERSTAND": return ACCENT;
            case "APPLY":      return GOOD;
            case "ANALYZE":    return WARN;
            case "EVALUATE":   return PINK;
            case "CREATE":     return PRIMARY2;
            default:           return MUTED;
        }
    }

    public static Color scoreColor(double pct) {
        return pct >= 80 ? GOOD : pct >= 65 ? WARN : BAD;
    }
}
