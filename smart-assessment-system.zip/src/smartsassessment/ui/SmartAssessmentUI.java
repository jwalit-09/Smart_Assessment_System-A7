package smartsassessment.ui;

import smartsassessment.model.*;
import smartsassessment.service.*;
import smartsassessment.storage.DataManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

/**
 * Smart Assessment System - premium desktop UI.
 * Every screen is driven by the existing Core Java services (QuestionGenerator, DuplicateDetector,
 * AssessmentGenerator, AssessmentEvaluator, AnalyticsService, KMP search, ...).
 */
public class SmartAssessmentUI extends JFrame {
    private static final String[] TITLES = {"Dashboard", "Question Generator", "Question Bank", "Assessment Builder", "Exam Mode", "Analytics", "Algorithm Lab"};
    private static final String[] SUBS = {"Live overview of your question bank, students and results",
        "Generate questions from topics, auto-classified by Bloom level and difficulty",
        "Search with KMP, filter, inspect, and audit your questions for duplicates",
        "Build balanced papers that satisfy difficulty and Bloom constraints",
        "Run a timed, auto-graded exam session for a student",
        "Cohort performance by module, topic, difficulty and cognitive level",
        "Run the hand-written algorithms live and see how they work"};
    private static final String[] ICONS = {"⌂", "✦", "☰", "▤", "✎", "◔", "⚙"};

    private final DataManager dm = new DataManager("data");
    private int page = 0;
    private Widgets.NavItem[] navs;
    private JPanel holder; private JLabel pageTitle, pageSub;
    private ExamPage exam;

    public SmartAssessmentUI() {
        dm.init(); hydrateBreakdowns();
        setTitle("Smart Assessment & Question Bank System"); setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1380, 840); setMinimumSize(new Dimension(1180, 700)); setLocationRelativeTo(null);
        setIconImage(logo(64));
        Kit.ToastLayer toast = new Kit.ToastLayer(); setGlassPane(toast); toast.setVisible(true);
        build(); go(0);
    }

    /**
     * Results loaded from the flat file only carry per-answer marks. Rebuild the module / topic / difficulty /
     * Bloom percentage breakdowns from those answers so analytics work for historical data too.
     */
    private void hydrateBreakdowns() {
        for (Performance p : dm.getResults()) {
            boolean missing = p.getTopicBreakdown() == null || p.getTopicBreakdown().isEmpty();
            if (!missing || p.getAnswers() == null) continue;
            Map<String, int[]> topic = new HashMap<>(), module = new HashMap<>(), diff = new HashMap<>(), bloom = new HashMap<>();
            for (Answer a : p.getAnswers()) {
                Question q = dm.getQuestionBank().findQuestionById(a.getQuestionId()); if (q == null) continue;
                add(topic, q.getTopic(), a); add(module, q.getModule(), a); add(diff, q.getDifficulty().name(), a); add(bloom, q.getBloomLevel().name(), a);
            }
            p.setTopicBreakdown(pct(topic)); p.setModuleBreakdown(pct(module)); p.setDifficultyBreakdown(pct(diff)); p.setBloomBreakdown(pct(bloom));
        }
    }
    private static void add(Map<String, int[]> m, String k, Answer a) { int[] v = m.computeIfAbsent(k, x -> new int[2]); v[0] += a.getMarksAwarded(); v[1] += a.getMaxMarks(); }
    private static Map<String, Double> pct(Map<String, int[]> m) { Map<String, Double> r = new LinkedHashMap<>(); for (Map.Entry<String, int[]> e : m.entrySet()) r.put(e.getKey(), e.getValue()[1] == 0 ? 0.0 : Math.round(1000.0 * e.getValue()[0] / e.getValue()[1]) / 10.0); return r; }

    // =========================================================== Shell
    private static BufferedImage logo(int s) {
        BufferedImage im = new BufferedImage(s, s, BufferedImage.TYPE_INT_ARGB); Graphics2D g = im.createGraphics(); Widgets.quality(g);
        g.setPaint(new GradientPaint(0, 0, Theme.PRIMARY, s, s, Theme.PRIMARY2)); g.fill(new RoundRectangle2D.Float(0, 0, s, s, s * .3f, s * .3f));
        g.setColor(Color.WHITE); g.setFont(Theme.font(Font.BOLD, s * .42f)); FontMetrics fm = g.getFontMetrics();
        g.drawString("SA", (s - fm.stringWidth("SA")) / 2, (s + fm.getAscent() - fm.getDescent()) / 2); g.dispose(); return im;
    }

    private void build() {
        JPanel root = new JPanel(new BorderLayout()); root.setBackground(Theme.BG);
        root.add(sidebar(), BorderLayout.WEST);
        JPanel right = new JPanel(new BorderLayout()); right.setOpaque(false);
        right.add(topBar(), BorderLayout.NORTH);
        holder = new JPanel(new BorderLayout()); holder.setOpaque(false); holder.setBorder(new EmptyBorder(0, 28, 0, 22));
        right.add(holder, BorderLayout.CENTER); root.add(right, BorderLayout.CENTER);
        setContentPane(root);
    }

    private JComponent sidebar() {
        JPanel side = new JPanel() {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
                g.setPaint(new GradientPaint(0, 0, Theme.SIDE_TOP, 0, getHeight(), Theme.SIDE_BOT)); g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(new Color(139, 92, 246, 40)); g.fillOval(-90, getHeight() - 220, 300, 300); g.dispose();
            }
        };
        side.setOpaque(false); side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS)); side.setPreferredSize(new Dimension(268, 0)); side.setBorder(new EmptyBorder(26, 18, 22, 18));
        JPanel brand = new JPanel(new BorderLayout(12, 0)); brand.setOpaque(false); brand.setAlignmentX(LEFT_ALIGNMENT); brand.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        JLabel lg = new JLabel(new ImageIcon(logo(44))); JPanel bt = Kit.vbox();
        bt.add(Kit.left(Kit.label("Smart Assessment", Font.BOLD, 15f, Color.WHITE))); bt.add(Kit.left(Kit.label("Question Bank System", Font.PLAIN, 11.5f, new Color(165, 175, 220))));
        brand.add(lg, BorderLayout.WEST); brand.add(bt, BorderLayout.CENTER); side.add(brand); side.add(Box.createVerticalStrut(30));
        JLabel menu = Kit.label("MENU", Font.BOLD, 10.5f, new Color(125, 135, 185)); menu.setBorder(new EmptyBorder(0, 6, 8, 0)); side.add(Kit.left(menu));
        navs = new Widgets.NavItem[TITLES.length];
        for (int i = 0; i < TITLES.length; i++) {
            final int n = i; navs[i] = new Widgets.NavItem(ICONS[i], TITLES[i]); navs[i].addActionListener(e -> go(n));
            side.add(navs[i]); side.add(Box.createVerticalStrut(4));
            if (i == 4) { side.add(Box.createVerticalStrut(10)); JLabel m2 = Kit.label("INSIGHTS", Font.BOLD, 10.5f, new Color(125, 135, 185)); m2.setBorder(new EmptyBorder(0, 6, 8, 0)); side.add(Kit.left(m2)); }
        }
        side.add(Box.createVerticalGlue());
        JPanel status = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g0) { Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
                g.setColor(new Color(255, 255, 255, 18)); g.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g.setColor(new Color(52, 211, 153)); g.fillOval(16, 20, 9, 9); g.dispose(); } };
        status.setOpaque(false); status.setBorder(new EmptyBorder(12, 34, 12, 10)); status.setAlignmentX(LEFT_ALIGNMENT); status.setMaximumSize(new Dimension(Integer.MAX_VALUE, 62));
        JPanel st = Kit.vbox(); st.add(Kit.left(Kit.label("Core engine online", Font.BOLD, 12.5f, Color.WHITE))); st.add(Kit.left(Kit.label("18 algorithms · pure Java", Font.PLAIN, 11f, new Color(165, 175, 220))));
        status.add(st); side.add(status); return side;
    }

    private JComponent topBar() {
        JPanel bar = new JPanel(new BorderLayout()); bar.setOpaque(false); bar.setBorder(new EmptyBorder(22, 28, 14, 28));
        JPanel t = Kit.vbox(); pageTitle = Kit.label("", Font.BOLD, 26f, Theme.TEXT); pageSub = Kit.muted(""); t.add(Kit.left(pageTitle)); t.add(Kit.left(pageSub));
        JPanel r = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0)); r.setOpaque(false);
        JLabel date = Kit.label(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy")), Font.BOLD, 12.5f, Theme.MUTED);
        Widgets.Btn theme = new Widgets.Btn(Theme.dark ? "☀  Light mode" : "☾  Dark mode", Widgets.Btn.Kind.GHOST);
        theme.addActionListener(e -> { Theme.apply(!Theme.dark); exam = null; build(); go(page); revalidate(); repaint(); });
        JLabel av = new JLabel("T", SwingConstants.CENTER) { @Override protected void paintComponent(Graphics g0) { Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
            g.setPaint(new GradientPaint(0, 0, Theme.ACCENT, getWidth(), getHeight(), Theme.PRIMARY)); g.fillOval(0, 0, getWidth(), getHeight()); g.dispose(); super.paintComponent(g0); } };
        av.setFont(Theme.font(Font.BOLD, 15f)); av.setForeground(Color.WHITE); av.setPreferredSize(new Dimension(40, 40)); av.setToolTipText("Teacher");
        r.add(date); r.add(theme); r.add(av); bar.add(t, BorderLayout.WEST); bar.add(r, BorderLayout.EAST); return bar;
    }

    private static List<JScrollPane> scrollPanes(Component c) {
        List<JScrollPane> r = new ArrayList<>(); if (c instanceof JScrollPane) r.add((JScrollPane) c);
        if (c instanceof Container) for (Component x : ((Container) c).getComponents()) r.addAll(scrollPanes(x)); return r;
    }

    private int contentW() { return Math.max(700, getWidth() - 268 - 56 - 20); }

    private void go(int i) {
        page = i; for (int k = 0; k < navs.length; k++) navs[k].setActive(k == i);
        pageTitle.setText(TITLES[i]); pageSub.setText(SUBS[i]); holder.removeAll();
        JComponent c;
        switch (i) {
            case 0: c = dashboard(); break; case 1: c = generator(); break; case 2: c = bank(); break; case 3: c = builder(); break;
            case 4: if (exam == null) exam = new ExamPage(dm); c = exam; break; case 5: c = analytics(); break; default: c = new AlgorithmLab();
        }
        holder.add(c); holder.revalidate(); holder.repaint();
        final JComponent cc = c; SwingUtilities.invokeLater(() -> { for (JScrollPane sp : scrollPanes(cc)) sp.getViewport().setViewPosition(new Point(0, 0)); });
    }

    private Kit.Page newPage() { return new Kit.Page(); }
    private JScrollPane scrolled(Kit.Page p) { p.setBorder(new EmptyBorder(0, 0, 24, 6)); return Widgets.scroll(p); }

    // ====================================================== Data helpers
    private Map<String, Double> countDifficulty(List<Question> qs) {
        Map<String, Double> m = new LinkedHashMap<>(); for (DifficultyLevel d : DifficultyLevel.values()) m.put(d.name(), 0.0);
        for (Question q : qs) m.merge(q.getDifficulty().name(), 1.0, Double::sum); return m;
    }
    private Map<String, Double> countBloom(List<Question> qs) {
        Map<String, Double> m = new LinkedHashMap<>(); for (BloomLevel b : BloomLevel.values()) m.put(b.name(), 0.0);
        for (Question q : qs) m.merge(q.getBloomLevel().name(), 1.0, Double::sum); return m;
    }
    private Map<String, Double> countModules(List<Question> qs) {
        Map<String, Double> m = new TreeMap<>(); for (Question q : qs) m.merge(q.getModule(), 1.0, Double::sum); return m;
    }
    private Map<String, Color> diffColors() { Map<String, Color> c = new HashMap<>(); for (DifficultyLevel d : DifficultyLevel.values()) c.put(d.name(), Theme.difficulty(d.name())); return c; }
    private double max(Map<String, Double> m) { double x = 1; for (double v : m.values()) x = Math.max(x, v); return x; }

    private JComponent tableCard(String title, String sub, JTable t, int rows) {
        Widgets.styleTable(t); JScrollPane sp = new JScrollPane(t); sp.setBorder(BorderFactory.createEmptyBorder()); sp.getViewport().setBackground(Theme.SURFACE);
        sp.setPreferredSize(new Dimension(100, 40 + rows * 42)); sp.getHorizontalScrollBar().setUI(new Widgets.ThinScroll()); sp.getVerticalScrollBar().setUI(new Widgets.ThinScroll());
        return Kit.section(title, sub, sp);
    }

    // ========================================================= Dashboard
    private JComponent dashboard() {
        Kit.Page p = newPage(); List<Question> qs = dm.getQuestionBank().getQuestions();
        AnalyticsService.OverallAnalytics an = AnalyticsService.computeAnalytics(dm.getResults());

        Widgets.GradientPanel hero = new Widgets.GradientPanel(Theme.PRIMARY, new Color(168, 85, 247), 26);
        hero.setLayout(new BorderLayout()); hero.setBorder(new EmptyBorder(26, 32, 26, 32));
        JPanel ht = Kit.vbox(); ht.add(Kit.left(Kit.label("Welcome back, Professor", Font.BOLD, 28f, Color.WHITE)));
        ht.add(Box.createVerticalStrut(6));
        ht.add(Kit.left(Kit.label("Your bank holds " + qs.size() + " questions across " + countModules(qs).size() + " modules, with " + dm.getResults().size() + " graded submissions ready to analyse.", Font.PLAIN, 14f, new Color(235, 232, 255))));
        ht.add(Box.createVerticalStrut(16));
        Widgets.Btn b1 = new Widgets.Btn("✦  Generate questions", Widgets.Btn.Kind.LIGHT); b1.addActionListener(e -> go(1));
        Widgets.Btn b2 = new Widgets.Btn("▤  Build an assessment", Widgets.Btn.Kind.LIGHT); b2.addActionListener(e -> go(3));
        Widgets.Btn b3 = new Widgets.Btn("✎  Start an exam", Widgets.Btn.Kind.LIGHT); b3.addActionListener(e -> go(4));
        ht.add(Kit.left(Kit.flow(10, 0, b1, b2, b3))); hero.add(ht);
        p.addRow(hero);

        p.addRow(Kit.even(4, 16,
            Kit.statCard("?", "QUESTIONS", new Widgets.CountLabel(qs.size(), "", Theme.TEXT), Theme.PRIMARY, "in the question bank"),
            Kit.statCard("☺", "STUDENTS", new Widgets.CountLabel(dm.getStudents().size(), "", Theme.TEXT), Theme.ACCENT, "registered learners"),
            Kit.statCard("▤", "ASSESSMENTS", new Widgets.CountLabel(dm.getAssessments().size(), "", Theme.TEXT), Theme.PINK, "papers generated"),
            Kit.statCard("✔", "AVG. SCORE", new Widgets.CountLabel(an.getTotalAssessmentsTaken() == 0 ? 0 : an.getAveragePercentage(), "%", Theme.TEXT), Theme.GOOD, dm.getResults().size() + (dm.getResults().size() == 1 ? " graded submission" : " graded submissions"))));

        p.addRow(Kit.cols(new double[]{0.4, 0.6}, 16,
            Kit.section("Difficulty mix", "How hard is your bank?", new Widgets.Donut(countDifficulty(qs), diffColors(), "questions")),
            Kit.section("Bloom's taxonomy coverage", "Questions per cognitive level", new Widgets.Bars(countBloom(qs), max(countBloom(qs)), false, (k, v) -> Theme.bloom(k)))));

        JPanel insights = Kit.vbox(); JLabel dupLabel = Kit.muted("Scanning for near-duplicates…");
        for (String[] ins : insightList(qs, an)) { insights.add(Kit.left(insight(ins[0], ins[1], ins[2]))); insights.add(Box.createVerticalStrut(10)); }
        JComponent dupRow = insight("i", "Duplicate audit", "Scanning bank with TF-IDF + cosine similarity…");
        insights.add(Kit.left(dupRow));
        new SwingWorker<Integer, Void>() {
            @Override protected Integer doInBackground() { int n = 0; for (DuplicateDetector.SimilarityReport r : DuplicateDetector.scanAllPairs(qs)) if (r.getVerdict() != DuplicateDetector.MatchVerdict.DIFFERENT) n++; return n; }
            @Override protected void done() { try { int n = get(); insights.remove(dupRow);
                insights.add(Kit.left(insight(n == 0 ? "g" : "w", "Duplicate audit", n == 0 ? "No duplicate or near-duplicate questions found — your bank is clean." : n + " question pair(s) flagged as similar. Review them in Question Bank → Scan duplicates.")));
                insights.revalidate(); insights.repaint(); } catch (Exception ignored) {} }
        }.execute();
        p.addRow(Kit.cols(new double[]{0.4, 0.6}, 16,
            Kit.section("Module coverage", "Questions per module", new Widgets.Bars(countModules(qs), max(countModules(qs)), false, (k, v) -> Theme.PALETTE[Math.abs(k.hashCode()) % Theme.PALETTE.length])),
            Kit.section("Smart insights", "Generated automatically from your data", insights)));

        p.addRow(workflow());

        DefaultTableModel m = new DefaultTableModel(new String[]{"Student", "Assessment", "Score", "Percentage", "Date"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        List<Performance> rs = new ArrayList<>(dm.getResults()); Collections.reverse(rs);
        for (int i = 0; i < Math.min(5, rs.size()); i++) { Performance r = rs.get(i); m.addRow(new Object[]{r.getStudentName(), r.getAssessmentId(), r.getScore() + " / " + r.getTotalMarks(), String.format("%.0f%%", r.getPercentage()), r.getSubmissionDate()}); }
        p.addRow(tableCard("Recent submissions", "Latest graded attempts", new JTable(m), Math.max(1, m.getRowCount())), 0);
        return scrolled(p);
    }

    private List<String[]> insightList(List<Question> qs, AnalyticsService.OverallAnalytics an) {
        List<String[]> l = new ArrayList<>();
        if (an.getTotalAssessmentsTaken() > 0) {
            double avg = an.getAveragePercentage();
            l.add(new String[]{avg >= 75 ? "g" : avg >= 60 ? "w" : "b", "Cohort performance", String.format("Average score is %.1f%% (best %.0f%%, lowest %.0f%%).", avg, an.getHighestPercentage(), an.getLowestPercentage())});
            String weakest = null; double wv = 101; for (Map.Entry<String, Double> e : an.getTopicAverages().entrySet()) if (e.getValue() < wv) { wv = e.getValue(); weakest = e.getKey(); }
            if (weakest != null) l.add(new String[]{wv < 65 ? "b" : "w", "Weakest topic", weakest + " at " + String.format("%.0f%%", wv) + (wv < 65 ? " — schedule a revision session." : " — still your lowest, worth a quick recap.")});
        } else l.add(new String[]{"i", "No submissions yet", "Run an exam to unlock performance analytics."});
        Map<String, Double> bl = countBloom(qs); for (Map.Entry<String, Double> e : bl.entrySet()) if (e.getValue() < 5) { l.add(new String[]{"w", "Bloom gap: " + Widgets.pretty(e.getKey()), "Only " + e.getValue().intValue() + " question(s) at this level. Use the generator to add more."}); break; }
        Map<String, Double> df = countDifficulty(qs); double tot = Math.max(1, qs.size());
        if (df.get("HARD") / tot > 0.4) l.add(new String[]{"w", "Hard-heavy bank", String.format("%.0f%% of questions are HARD — consider adding more EASY items for balance.", 100 * df.get("HARD") / tot)});
        return l;
    }

    private JComponent insight(String kind, String title, String text) {
        Color c = kind.equals("g") ? Theme.GOOD : kind.equals("w") ? Theme.WARN : kind.equals("b") ? Theme.BAD : Theme.PRIMARY;
        JPanel p = new JPanel(new BorderLayout(12, 0)) { @Override protected void paintComponent(Graphics g0) { Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
            g.setColor(Theme.alpha(c, Theme.dark ? 30 : 18)); g.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 14, 14)); g.setColor(c); g.fill(new RoundRectangle2D.Float(0, 10, 4, getHeight() - 20, 4, 4)); g.dispose(); } };
        p.setOpaque(false); p.setBorder(new EmptyBorder(10, 16, 10, 12));
        JPanel t = Kit.vbox(); t.add(Kit.left(Kit.label(title, Font.BOLD, 13f, Theme.TEXT))); t.add(Kit.left(Kit.wrap(text, Math.max(300, (contentW() - 32) * 6 / 10 - 90), 0, 12.5f, Theme.MUTED))); p.add(t); return p;
    }

    private JComponent workflow() {
        String[] steps = {"Topic / content", "Generate", "Classify Bloom + difficulty", "Duplicate check", "Question bank", "Build assessment", "Auto-evaluate", "Analytics"};
        JPanel flow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 6)); flow.setOpaque(false);
        for (int i = 0; i < steps.length; i++) {
            flow.add(new Widgets.Pill((i + 1) + "  " + steps[i], Theme.PALETTE[i % Theme.PALETTE.length]));
            if (i < steps.length - 1) flow.add(Kit.label("›", Font.BOLD, 18f, Theme.MUTED));
        }
        return Kit.section("How the system works", "From raw topic to cohort insight — every step runs on your own algorithms", flow);
    }

    // ============================================================ Generator
    private JComponent generator() {
        String[] topics = {"KMP", "Rabin-Karp", "Suffix Array", "LCP Kasai", "Matrix Chain", "TSP Bitmask", "Max Flow", "Miller-Rabin", "Pattern Search", "Fuzzy Matching", "Document Similarity", "Naive Pattern Matching", "Z Algorithm", "Aho-Corasick"};
        JComboBox<String> module = Widgets.combo(new JComboBox<>(new String[]{"Module 1", "Module 2", "Module 3"}));
        JComboBox<String> topic = Widgets.combo(new JComboBox<>(topics));
        JComboBox<QuestionType> type = Widgets.combo(new JComboBox<>(QuestionType.values()));
        JComboBox<DifficultyLevel> diff = Widgets.combo(new JComboBox<>(DifficultyLevel.values())); diff.setSelectedItem(DifficultyLevel.MEDIUM);
        JComboBox<BloomLevel> bloom = Widgets.combo(new JComboBox<>(BloomLevel.values())); bloom.setSelectedItem(BloomLevel.UNDERSTAND);
        JSpinner count = Widgets.spinner(new SpinnerNumberModel(2, 1, 10, 1));
        JCheckBox auto = new JCheckBox("Auto-classify (Bloom + Difficulty)", true); auto.setOpaque(false); auto.setFont(Theme.font(Font.BOLD, 12.5f)); auto.setForeground(Theme.TEXT); auto.setFocusPainted(false);
        JPanel form = Kit.vbox();
        Kit.formRow(form, "MODULE", module); Kit.formRow(form, "TOPIC", topic); Kit.formRow(form, "QUESTION TYPE", type);
        Kit.formRow(form, "PREFERRED DIFFICULTY", diff); Kit.formRow(form, "PREFERRED BLOOM LEVEL", bloom); Kit.formRow(form, "NUMBER OF QUESTIONS", count);
        form.add(Kit.left(auto)); form.add(Box.createVerticalStrut(16));
        Widgets.Btn gen = new Widgets.Btn("✦  Generate questions"); gen.setAlignmentX(LEFT_ALIGNMENT); form.add(gen);

        JPanel results = Kit.vbox(); results.add(emptyState("✦", "Nothing generated yet", "Pick a topic on the left and press Generate.\nEach question is checked against the bank for duplicates."));
        gen.addActionListener(e -> {
            try {
                String tp = (String) topic.getSelectedItem(); QuestionType qt = (QuestionType) type.getSelectedItem();
                List<Question> list = QuestionGenerator.generateQuestions(tp, (String) module.getSelectedItem(), tp, (Integer) count.getValue(), qt, (DifficultyLevel) diff.getSelectedItem(), (BloomLevel) bloom.getSelectedItem());
                results.removeAll();
                if (list.isEmpty()) { results.add(emptyState("!", "No template for this combination", "Try a different topic or question type.")); }
                for (Question q : list) {
                    if (auto.isSelected()) { BloomLevel b = BloomClassifier.classify(q.getQuestionText()); q.setBloomLevel(b); q.setDifficulty(DifficultyClassifier.classify(q.getQuestionText(), q.getQuestionType(), b)); }
                    results.add(Kit.left(generatedCard(q))); results.add(Box.createVerticalStrut(14));
                }
                results.revalidate(); results.repaint(); Kit.toast(this, list.size() + " question(s) generated", Theme.PRIMARY);
            } catch (Exception ex) { Kit.toast(this, "Generation error: " + ex.getMessage(), Theme.BAD); }
        });
        Widgets.Card formCard = Kit.section("Configuration", "Rule-based template engine", form);
        JPanel formWrap = new JPanel(new BorderLayout()); formWrap.setOpaque(false); formWrap.add(formCard, BorderLayout.NORTH); formWrap.setPreferredSize(new Dimension(360, 10));
        JPanel wrap = new JPanel(new BorderLayout(18, 0)); wrap.setOpaque(false); wrap.add(formWrap, BorderLayout.WEST);
        Kit.Page rp = newPage(); rp.setBorder(new EmptyBorder(0, 0, 24, 6)); rp.addRow(results, 0); wrap.add(Widgets.scroll(rp), BorderLayout.CENTER);
        return wrap;
    }

    private JComponent emptyState(String icon, String title, String text) {
        Widgets.Card c = new Widgets.Card(); c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS)); c.setBorder(new EmptyBorder(48, 20, 48, 20));
        JLabel i = Kit.label(icon, Font.BOLD, 40f, Theme.PRIMARY); i.setAlignmentX(CENTER_ALIGNMENT); c.add(i); c.add(Box.createVerticalStrut(10));
        JLabel t = Kit.label(title, Font.BOLD, 17f, Theme.TEXT); t.setAlignmentX(CENTER_ALIGNMENT); c.add(t); c.add(Box.createVerticalStrut(6));
        for (String line : text.split("\n")) { JLabel l = Kit.muted(line); l.setAlignmentX(CENTER_ALIGNMENT); c.add(l); }
        c.setAlignmentX(LEFT_ALIGNMENT); return c;
    }

    private JComponent generatedCard(Question q) {
        Widgets.Card c = new Widgets.Card(); c.setLayout(new BorderLayout(0, 12));
        c.add(questionView(q, contentW() - 378 - 18 - 70, true), BorderLayout.CENTER);
        List<DuplicateDetector.SimilarityReport> reps = DuplicateDetector.checkAgainstBank(q, dm.getQuestionBank().getQuestions());
        double top = 0; String with = ""; for (DuplicateDetector.SimilarityReport r : reps) if (r.getSimilarityScore() > top) { top = r.getSimilarityScore(); with = r.getQuestionB().getQuestionId(); }
        boolean review = !reps.isEmpty();
        JPanel foot = new JPanel(new BorderLayout()); foot.setOpaque(false);
        foot.add(new Widgets.Pill(review ? "REVIEW · " + String.format("%.0f%%", top * 100) + " similar to " + with : "DUPLICATE CHECK PASSED", review ? Theme.WARN : Theme.GOOD), BorderLayout.WEST);
        Widgets.Btn add = new Widgets.Btn("＋  Add to bank", review ? Widgets.Btn.Kind.GHOST : Widgets.Btn.Kind.SUCCESS);
        add.addActionListener(e -> { if (dm.getQuestionBank().addQuestion(q)) { dm.saveAllData(); add.setText("✔  Added"); add.setEnabled(false); Kit.toast(this, q.getQuestionId() + " added to the bank", Theme.GOOD); } else Kit.toast(this, "Could not add (ID already exists)", Theme.WARN); });
        JPanel r = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0)); r.setOpaque(false); r.add(add); foot.add(r, BorderLayout.EAST);
        c.add(foot, BorderLayout.SOUTH); return c;
    }

    /** Shared question presentation used by generator and bank. */
    private JComponent questionView(Question q, int width, boolean rationale) {
        JPanel v = Kit.vbox();
        JPanel pills = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0)); pills.setOpaque(false);
        pills.add(Kit.label(q.getQuestionId(), Font.BOLD, 13f, Theme.PRIMARY));
        pills.add(new Widgets.Pill(Widgets.pretty(q.getQuestionType().name()), Theme.PRIMARY));
        pills.add(new Widgets.Pill(Widgets.pretty(q.getDifficulty().name()), Theme.difficulty(q.getDifficulty().name())));
        pills.add(new Widgets.Pill(Widgets.pretty(q.getBloomLevel().name()), Theme.bloom(q.getBloomLevel().name())));
        pills.add(new Widgets.Pill(q.getMarks() + " marks", Theme.ACCENT));
        v.add(Kit.left(pills)); v.add(Box.createVerticalStrut(10));
        v.add(Kit.left(Kit.wrap(q.getQuestionText(), width, Font.BOLD, 14.5f, Theme.TEXT))); v.add(Box.createVerticalStrut(10));
        if (q.getQuestionType() == QuestionType.MCQ) {
            String[] L = {"A", "B", "C", "D"}, T = {q.getOptionA(), q.getOptionB(), q.getOptionC(), q.getOptionD()};
            for (int i = 0; i < 4; i++) {
                boolean ok = q.getCorrectAnswer() != null && q.getCorrectAnswer().trim().toUpperCase().startsWith(L[i]);
                JPanel row = new JPanel(new BorderLayout(10, 0)) { @Override protected void paintComponent(Graphics g0) { Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
                    g.setColor(ok ? Theme.alpha(Theme.GOOD, Theme.dark ? 45 : 28) : Theme.SURFACE_ALT); g.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12)); g.dispose(); } };
                row.setOpaque(false); row.setBorder(new EmptyBorder(7, 12, 7, 12));
                row.add(Kit.label(L[i], Font.BOLD, 12.5f, ok ? Theme.GOOD : Theme.MUTED), BorderLayout.WEST); row.add(Kit.wrap(T[i], width - 70, ok ? Font.BOLD : Font.PLAIN, 13f, Theme.TEXT), BorderLayout.CENTER);
                if (ok) row.add(Kit.label("✔", Font.BOLD, 13f, Theme.GOOD), BorderLayout.EAST);
                v.add(Kit.left(row)); v.add(Box.createVerticalStrut(6));
            }
        } else if (q.getCorrectAnswer() != null) {
            v.add(Kit.left(Kit.wrap("Model answer: " + q.getCorrectAnswer(), width, Font.PLAIN, 13f, Theme.GOOD))); v.add(Box.createVerticalStrut(6));
        }
        if (q.getExplanation() != null && !q.getExplanation().isEmpty()) { v.add(Kit.left(Kit.wrap("Explanation: " + q.getExplanation(), width, Font.PLAIN, 12.5f, Theme.MUTED))); v.add(Box.createVerticalStrut(6)); }
        if (rationale) {
            DifficultyClassifier.DifficultyAnalysis da = DifficultyClassifier.analyze(q.getQuestionText(), q.getQuestionType(), q.getBloomLevel());
            v.add(Kit.left(Kit.wrap("Bloom engine: " + BloomClassifier.getClassificationRationale(q.getQuestionText(), q.getBloomLevel()), width, Font.PLAIN, 12f, Theme.PRIMARY)));
            v.add(Kit.left(Kit.wrap("Difficulty engine (score " + da.getScore() + "): " + da.getRationale(), width, Font.PLAIN, 12f, Theme.PRIMARY)));
        }
        return v;
    }

    // ============================================================== Bank
    private final DefaultTableModel bankModel = new DefaultTableModel(new String[]{"ID", "Topic", "Type", "Difficulty", "Bloom", "Question"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };

    private JComponent bank() {
        JTextField search = Widgets.field(new JTextField() {
            @Override protected void paintComponent(Graphics g0) { super.paintComponent(g0);
                if (getText().isEmpty()) { Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g); g.setColor(Theme.MUTED); g.setFont(Theme.font(0, 13.5f));
                    g.drawString("🔍  Search question text, topic or explanation (KMP string matching)…".replace("🔍  ", "⌕  "), 14, (getHeight() + g.getFontMetrics().getAscent() - g.getFontMetrics().getDescent()) / 2); g.dispose(); } } });
        JComboBox<String> mod = Widgets.combo(new JComboBox<>(new String[]{"Module: all", "Module 1", "Module 2", "Module 3"}));
        JComboBox<String> dif = Widgets.combo(new JComboBox<>(new String[]{"Difficulty: all", "EASY", "MEDIUM", "HARD"}));
        JComboBox<String> typ = Widgets.combo(new JComboBox<>(new String[]{"Type: all", "MCQ", "SHORT_ANSWER", "DESCRIPTIVE"}));
        JComboBox<String> blm = Widgets.combo(new JComboBox<>(new String[]{"Bloom: all", "REMEMBER", "UNDERSTAND", "APPLY", "ANALYZE", "EVALUATE", "CREATE"}));
        JLabel countLbl = Kit.label("", Font.BOLD, 12.5f, Theme.MUTED);
        JTable table = new JTable(bankModel); Widgets.styleTable(table); table.setAutoCreateRowSorter(true);
        int[] w = {74, 124, 74, 84, 104, 220}; for (int i = 0; i < w.length; i++) { javax.swing.table.TableColumn tc = table.getColumnModel().getColumn(i); tc.setPreferredWidth(w[i]); if (i < w.length - 1) { tc.setMinWidth(w[i]); tc.setMaxWidth(w[i]); } }
        table.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        JPanel detail = new JPanel(new BorderLayout()); detail.setOpaque(false);
        final List<Question> shown = new ArrayList<>();
        Runnable refresh = () -> {
            String s = search.getText().trim(); List<Question> base = s.isEmpty() ? dm.getQuestionBank().getQuestions() : dm.getQuestionBank().searchQuestion(s);
            shown.clear(); bankModel.setRowCount(0);
            for (Question q : base) {
                if (mod.getSelectedIndex() > 0 && !q.getModule().equals(mod.getSelectedItem())) continue;
                if (dif.getSelectedIndex() > 0 && !q.getDifficulty().name().equals(dif.getSelectedItem())) continue;
                if (typ.getSelectedIndex() > 0 && !q.getQuestionType().name().equals(typ.getSelectedItem())) continue;
                if (blm.getSelectedIndex() > 0 && !q.getBloomLevel().name().equals(blm.getSelectedItem())) continue;
                shown.add(q); bankModel.addRow(new Object[]{q.getQuestionId(), q.getTopic(), q.getQuestionType(), q.getDifficulty(), q.getBloomLevel(), q.getQuestionText()});
            }
            countLbl.setText(shown.size() + " of " + dm.getQuestionBank().getQuestionCount() + " questions");
        };
        Runnable showDetail = () -> {
            detail.removeAll(); int r = table.getSelectedRow();
            if (r < 0) { detail.add(emptyState("☰", "Select a question", "Click any row to inspect it here."), BorderLayout.NORTH); }
            else {
                Question q = dm.getQuestionBank().findQuestionById((String) bankModel.getValueAt(table.convertRowIndexToModel(r), 0));
                if (q != null) {
                    Widgets.Card c = new Widgets.Card(); c.setLayout(new BorderLayout(0, 14)); c.add(questionView(q, 300, false), BorderLayout.CENTER);
                    JPanel meta = Kit.vbox(); meta.add(Kit.left(Kit.muted(q.getModule() + "  ·  " + q.getTopic())));
                    Widgets.Btn del = new Widgets.Btn("Delete question", Widgets.Btn.Kind.DANGER);
                    del.addActionListener(e -> { if (JOptionPane.showConfirmDialog(this, "Delete " + q.getQuestionId() + " permanently?", "Confirm delete", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                        dm.getQuestionBank().removeQuestion(q.getQuestionId()); dm.saveAllData(); Kit.toast(this, q.getQuestionId() + " deleted", Theme.BAD); table.clearSelection(); }});
                    meta.add(Box.createVerticalStrut(10)); meta.add(Kit.left(del)); c.add(meta, BorderLayout.SOUTH); detail.add(c, BorderLayout.NORTH);
                }
            }
            detail.revalidate(); detail.repaint();
        };
        table.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) showDetail.run(); });
        bankModel.addTableModelListener(e -> { if (table.getSelectedRow() < 0) showDetail.run(); });
        search.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() { void c() { refresh.run(); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { c(); } public void removeUpdate(javax.swing.event.DocumentEvent e) { c(); } public void changedUpdate(javax.swing.event.DocumentEvent e) { c(); } });
        for (JComboBox<String> cb : Arrays.asList(mod, dif, typ, blm)) cb.addActionListener(e -> refresh.run());

        Widgets.Btn scan = new Widgets.Btn("⚠  Scan duplicates", Widgets.Btn.Kind.GHOST); scan.addActionListener(e -> scanDuplicates(scan));
        Widgets.Btn export = new Widgets.Btn("⇩  Export CSV", Widgets.Btn.Kind.GHOST); export.addActionListener(e -> exportCsv(shown));
        search.setPreferredSize(new Dimension(300, 40));
        JPanel filters = new JPanel(new GridBagLayout()); filters.setOpaque(false); GridBagConstraints g = new GridBagConstraints(); g.fill = GridBagConstraints.HORIZONTAL; g.insets = new Insets(0, 0, 0, 10);
        g.gridx = 0; g.weightx = 1.0; filters.add(mod, g); g.gridx = 1; filters.add(dif, g); g.gridx = 2; filters.add(typ, g); g.gridx = 3; filters.add(blm, g);
        g.gridx = 4; g.weightx = 0; filters.add(scan, g); g.gridx = 5; g.insets = new Insets(0, 0, 0, 0); filters.add(export, g);
        JPanel top = Kit.vbox(); top.add(Kit.left(search)); search.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40)); top.add(Box.createVerticalStrut(10)); top.add(Kit.left(filters));
        filters.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        Widgets.Card bar = new Widgets.Card(); bar.setBorder(new EmptyBorder(14, 16, 12, 16)); bar.setLayout(new BorderLayout(0, 8)); bar.add(top, BorderLayout.CENTER);
        JPanel sub = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); sub.setOpaque(false); sub.add(new Widgets.Pill("KMP-powered search", Theme.PRIMARY)); sub.add(countLbl); bar.add(sub, BorderLayout.SOUTH);

        JScrollPane sp = new JScrollPane(table); sp.setBorder(BorderFactory.createEmptyBorder()); sp.getViewport().setBackground(Theme.SURFACE);
        sp.getVerticalScrollBar().setUI(new Widgets.ThinScroll()); sp.getHorizontalScrollBar().setUI(new Widgets.ThinScroll());
        Widgets.Card tableCard = new Widgets.Card(); tableCard.setBorder(new EmptyBorder(6, 6, 6, 6)); tableCard.setLayout(new BorderLayout()); tableCard.add(sp);
        JScrollPane dsp = Widgets.scroll(wrapDetail(detail)); dsp.setPreferredSize(new Dimension(372, 10));
        JPanel body = new JPanel(new BorderLayout(16, 0)); body.setOpaque(false); body.add(tableCard, BorderLayout.CENTER); body.add(dsp, BorderLayout.EAST);
        JPanel root = new JPanel(new BorderLayout(0, 16)); root.setOpaque(false); root.setBorder(new EmptyBorder(0, 0, 22, 0)); root.add(bar, BorderLayout.NORTH); root.add(body, BorderLayout.CENTER);
        refresh.run(); showDetail.run(); return root;
    }
    private JComponent wrapDetail(JComponent d) { Kit.Page p = new Kit.Page(); p.setBorder(new EmptyBorder(0, 0, 8, 6)); p.addRow(d, 0); return p; }

    private void scanDuplicates(JComponent src) {
        Kit.toast(this, "Scanning bank…", Theme.PRIMARY);
        new SwingWorker<List<DuplicateDetector.SimilarityReport>, Void>() {
            @Override protected List<DuplicateDetector.SimilarityReport> doInBackground() { return DuplicateDetector.scanAllPairs(dm.getQuestionBank().getQuestions()); }
            @Override protected void done() { try {
                List<DuplicateDetector.SimilarityReport> rs = new ArrayList<>(); for (DuplicateDetector.SimilarityReport r : get()) if (r.getVerdict() != DuplicateDetector.MatchVerdict.DIFFERENT) rs.add(r);
                DefaultTableModel m = new DefaultTableModel(new String[]{"Question A", "Question B", "Percentage", "Verdict"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
                for (DuplicateDetector.SimilarityReport r : rs) m.addRow(new Object[]{r.getQuestionA().getQuestionId(), r.getQuestionB().getQuestionId(), String.format("%.0f%%", r.getSimilarityScore() * 100), r.getVerdict()});
                JDialog d = new JDialog(SmartAssessmentUI.this, "Duplicate audit", true); JPanel c = new JPanel(new BorderLayout(0, 12)); c.setBackground(Theme.BG); c.setBorder(new EmptyBorder(18, 18, 18, 18));
                JTable t = new JTable(m); Widgets.styleTable(t); JScrollPane sp = new JScrollPane(t); sp.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
                c.add(Kit.label(rs.isEmpty() ? "No duplicates or near-duplicates found ✔" : rs.size() + " flagged pair(s)", Font.BOLD, 16f, rs.isEmpty() ? Theme.GOOD : Theme.WARN), BorderLayout.NORTH); c.add(sp);
                d.setContentPane(c); d.setSize(560, 420); d.setLocationRelativeTo(SmartAssessmentUI.this); d.setVisible(true);
            } catch (Exception ex) { Kit.toast(SmartAssessmentUI.this, "Scan failed", Theme.BAD); } }
        }.execute();
    }

    private void exportCsv(List<Question> qs) {
        JFileChooser fc = new JFileChooser(); fc.setSelectedFile(new File("question-bank.csv"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try (PrintWriter w = new PrintWriter(fc.getSelectedFile(), "UTF-8")) {
            w.println("ID,Module,Topic,Type,Difficulty,Bloom,Marks,Question,Answer");
            for (Question q : qs) w.println(csv(q.getQuestionId()) + "," + csv(q.getModule()) + "," + csv(q.getTopic()) + "," + q.getQuestionType() + "," + q.getDifficulty() + "," + q.getBloomLevel() + "," + q.getMarks() + "," + csv(q.getQuestionText()) + "," + csv(q.getCorrectAnswer()));
            Kit.toast(this, "Exported " + qs.size() + " questions", Theme.GOOD);
        } catch (IOException ex) { Kit.toast(this, "Export failed: " + ex.getMessage(), Theme.BAD); }
    }
    private static String csv(String s) { return "\"" + (s == null ? "" : s.replace("\"", "\"\"")) + "\""; }

    // ============================================================ Builder
    private JComponent builder() {
        JTextField title = Widgets.field(new JTextField("Advanced Algorithms – Unit Test"));
        JComboBox<String> mod = Widgets.combo(new JComboBox<>(new String[]{"ALL", "Module 1", "Module 2", "Module 3"}));
        JComboBox<String> typ = Widgets.combo(new JComboBox<>(new String[]{"Any type", "MCQ", "SHORT_ANSWER", "DESCRIPTIVE"}));
        JSpinner cnt = Widgets.spinner(new SpinnerNumberModel(10, 1, 50, 1)); JSpinner dur = Widgets.spinner(new SpinnerNumberModel(45, 5, 240, 5));
        JSlider[] sl = {slider(30), slider(50), slider(20)}; JLabel total = Kit.label("", Font.BOLD, 13f, Theme.GOOD);
        JLabel[] pv = {Kit.label("30%", Font.BOLD, 12.5f, Theme.GOOD), Kit.label("50%", Font.BOLD, 12.5f, Theme.WARN), Kit.label("20%", Font.BOLD, 12.5f, Theme.BAD)};
        Widgets.Btn go = new Widgets.Btn("▤  Generate balanced assessment");
        Runnable upd = () -> { int s = sl[0].getValue() + sl[1].getValue() + sl[2].getValue(); for (int i = 0; i < 3; i++) pv[i].setText(sl[i].getValue() + "%");
            total.setText("Total: " + s + "%" + (s == 100 ? "  ✔" : "  (must equal 100)")); total.setForeground(s == 100 ? Theme.GOOD : Theme.BAD); go.setEnabled(s == 100); };
        for (JSlider s : sl) s.addChangeListener(e -> upd.run());
        JCheckBox auto = new JCheckBox("Auto-balance Bloom levels from the bank", true); auto.setOpaque(false); auto.setFont(Theme.font(Font.BOLD, 12.5f)); auto.setForeground(Theme.TEXT); auto.setFocusPainted(false);
        JPanel form = Kit.vbox(); Kit.formRow(form, "ASSESSMENT TITLE", title); Kit.formRow(form, "MODULE", mod); Kit.formRow(form, "QUESTION TYPE", typ);
        JPanel two = new JPanel(new GridLayout(1, 2, 12, 0)); two.setOpaque(false); JPanel a = Kit.vbox(), b = Kit.vbox(); Kit.formRow(a, "QUESTIONS", cnt); Kit.formRow(b, "DURATION (MIN)", dur); two.add(a); two.add(b); form.add(Kit.left(two));
        String[] names = {"Easy", "Medium", "Hard"}; Color[] cols = {Theme.GOOD, Theme.WARN, Theme.BAD};
        form.add(Kit.left(Kit.label("DIFFICULTY MIX", Font.BOLD, 12f, Theme.MUTED))); form.add(Box.createVerticalStrut(4));
        for (int i = 0; i < 3; i++) { JPanel r = new JPanel(new BorderLayout(8, 0)); r.setOpaque(false); r.add(Kit.label(names[i], Font.BOLD, 12.5f, cols[i]), BorderLayout.WEST); ((JLabel) r.getComponent(0)).setPreferredSize(new Dimension(60, 20)); r.add(sl[i]); r.add(pv[i], BorderLayout.EAST); r.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30)); form.add(Kit.left(r)); }
        form.add(Box.createVerticalStrut(6)); form.add(Kit.left(total)); form.add(Box.createVerticalStrut(10));
        JPanel presets = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); presets.setOpaque(false);
        presets.add(preset("Balanced", sl, 30, 50, 20)); presets.add(preset("Easy", sl, 60, 30, 10)); presets.add(preset("Challenging", sl, 10, 40, 50)); form.add(Kit.left(presets));
        form.add(Box.createVerticalStrut(14)); form.add(Kit.left(auto)); form.add(Box.createVerticalStrut(16)); go.setAlignmentX(LEFT_ALIGNMENT); form.add(go); upd.run();

        JPanel out = Kit.vbox(); out.add(emptyState("▤", "Your paper will appear here", "Set the constraints and press Generate.\nIf the bank can't satisfy them you'll get an exact deficit report."));
        go.addActionListener(e -> {
            String module = (String) mod.getSelectedItem(); QuestionType qt = typ.getSelectedIndex() == 0 ? null : QuestionType.valueOf((String) typ.getSelectedItem()); int n = (Integer) cnt.getValue();
            Map<DifficultyLevel, Integer> dd = new EnumMap<>(DifficultyLevel.class); dd.put(DifficultyLevel.EASY, sl[0].getValue()); dd.put(DifficultyLevel.MEDIUM, sl[1].getValue()); dd.put(DifficultyLevel.HARD, sl[2].getValue());
            Map<BloomLevel, Integer> bd = new EnumMap<>(BloomLevel.class);
            List<Question> pool = new ArrayList<>(); for (Question q : dm.getQuestionBank().getQuestions()) if ((module.equals("ALL") || q.getModule().equals(module)) && (qt == null || q.getQuestionType() == qt)) pool.add(q);
            for (BloomLevel bl : BloomLevel.values()) { int c = 0; for (Question q : pool) if (q.getBloomLevel() == bl) c++; bd.put(bl, pool.isEmpty() ? 0 : (int) Math.round(100.0 * c / pool.size())); }
            AssessmentGenerator.GenerationResult r = AssessmentGenerator.generate(dm.getQuestionBank(), title.getText().trim().isEmpty() ? "Untitled Assessment" : title.getText().trim(), module, null, n, (Integer) dur.getValue(), dd, bd, qt);
            out.removeAll();
            if (r.isSuccess()) { out.add(Kit.left(paperView(r))); Kit.toast(this, "Assessment generated — " + r.getSelectedQuestions().size() + " questions", Theme.GOOD); }
            else {
                JPanel err = Kit.vbox(); for (String s : r.getDeficitErrors()) { err.add(Kit.left(insight("b", "Constraint not satisfiable", s))); err.add(Box.createVerticalStrut(8)); }
                err.add(Kit.left(Kit.wrap("Tip: reduce the number of questions, relax the difficulty mix, or generate more questions to fill the gap.", contentW() - 378 - 18 - 80, 0, 12.5f, Theme.MUTED)));
                out.add(Kit.left(Kit.section("Could not build this paper", "The generator refuses to silently produce an unbalanced exam", err)));
            }
            out.revalidate(); out.repaint();
        });
        Widgets.Card fc = Kit.section("Constraints", "Difficulty & Bloom balanced selection", form); JPanel fw = new JPanel(new BorderLayout()); fw.setOpaque(false); fw.add(fc, BorderLayout.NORTH); fw.setPreferredSize(new Dimension(380, 10));
        JPanel wrap = new JPanel(new BorderLayout(18, 0)); wrap.setOpaque(false); wrap.add(fw, BorderLayout.WEST);
        Kit.Page rp = newPage(); rp.setBorder(new EmptyBorder(0, 0, 24, 6)); rp.addRow(out, 0); wrap.add(Widgets.scroll(rp), BorderLayout.CENTER); return wrap;
    }

    private JSlider slider(int v) { JSlider s = new JSlider(0, 100, v); s.setOpaque(false); s.setFocusable(false); return s; }
    private JComponent preset(String name, JSlider[] sl, int a, int b, int c) {
        Widgets.Btn x = new Widgets.Btn(name, Widgets.Btn.Kind.GHOST); x.setFont(Theme.font(Font.BOLD, 12f)); x.setBorder(new EmptyBorder(6, 12, 6, 12));
        x.addActionListener(e -> { sl[0].setValue(a); sl[1].setValue(b); sl[2].setValue(c); }); return x;
    }

    private JComponent paperView(AssessmentGenerator.GenerationResult r) {
        Assessment as = r.getAssessment(); List<Question> qs = r.getSelectedQuestions();
        JPanel v = Kit.vbox();
        JPanel chips = new JPanel(new GridLayout(1, 4, 12, 0)); chips.setOpaque(false);
        chips.add(Kit.chip("ASSESSMENT ID", as.getAssessmentId(), Theme.PRIMARY)); chips.add(Kit.chip("QUESTIONS", String.valueOf(qs.size()), Theme.ACCENT));
        chips.add(Kit.chip("TOTAL MARKS", String.valueOf(as.getTotalMarks()), Theme.GOOD)); chips.add(Kit.chip("DURATION", as.getDurationMinutes() + " min", Theme.WARN));
        v.add(Kit.left(chips)); v.add(Box.createVerticalStrut(14));
        v.add(Kit.left(Kit.cols(new double[]{0.45, 0.55}, 14, Kit.section("Difficulty achieved", null, new Widgets.Donut(countDifficulty(qs), diffColors(), "questions")),
            Kit.section("Bloom coverage", null, new Widgets.Bars(nonZero(countBloom(qs)), Math.max(1, max(countBloom(qs))), false, (k, x) -> Theme.bloom(k)))))); v.add(Box.createVerticalStrut(14));
        JPanel list = Kit.vbox(); int n = 1;
        for (Question q : qs) {
            JPanel row = new JPanel(new BorderLayout(12, 0)); row.setOpaque(false); row.setBorder(new EmptyBorder(8, 0, 8, 0));
            row.add(Kit.label(String.valueOf(n++), Font.BOLD, 18f, Theme.PRIMARY), BorderLayout.WEST); ((JLabel) row.getComponent(0)).setPreferredSize(new Dimension(30, 20));
            JPanel t = Kit.vbox(); t.add(Kit.left(Kit.wrap(q.getQuestionText(), contentW() - 378 - 18 - 140, Font.BOLD, 13.5f, Theme.TEXT)));
            JPanel pl = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0)); pl.setOpaque(false); pl.add(Kit.label(q.getQuestionId(), Font.BOLD, 11.5f, Theme.MUTED));
            pl.add(new Widgets.Pill(Widgets.pretty(q.getDifficulty().name()), Theme.difficulty(q.getDifficulty().name()))); pl.add(new Widgets.Pill(Widgets.pretty(q.getBloomLevel().name()), Theme.bloom(q.getBloomLevel().name()))); pl.add(new Widgets.Pill(q.getMarks() + " marks", Theme.ACCENT));
            t.add(Box.createVerticalStrut(4)); t.add(Kit.left(pl)); row.add(t); list.add(Kit.left(row));
            JSeparator sep = new JSeparator(); sep.setForeground(Theme.BORDER); sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1)); list.add(sep);
        }
        Widgets.Btn save = new Widgets.Btn("✔  Save assessment", Widgets.Btn.Kind.SUCCESS);
        save.addActionListener(e -> { dm.addAssessment(as); dm.saveAllData(); save.setText("✔  Saved"); save.setEnabled(false); Kit.toast(this, as.getAssessmentId() + " saved — ready for Exam Mode", Theme.GOOD); });
        Widgets.Btn exp = new Widgets.Btn("⇩  Export paper & answer key", Widgets.Btn.Kind.GHOST); exp.addActionListener(e -> exportPaper(as, qs));
        Widgets.Btn take = new Widgets.Btn("✎  Take exam", Widgets.Btn.Kind.GHOST); take.addActionListener(e -> { dm.addAssessment(as); dm.saveAllData(); exam = null; go(4); });
        JPanel acts = Kit.flow(10, 0, save, exp, take);
        Widgets.Card paper = Kit.section(as.getTitle(), as.getModule() + "  ·  " + LocalDate.now(), list); paper.add(acts, BorderLayout.SOUTH);
        v.add(Kit.left(paper)); return v;
    }
    private Map<String, Double> nonZero(Map<String, Double> m) { Map<String, Double> r = new LinkedHashMap<>(); for (Map.Entry<String, Double> e : m.entrySet()) if (e.getValue() > 0) r.put(e.getKey(), e.getValue()); return r; }

    private void exportPaper(Assessment as, List<Question> qs) {
        JFileChooser fc = new JFileChooser(); fc.setSelectedFile(new File(as.getAssessmentId() + "-paper.txt")); if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try (PrintWriter w = new PrintWriter(fc.getSelectedFile(), "UTF-8")) {
            w.println(as.getTitle()); w.println("Duration: " + as.getDurationMinutes() + " minutes    Total marks: " + as.getTotalMarks()); w.println("==================================================");
            int n = 1; for (Question q : qs) { w.println("\nQ" + n++ + ". " + q.getQuestionText() + "  [" + q.getMarks() + " marks]");
                if (q.getQuestionType() == QuestionType.MCQ) { w.println("   A. " + q.getOptionA()); w.println("   B. " + q.getOptionB()); w.println("   C. " + q.getOptionC()); w.println("   D. " + q.getOptionD()); } }
            w.println("\n\n==================== ANSWER KEY ====================");
            n = 1; for (Question q : qs) w.println("Q" + n++ + ": " + q.getCorrectAnswer() + "   (" + q.getDifficulty() + " / " + q.getBloomLevel() + ")");
            Kit.toast(this, "Paper exported", Theme.GOOD);
        } catch (IOException ex) { Kit.toast(this, "Export failed: " + ex.getMessage(), Theme.BAD); }
    }

    // =========================================================== Analytics
    private JComponent analytics() {
        Kit.Page p = newPage(); AnalyticsService.OverallAnalytics an = AnalyticsService.computeAnalytics(dm.getResults());
        if (an.getTotalAssessmentsTaken() == 0) {
            JComponent es = emptyState("◔", "No results to analyse yet", "Run a student through Exam Mode and the analytics will appear here.");
            Widgets.Btn b = new Widgets.Btn("✎  Go to Exam Mode"); b.addActionListener(e -> go(4)); p.addRow(es); p.addRow(Kit.left(b)); return scrolled(p);
        }
        p.addRow(Kit.cols(new double[]{0.24, 0.76}, 16, gaugeCard(an.getAveragePercentage()), Kit.even(3, 16,
            Kit.statCard("↑", "HIGHEST", new Widgets.CountLabel(an.getHighestPercentage(), "%", Theme.TEXT), Theme.GOOD, "best submission"),
            Kit.statCard("↓", "LOWEST", new Widgets.CountLabel(an.getLowestPercentage(), "%", Theme.TEXT), Theme.BAD, "weakest submission"),
            Kit.statCard("◎", "ACCURACY", new Widgets.CountLabel(an.getAverageAccuracy(), "%", Theme.TEXT), Theme.ACCENT, an.getTotalAssessmentsTaken() + (an.getTotalAssessmentsTaken() == 1 ? " submission" : " submissions")))));
        p.addRow(Kit.even(2, 16,
            Kit.section("Performance by module", "Average % of marks earned", new Widgets.Bars(sorted(an.getModuleAverages()), 100, true, (k, v) -> Theme.scoreColor(v))),
            Kit.section("Performance by difficulty", "Does difficulty track results?", new Widgets.Bars(an.getDifficultyAverages(), 100, true, (k, v) -> Theme.difficulty(k)))));
        p.addRow(Kit.even(2, 16,
            Kit.section("Cognitive level (Bloom)", "Where do students struggle cognitively?", new Widgets.Bars(sorted(an.getBloomAverages()), 100, true, (k, v) -> Theme.bloom(k))),
            Kit.section("Topic mastery", "Red below the 65% intervention threshold", new Widgets.Bars(sorted(an.getTopicAverages()), 100, true, (k, v) -> Theme.scoreColor(v)))));
        JPanel weak = Kit.vbox();
        if (an.getWeakAreas().isEmpty()) weak.add(Kit.left(insight("g", "No weak areas", "Every tested topic is above the 65% threshold. Great teaching!")));
        for (String w : an.getWeakAreas()) { weak.add(Kit.left(insight("b", "Needs attention", w))); weak.add(Box.createVerticalStrut(8)); }
        p.addRow(Kit.section("Diagnostic weak areas", "Auto-detected topics scoring under 65%", weak));

        DefaultTableModel m = new DefaultTableModel(new String[]{"Rank", "Student", "Assessment", "Score", "Percentage", "Date"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        List<Performance> rs = new ArrayList<>(dm.getResults()); rs.sort((a, b) -> Double.compare(b.getPercentage(), a.getPercentage())); int rank = 1;
        for (Performance r : rs) m.addRow(new Object[]{"#" + rank++, r.getStudentName(), r.getAssessmentId(), r.getScore() + " / " + r.getTotalMarks(), String.format("%.0f%%", r.getPercentage()), r.getSubmissionDate()});
        JComponent lb = tableCard("Leaderboard", "All graded submissions ranked by score", new JTable(m), Math.min(8, Math.max(1, m.getRowCount())));
        p.addRow(lb);
        Widgets.Btn ex = new Widgets.Btn("⇩  Export results CSV", Widgets.Btn.Kind.GHOST); ex.addActionListener(e -> exportResults(rs)); p.addRow(Kit.left(ex), 0);
        return scrolled(p);
    }
    private JComponent gaugeCard(double v) { Widgets.Card c = new Widgets.Card(); c.setLayout(new BorderLayout()); c.add(Kit.label("Cohort average", Font.BOLD, 14f, Theme.TEXT), BorderLayout.NORTH); c.add(new Widgets.Gauge(v, "average")); return c; }
    private Map<String, Double> sorted(Map<String, Double> m) {
        List<Map.Entry<String, Double>> l = new ArrayList<>(m.entrySet()); l.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        Map<String, Double> r = new LinkedHashMap<>(); for (Map.Entry<String, Double> e : l) r.put(e.getKey(), e.getValue()); return r;
    }
    private void exportResults(List<Performance> rs) {
        JFileChooser fc = new JFileChooser(); fc.setSelectedFile(new File("results.csv")); if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try (PrintWriter w = new PrintWriter(fc.getSelectedFile(), "UTF-8")) {
            w.println("ResultId,Student,Assessment,Score,Total,Percentage,Accuracy,Date");
            for (Performance r : rs) w.println(r.getResultId() + "," + csv(r.getStudentName()) + "," + r.getAssessmentId() + "," + r.getScore() + "," + r.getTotalMarks() + "," + String.format("%.2f", r.getPercentage()) + "," + String.format("%.2f", r.getAccuracy()) + "," + r.getSubmissionDate());
            Kit.toast(this, "Results exported", Theme.GOOD);
        } catch (IOException ex) { Kit.toast(this, "Export failed", Theme.BAD); }
    }

    // ================================================================ main
    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on"); System.setProperty("swing.aatext", "true");
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); } catch (Exception ignored) {}
            UIManager.put("ToolTip.font", Theme.font(0, 12f)); UIManager.put("OptionPane.messageFont", Theme.font(0, 13.5f)); UIManager.put("OptionPane.buttonFont", Theme.font(Font.BOLD, 12.5f));
            new SmartAssessmentUI().setVisible(true);
        });
    }
}
