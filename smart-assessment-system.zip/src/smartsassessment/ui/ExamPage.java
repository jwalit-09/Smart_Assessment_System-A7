package smartsassessment.ui;

import smartsassessment.model.*;
import smartsassessment.service.AssessmentEvaluator;
import smartsassessment.storage.DataManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.*;
import java.util.List;

/** Student-facing exam flow: setup -> timed exam with question palette -> graded result review. */
public class ExamPage extends JPanel {
    private final DataManager dm;
    private final CardLayout cl = new CardLayout();
    private final JPanel root = new JPanel(cl);
    private Student student; private Assessment assessment; private List<Question> qs = new ArrayList<>();
    private final Map<String, String> answers = new HashMap<>();
    private int idx; private long endAt; private javax.swing.Timer clock; private JLabel clockLabel;
    private JPanel questionHolder, paletteHolder; private JLabel progressLabel;

    public ExamPage(DataManager dm) {
        this.dm = dm; setOpaque(false); setLayout(new BorderLayout()); root.setOpaque(false); add(root);
        showSetup();
    }

    private void swap(String name, JComponent c) {
        JScrollPane sp = Widgets.scroll(wrapPage(c)); root.add(sp, name); cl.show(root, name);
        SwingUtilities.invokeLater(() -> sp.getViewport().setViewPosition(new Point(0, 0)));
    }
    private JComponent wrapPage(JComponent c) { Kit.Page p = new Kit.Page(); p.setBorder(new EmptyBorder(0, 0, 8, 6)); p.addRow(c, 0); return p; }

    // ----------------------------------------------------------------- Setup
    private void showSetup() {
        if (clock != null) clock.stop();
        JPanel v = Kit.vbox();
        JComboBox<Student> sc = Widgets.combo(new JComboBox<>(dm.getStudents().toArray(new Student[0])));
        JComboBox<Assessment> ac = Widgets.combo(new JComboBox<>(dm.getAssessments().toArray(new Assessment[0])));
        sc.setRenderer(rend(o -> o instanceof Student ? ((Student) o).getName() + "  ·  " + ((Student) o).getStudentId() : ""));
        ac.setRenderer(rend(o -> o instanceof Assessment ? ((Assessment) o).getAssessmentId() + "  ·  " + ((Assessment) o).getTitle() : ""));
        JLabel info = Kit.muted(" ");
        Runnable upd = () -> { Assessment a = (Assessment) ac.getSelectedItem(); if (a != null) info.setText(a.getQuestionIds().size() + " questions   ·   " + a.getTotalMarks() + " marks   ·   " + a.getDurationMinutes() + " minutes"); };
        ac.addActionListener(e -> upd.run()); upd.run();
        JPanel form = Kit.vbox();
        Kit.formRow(form, "STUDENT", sc); Kit.formRow(form, "ASSESSMENT", ac); form.add(Kit.left(info)); form.add(Box.createVerticalStrut(20));
        Widgets.Btn start = new Widgets.Btn("Start exam  →"); form.add(Kit.left(start));
        if (dm.getStudents().isEmpty() || dm.getAssessments().isEmpty()) { start.setEnabled(false); form.add(Box.createVerticalStrut(10)); form.add(Kit.left(Kit.label("Add a student and build an assessment first.", Font.PLAIN, 12.5f, Theme.WARN))); }
        start.addActionListener(e -> begin((Student) sc.getSelectedItem(), (Assessment) ac.getSelectedItem()));

        Widgets.GradientPanel hero = new Widgets.GradientPanel(new Color(14, 165, 233), Theme.PRIMARY, 24);
        hero.setLayout(new BorderLayout()); hero.setBorder(new EmptyBorder(26, 30, 26, 30));
        JPanel ht = Kit.vbox(); ht.add(Kit.left(Kit.label("Exam Mode", Font.BOLD, 26f, Color.WHITE)));
        ht.add(Kit.left(Kit.label("Run a timed, auto-graded session. MCQs are checked exactly; short and descriptive answers", Font.PLAIN, 13.5f, new Color(230, 240, 255))));
        ht.add(Kit.left(Kit.label("are scored with edit distance, keyword coverage and TF-IDF cosine similarity.", Font.PLAIN, 13.5f, new Color(230, 240, 255))));
        hero.add(ht); v.add(Kit.left(hero)); v.add(Box.createVerticalStrut(18));
        v.add(Kit.left(Kit.section("Start a session", "Choose who is sitting which paper", form)));
        swap("setup", v);
    }

    private interface Namer { String name(Object o); }
    private ListCellRenderer<Object> rend(Namer n) {
        return (l, v, i, sel, f) -> { JLabel x = new JLabel(n.name(v)); x.setOpaque(true); x.setBorder(new EmptyBorder(6, 10, 6, 10)); x.setFont(Theme.font(0, 13.5f));
            x.setBackground(sel ? Theme.alpha(Theme.PRIMARY, 60) : Theme.INPUT_BG); x.setForeground(Theme.TEXT); return x; };
    }

    // ------------------------------------------------------------------ Exam
    private void begin(Student s, Assessment a) {
        if (s == null || a == null) return;
        student = s; assessment = a; qs = new ArrayList<>(); answers.clear(); idx = 0;
        for (String id : a.getQuestionIds()) { Question q = dm.getQuestionBank().findQuestionById(id); if (q != null) qs.add(q); }
        if (qs.isEmpty()) { Kit.toast(this, "This assessment has no questions", Theme.WARN); return; }
        endAt = System.currentTimeMillis() + a.getDurationMinutes() * 60_000L;

        JPanel v = Kit.vbox();
        // header strip
        Widgets.Card top = new Widgets.Card(); top.setLayout(new BorderLayout(12, 0));
        JPanel t = Kit.vbox(); t.add(Kit.left(Kit.label(a.getTitle(), Font.BOLD, 17f, Theme.TEXT))); t.add(Kit.left(Kit.muted(s.getName() + "  ·  " + a.getAssessmentId() + "  ·  " + a.getTotalMarks() + " marks")));
        clockLabel = Kit.label("--:--", Font.BOLD, 22f, Theme.PRIMARY);
        top.add(t, BorderLayout.CENTER); top.add(clockLabel, BorderLayout.EAST);
        v.add(Kit.left(top)); v.add(Box.createVerticalStrut(16));

        progressLabel = Kit.label("", Font.BOLD, 12f, Theme.MUTED);
        questionHolder = new JPanel(new BorderLayout()); questionHolder.setOpaque(false);
        paletteHolder = new JPanel(new BorderLayout()); paletteHolder.setOpaque(false); paletteHolder.setPreferredSize(new Dimension(250, 10));
        JPanel body = Kit.cols(new double[]{0.74, 0.26}, 16, questionHolder, paletteHolder);
        v.add(Kit.left(body));
        renderQuestion();
        swap("exam", v);

        if (clock != null) clock.stop();
        clock = new javax.swing.Timer(500, e -> tick()); clock.start(); tick();
    }

    private void tick() {
        long left = Math.max(0, endAt - System.currentTimeMillis()) / 1000;
        clockLabel.setText(String.format("⏱ %02d:%02d", left / 60, left % 60));
        clockLabel.setForeground(left < 60 ? Theme.BAD : left < 300 ? Theme.WARN : Theme.PRIMARY);
        if (left == 0) { clock.stop(); Kit.toast(this, "Time is up — submitting", Theme.WARN); submit(); }
    }

    private void renderQuestion() {
        questionHolder.removeAll(); paletteHolder.removeAll();
        Question q = qs.get(idx);
        Widgets.Card card = new Widgets.Card(); card.setLayout(new BorderLayout(0, 16)); card.setBorder(new EmptyBorder(22, 26, 22, 26));
        JPanel head = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); head.setOpaque(false);
        head.add(Kit.label("Question " + (idx + 1) + " of " + qs.size(), Font.BOLD, 13f, Theme.MUTED));
        head.add(new Widgets.Pill(Widgets.pretty(q.getQuestionType().name()), Theme.PRIMARY));
        head.add(new Widgets.Pill(Widgets.pretty(q.getDifficulty().name()), Theme.difficulty(q.getDifficulty().name())));
        head.add(new Widgets.Pill(q.getMarks() + (q.getMarks() == 1 ? " mark" : " marks"), Theme.ACCENT));
        JPanel main = Kit.vbox(); main.add(Kit.left(Kit.wrap(q.getQuestionText(), Math.max(480, getWidth() - 640), Font.BOLD, 16f, Theme.TEXT))); main.add(Box.createVerticalStrut(18));
        if (q.getQuestionType() == QuestionType.MCQ) {
            String[] letters = {"A", "B", "C", "D"}; String[] texts = {q.getOptionA(), q.getOptionB(), q.getOptionC(), q.getOptionD()};
            final List<Option> opts = new ArrayList<>();
            for (int i = 0; i < 4; i++) {
                final String L = letters[i]; Option o = new Option(L, texts[i], L.equals(answers.get(q.getQuestionId())));
                opts.add(o);
                o.addMouseListener(new MouseAdapter() { @Override public void mouseClicked(MouseEvent e) {
                    answers.put(q.getQuestionId(), L); for (Option x : opts) x.setSelectedState(x == o); renderPalette(); } });
                main.add(Kit.left(o)); main.add(Box.createVerticalStrut(10));
            }
        } else {
            JTextArea ta = Widgets.field(new JTextArea(8, 40)); ta.setLineWrap(true); ta.setWrapStyleWord(true);
            ta.setText(answers.getOrDefault(q.getQuestionId(), ""));
            ta.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
                void ch() { if (ta.getText().trim().isEmpty()) answers.remove(q.getQuestionId()); else answers.put(q.getQuestionId(), ta.getText()); renderPalette(); }
                public void insertUpdate(javax.swing.event.DocumentEvent e) { ch(); } public void removeUpdate(javax.swing.event.DocumentEvent e) { ch(); } public void changedUpdate(javax.swing.event.DocumentEvent e) { ch(); } });
            main.add(Kit.left(new JScrollPane(ta) {{ setBorder(BorderFactory.createEmptyBorder()); }}));
            main.add(Box.createVerticalStrut(6)); main.add(Kit.left(Kit.muted(q.getQuestionType() == QuestionType.SHORT_ANSWER ? "Tip: be concise — keywords are matched against the model answer." : "Tip: cover as many key concepts as you can; partial marks are awarded.")));
        }
        JPanel nav = new JPanel(new BorderLayout()); nav.setOpaque(false);
        Widgets.Btn prev = new Widgets.Btn("←  Previous", Widgets.Btn.Kind.GHOST); prev.setEnabled(idx > 0); prev.addActionListener(e -> { idx--; renderQuestion(); });
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0)); right.setOpaque(false);
        if (idx < qs.size() - 1) { Widgets.Btn next = new Widgets.Btn("Next  →"); next.addActionListener(e -> { idx++; renderQuestion(); }); right.add(next); }
        else { Widgets.Btn sub = new Widgets.Btn("Submit exam  ✔", Widgets.Btn.Kind.SUCCESS); sub.addActionListener(e -> confirmSubmit()); right.add(sub); }
        nav.add(prev, BorderLayout.WEST); nav.add(right, BorderLayout.EAST);
        card.add(head, BorderLayout.NORTH); card.add(main, BorderLayout.CENTER); card.add(nav, BorderLayout.SOUTH);
        questionHolder.add(card); renderPalette();
        questionHolder.revalidate(); questionHolder.repaint(); paletteHolder.revalidate(); paletteHolder.repaint();
    }

    private void renderPalette() {
        paletteHolder.removeAll();
        Widgets.Card c = new Widgets.Card(); c.setLayout(new BorderLayout(0, 12));
        JPanel grid = new JPanel(new GridLayout(0, 4, 8, 8)); grid.setOpaque(false);
        int done = 0;
        for (int i = 0; i < qs.size(); i++) {
            final int n = i; boolean ans = answers.containsKey(qs.get(i).getQuestionId()); if (ans) done++;
            JLabel b = new JLabel(String.valueOf(i + 1), SwingConstants.CENTER) {
                @Override protected void paintComponent(Graphics g0) { Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
                    Color bg = n == idx ? Theme.PRIMARY : ans ? Theme.alpha(Theme.GOOD, 60) : Theme.SURFACE_ALT;
                    g.setColor(bg); g.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                    if (n != idx && ans) { g.setColor(Theme.GOOD); g.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 12, 12)); }
                    g.dispose(); super.paintComponent(g0); } };
            b.setFont(Theme.font(Font.BOLD, 13f)); b.setForeground(n == idx ? Color.WHITE : Theme.TEXT); b.setPreferredSize(new Dimension(40, 40)); b.setOpaque(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.addMouseListener(new MouseAdapter() { @Override public void mouseClicked(MouseEvent e) { idx = n; renderQuestion(); } });
            grid.add(b);
        }
        JPanel head = Kit.vbox(); head.add(Kit.left(Kit.label("Question palette", Font.BOLD, 15f, Theme.TEXT))); head.add(Kit.left(Kit.muted(done + " of " + qs.size() + " answered")));
        c.add(head, BorderLayout.NORTH); c.add(grid, BorderLayout.CENTER);
        JPanel legend = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0)); legend.setOpaque(false); legend.add(new Widgets.Pill("Current", Theme.PRIMARY)); legend.add(new Widgets.Pill("Done", Theme.GOOD)); legend.add(new Widgets.Pill("Open", Theme.MUTED));
        c.add(legend, BorderLayout.SOUTH);
        paletteHolder.add(c, BorderLayout.NORTH); paletteHolder.revalidate(); paletteHolder.repaint();
    }

    private void confirmSubmit() {
        int unanswered = qs.size() - answers.size();
        String msg = unanswered > 0 ? "You still have " + unanswered + " unanswered question(s).\nSubmit anyway?" : "Submit your answers for grading?";
        if (JOptionPane.showConfirmDialog(this, msg, "Submit exam", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) submit();
    }

    private void submit() {
        if (clock != null) clock.stop();
        Performance perf = AssessmentEvaluator.evaluate(assessment, student, qs, answers);
        dm.addResult(perf); dm.saveAllData();
        Kit.toast(this, "Result saved — " + String.format("%.0f%%", perf.getPercentage()), Theme.GOOD);
        showResult(perf);
    }

    // ---------------------------------------------------------------- Result
    private void showResult(Performance p) {
        JPanel v = Kit.vbox();
        Widgets.GradientPanel hero = new Widgets.GradientPanel(p.getPercentage() >= 65 ? Theme.GOOD : Theme.BAD, p.getPercentage() >= 65 ? Theme.ACCENT : Theme.PINK, 24);
        hero.setLayout(new BorderLayout()); hero.setBorder(new EmptyBorder(24, 30, 24, 30));
        String grade = p.getPercentage() >= 90 ? "Outstanding" : p.getPercentage() >= 75 ? "Great work" : p.getPercentage() >= 65 ? "Good effort" : "Needs revision";
        JPanel ht = Kit.vbox(); ht.add(Kit.left(Kit.label(grade + ", " + student.getName(), Font.BOLD, 26f, Color.WHITE)));
        ht.add(Kit.left(Kit.label(p.getScore() + " / " + p.getTotalMarks() + " marks  ·  " + String.format("%.0f%%", p.getAccuracy()) + " question accuracy  ·  " + assessment.getTitle(), Font.PLAIN, 13.5f, new Color(240, 250, 250))));
        hero.add(ht); v.add(Kit.left(hero)); v.add(Box.createVerticalStrut(16));

        Widgets.Gauge gauge = new Widgets.Gauge(p.getPercentage(), "score");
        Widgets.Card gc = new Widgets.Card(); gc.setLayout(new BorderLayout()); gc.add(gauge);
        Map<String, Double> topics = new LinkedHashMap<>(); if (p.getTopicBreakdown() != null) topics.putAll(p.getTopicBreakdown());
        v.add(Kit.left(Kit.cols(new double[]{0.28, 0.72}, 16, gc, Kit.section("Topic breakdown", "Percentage of marks earned per topic", new Widgets.Bars(topics, 100, true, (k, x) -> Theme.scoreColor(x))))));
        v.add(Box.createVerticalStrut(16));

        JPanel review = Kit.vbox();
        for (int i = 0; i < qs.size(); i++) {
            Question q = qs.get(i); Answer a = null; for (Answer x : p.getAnswers()) if (x.getQuestionId().equals(q.getQuestionId())) a = x;
            boolean ok = a != null && a.isCorrect(); Color col = ok ? Theme.GOOD : (a != null && a.getMarksAwarded() > 0 ? Theme.WARN : Theme.BAD);
            JPanel row = new JPanel(new BorderLayout(14, 0)) { @Override protected void paintComponent(Graphics g0) { Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
                g.setColor(Theme.SURFACE_ALT); g.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 14, 14)); g.setColor(col); g.fill(new RoundRectangle2D.Float(0, 0, 5, getHeight(), 5, 5)); g.dispose(); } };
            row.setOpaque(false); row.setBorder(new EmptyBorder(12, 18, 12, 14));
            JPanel t = Kit.vbox();
            t.add(Kit.left(Kit.wrap((i + 1) + ".  " + q.getQuestionText(), Math.max(520, getWidth() - 420), Font.BOLD, 13.5f, Theme.TEXT)));
            String given = a == null || a.getStudentAnswer().isEmpty() ? "(no answer)" : a.getStudentAnswer();
            t.add(Box.createVerticalStrut(4)); t.add(Kit.left(Kit.wrap("Your answer: " + given, Math.max(520, getWidth() - 420), 0, 12.5f, Theme.MUTED)));
            if (!ok && q.getCorrectAnswer() != null) { t.add(Kit.left(Kit.wrap("Expected: " + q.getCorrectAnswer(), Math.max(520, getWidth() - 420), 0, 12.5f, Theme.GOOD))); }
            if (a != null) t.add(Kit.left(Kit.wrap(a.getFeedback(), Math.max(520, getWidth() - 420), 0, 12f, Theme.MUTED)));
            row.add(t, BorderLayout.CENTER);
            JPanel pw = new JPanel(new GridBagLayout()); pw.setOpaque(false); pw.add(new Widgets.Pill((a == null ? 0 : a.getMarksAwarded()) + " / " + q.getMarks() + " marks", col)); row.add(pw, BorderLayout.EAST);
            review.add(Kit.left(row)); review.add(Box.createVerticalStrut(10));
        }
        v.add(Kit.left(Kit.section("Answer review", "Question-by-question feedback from the evaluator", review))); v.add(Box.createVerticalStrut(16));
        Widgets.Btn again = new Widgets.Btn("Start another session"); again.addActionListener(e -> showSetup()); v.add(Kit.left(again));
        swap("result", v);
    }

    // ------------------------------------------------------- Option widget
    private static class Option extends JPanel {
        private boolean selected, hover; private final String letter;
        Option(String letter, String text, boolean selected) {
            this.letter = letter; this.selected = selected; setOpaque(false); setLayout(new BorderLayout()); setBorder(new EmptyBorder(12, 58, 12, 16));
            add(Kit.wrap(text, 440, 0, 14f, Theme.TEXT)); setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); } });
        }
        void setSelectedState(boolean s) { selected = s; repaint(); }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g); int w = getWidth(), h = getHeight();
            g.setColor(selected ? Theme.alpha(Theme.PRIMARY, Theme.dark ? 55 : 28) : hover ? Theme.HOVER : Theme.SURFACE_ALT);
            g.fill(new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 16, 16));
            g.setColor(selected ? Theme.PRIMARY : Theme.BORDER); g.setStroke(new BasicStroke(selected ? 2f : 1f)); g.draw(new RoundRectangle2D.Float(1, 1, w - 3, h - 3, 16, 16));
            g.setColor(selected ? Theme.PRIMARY : Theme.alpha(Theme.MUTED, 60)); g.fillOval(16, h / 2 - 14, 28, 28);
            g.setColor(selected ? Color.WHITE : Theme.TEXT); g.setFont(Theme.font(Font.BOLD, 13f)); FontMetrics fm = g.getFontMetrics();
            g.drawString(letter, 30 - fm.stringWidth(letter) / 2, h / 2 + (fm.getAscent() - fm.getDescent()) / 2); g.dispose();
        }
    }
}
