package smartsassessment.ui;

import smartsassessment.algorithms.*;
import smartsassessment.model.Question;
import smartsassessment.service.DuplicateDetector;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.*;
import java.util.List;

/** Interactive playground that runs the project's hand-written algorithms live. */
public class AlgorithmLab extends JPanel {
    private static final String[] NAMES = {
        "KMP Search", "Z-Algorithm", "Rabin-Karp", "Edit Distance", "Aho-Corasick",
        "Miller-Rabin", "Matrix Chain DP", "TF-IDF Similarity"
    };
    private static final String[] BLURB = {
        "Linear-time pattern matching with a failure table", "Prefix matching via the Z-array",
        "Rolling-hash search with spurious-hit tracking", "Levenshtein DP table with traceback",
        "Multi-pattern automaton search", "Probabilistic primality testing",
        "Optimal parenthesisation by interval DP", "Cosine similarity of TF-IDF vectors"
    };
    private static final String[][] DEFAULTS = {
        {"ABABDABACDABABCABAB", "ABABCABAB"}, {"AABXAABXCAABXAABXAY", "AABX"}, {"GEEKS FOR GEEKS", "GEEK"},
        {"kitten", "sitting"}, {"ushers she he hers", "he,she,his,hers"}, {"561", "10"},
        {"10,30,5,60", ""},
        {"What is the time complexity of KMP pattern matching?", "State the running time of the Knuth-Morris-Pratt search"}
    };
    private static final String[][] LABELS = {
        {"Text", "Pattern"}, {"Text", "Pattern"}, {"Text", "Pattern"}, {"String A", "String B"},
        {"Text", "Patterns (comma separated)"}, {"Number n", "Rounds"}, {"Matrix dimensions (comma separated)", ""},
        {"Question A", "Question B"}
    };

    private int selected = 0;
    private final JPanel list = Kit.vbox();
    private final JPanel output = Kit.vbox();
    private final JTextField in1 = Widgets.field(new JTextField());
    private final JTextField in2 = Widgets.field(new JTextField());
    private final JLabel lab1 = Kit.label("", Font.BOLD, 12f, Theme.MUTED), lab2 = Kit.label("", Font.BOLD, 12f, Theme.MUTED);
    private final JLabel title = Kit.label("", Font.BOLD, 18f, Theme.TEXT), blurb = Kit.muted("");
    private final JPanel[] items = new JPanel[NAMES.length];

    public AlgorithmLab() {
        setOpaque(false); setLayout(new BorderLayout(18, 0));
        for (int i = 0; i < NAMES.length; i++) list.add(item(i));
        Widgets.Card left = new Widgets.Card(); left.setLayout(new BorderLayout(0, 10)); left.setPreferredSize(new Dimension(290, 0));
        left.add(Kit.label("Algorithms", Font.BOLD, 16f, Theme.TEXT), BorderLayout.NORTH); left.add(list, BorderLayout.CENTER);
        add(left, BorderLayout.WEST);

        Widgets.Card inputs = new Widgets.Card(); inputs.setLayout(new BorderLayout(0, 12));
        JPanel head = Kit.vbox(); head.add(Kit.left(title)); head.add(Kit.left(blurb)); head.add(Box.createVerticalStrut(14));
        JPanel fields = new JPanel(new GridLayout(2, 2, 14, 4)); fields.setOpaque(false);
        fields.add(lab1); fields.add(lab2); fields.add(in1); fields.add(in2);
        head.add(Kit.left(fields)); head.add(Box.createVerticalStrut(14));
        Widgets.Btn run = new Widgets.Btn("Run algorithm"); run.addActionListener(e -> run());
        Widgets.Btn reset = new Widgets.Btn("Reset example", Widgets.Btn.Kind.GHOST); reset.addActionListener(e -> select(selected));
        head.add(Kit.left(Kit.flow(10, 0, run, reset)));
        inputs.add(head, BorderLayout.CENTER);

        JPanel right = Kit.vbox(); right.add(Kit.left(inputs)); right.add(Box.createVerticalStrut(16));
        output.setAlignmentX(Component.LEFT_ALIGNMENT); right.add(output);
        JScrollPane sp = Widgets.scroll(wrapTop(right)); add(sp, BorderLayout.CENTER);
        in1.addActionListener(e -> run()); in2.addActionListener(e -> run());
        select(0);
    }

    private JComponent wrapTop(JComponent c) {
        JPanel p = new Kit.Page() {}; p.setBorder(new EmptyBorder(0, 0, 8, 6)); ((Kit.Page) p).addRow((JComponent) c, 0); return p;
    }

    private JPanel item(int i) {
        JPanel p = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create(); Widgets.quality(g);
                if (selected == i) { g.setColor(Theme.alpha(Theme.PRIMARY, Theme.dark ? 60 : 30)); g.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                    g.setColor(Theme.PRIMARY); g.fillRoundRect(0, 12, 4, getHeight() - 24, 4, 4); }
                g.dispose();
            }
        };
        p.setOpaque(false); p.setBorder(new EmptyBorder(9, 16, 9, 10)); p.setAlignmentX(LEFT_ALIGNMENT);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 58)); p.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        JPanel t = Kit.vbox(); t.add(Kit.left(Kit.label(NAMES[i], Font.BOLD, 13.5f, Theme.TEXT)));
        JLabel b = Kit.label(BLURB[i].length() > 38 ? BLURB[i].substring(0, 36) + "…" : BLURB[i], Font.PLAIN, 11.5f, Theme.MUTED); t.add(Kit.left(b));
        p.add(t); items[i] = p;
        p.addMouseListener(new java.awt.event.MouseAdapter() { @Override public void mouseClicked(java.awt.event.MouseEvent e) { select(i); } });
        return p;
    }

    private void select(int i) {
        selected = i; title.setText(NAMES[i]); blurb.setText(BLURB[i]);
        lab1.setText(LABELS[i][0]); lab2.setText(LABELS[i][1]); in1.setText(DEFAULTS[i][0]); in2.setText(DEFAULTS[i][1]);
        in2.setVisible(!LABELS[i][1].isEmpty()); lab2.setVisible(!LABELS[i][1].isEmpty());
        if (i == 5) in2.setText("10");
        for (JPanel p : items) if (p != null) p.repaint();
        run();
    }

    private void out(JComponent c) { c.setAlignmentX(LEFT_ALIGNMENT); output.add(c); output.add(Box.createVerticalStrut(14)); }
    private JPanel chips(JComponent... cs) { JPanel p = new JPanel(new GridLayout(1, cs.length, 12, 0)); p.setOpaque(false); for (JComponent c : cs) p.add(c); return p; }

    private void run() {
        output.removeAll();
        try {
            String a = in1.getText(), b = in2.getText();
            switch (selected) {
                case 0: kmp(a, b); break;
                case 1: z(a, b); break;
                case 2: rk(a, b); break;
                case 3: edit(a, b); break;
                case 4: aho(a, b); break;
                case 5: miller(a, b); break;
                case 6: mcm(a); break;
                default: sim(a, b);
            }
        } catch (Exception ex) {
            out(Kit.section("Input error", "Please check your values", Kit.wrap("Could not run: " + ex.getMessage(), 600, 0, 13f, Theme.BAD)));
        }
        output.revalidate(); output.repaint();
    }

    private List<int[]> ranges(List<Integer> pos, int len) { List<int[]> r = new ArrayList<>(); for (int p : pos) r.add(new int[]{p, len}); return r; }
    private String join(List<Integer> l) { return l.isEmpty() ? "none" : l.toString(); }

    private void complexity(String info) {
        JTextArea t = new JTextArea(info); t.setEditable(false); t.setOpaque(false); t.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12)); t.setForeground(Theme.TEXT);
        out(Kit.section("Complexity & core idea", "Straight from the implementation", t));
    }

    private void kmp(String text, String pat) {
        KMP.SearchResult r = KMP.search(text, pat);
        out(chips(Kit.chip("MATCHES", String.valueOf(r.getPositions().size()), Theme.GOOD), Kit.chip("COMPARISONS", String.valueOf(r.getComparisons()), Theme.PRIMARY),
                  Kit.chip("POSITIONS", join(r.getPositions()), Theme.ACCENT)));
        out(Kit.section("Text with matches highlighted", null, Kit.highlight(text, ranges(r.getPositions(), pat.length()), Theme.PRIMARY)));
        int[] f = r.getFailureFunction(); String[] cols = new String[pat.length()], vals = new String[pat.length()];
        for (int i = 0; i < pat.length(); i++) { cols[i] = String.valueOf(pat.charAt(i)); vals[i] = String.valueOf(f[i]); }
        out(Kit.section("Failure function (π table)", "Longest proper prefix that is also a suffix", scrollX(new Kit.Grid(new String[]{"π"}, cols, new String[][]{vals}, null, 44))));
        complexity(KMP.getComplexityInfo());
    }

    private void z(String text, String pat) {
        ZAlgorithm.ZResult r = ZAlgorithm.search(text, pat); String comb = r.getCombinedString(); int[] za = r.getZArray();
        out(chips(Kit.chip("MATCHES", String.valueOf(r.getMatchPositions().size()), Theme.GOOD), Kit.chip("POSITIONS", join(r.getMatchPositions()), Theme.ACCENT),
                  Kit.chip("Z-ARRAY LENGTH", String.valueOf(za.length), Theme.PRIMARY)));
        out(Kit.section("Text with matches highlighted", null, Kit.highlight(text, ranges(r.getMatchPositions(), pat.length()), Theme.PRIMARY)));
        String[] cols = new String[za.length], vals = new String[za.length]; boolean[][] hot = new boolean[1][za.length];
        for (int i = 0; i < za.length; i++) { cols[i] = comb.charAt(i) == '$' || comb.charAt(i) == '#' ? "#" : String.valueOf(comb.charAt(i)); vals[i] = String.valueOf(za[i]); hot[0][i] = za[i] == pat.length(); }
        out(Kit.section("Z-array of pattern + separator + text", "Highlighted cells equal the pattern length (a full match)", scrollX(new Kit.Grid(new String[]{"Z"}, cols, new String[][]{vals}, hot, 38))));
        complexity(ZAlgorithm.getComplexityInfo());
    }

    private void rk(String text, String pat) {
        RabinKarp.RKResult r = RabinKarp.search(text, pat);
        out(chips(Kit.chip("MATCHES", String.valueOf(r.getMatchPositions().size()), Theme.GOOD), Kit.chip("HASH COMPARISONS", String.valueOf(r.getHashComparisons()), Theme.PRIMARY),
                  Kit.chip("SPURIOUS HITS", String.valueOf(r.getSpuriousHits()), r.getSpuriousHits() > 0 ? Theme.WARN : Theme.GOOD), Kit.chip("PATTERN HASH", String.valueOf(r.getPatternHash()), Theme.ACCENT)));
        out(Kit.section("Text with matches highlighted", null, Kit.highlight(text, ranges(r.getMatchPositions(), pat.length()), Theme.PRIMARY)));
        complexity(RabinKarp.getComplexityInfo());
    }

    private void edit(String a, String b) {
        EditDistance.Result r = EditDistance.calculate(a, b); int[][] dp = r.getDpTable();
        DamerauLevenshtein.DLResult dl = DamerauLevenshtein.calculate(a, b);
        out(chips(Kit.chip("LEVENSHTEIN", String.valueOf(r.getDistance()), Theme.PRIMARY), Kit.chip("DAMERAU", String.valueOf(dl.getDistance()), Theme.ACCENT),
                  Kit.chip("INSERT / DELETE / SUB", r.getInsertions() + " / " + r.getDeletions() + " / " + r.getSubstitutions(), Theme.WARN)));
        String[] rows = new String[a.length() + 1], cols = new String[b.length() + 1]; String[][] cells = new String[a.length() + 1][b.length() + 1]; boolean[][] hot = new boolean[a.length() + 1][b.length() + 1];
        rows[0] = "ε"; cols[0] = "ε"; for (int i = 1; i <= a.length(); i++) rows[i] = String.valueOf(a.charAt(i - 1)); for (int j = 1; j <= b.length(); j++) cols[j] = String.valueOf(b.charAt(j - 1));
        for (int i = 0; i <= a.length(); i++) for (int j = 0; j <= b.length(); j++) cells[i][j] = String.valueOf(dp[i][j]);
        int i = a.length(), j = b.length(); hot[i][j] = true;
        while (i > 0 || j > 0) { // visualise the optimal alignment path
            if (i > 0 && j > 0 && a.charAt(i - 1) == b.charAt(j - 1)) { i--; j--; }
            else if (i > 0 && j > 0 && dp[i][j] == dp[i - 1][j - 1] + 1) { i--; j--; }
            else if (i > 0 && dp[i][j] == dp[i - 1][j] + 1) i--; else j--;
            hot[i][j] = true;
        }
        out(Kit.section("DP matrix", "Highlighted cells show the optimal edit path", scrollX(new Kit.Grid(rows, cols, cells, hot, 42))));
        StringBuilder sb = new StringBuilder(); int n = 1; for (String op : r.getOperations()) sb.append(n++).append(".  ").append(op).append("\n");
        JTextArea t = new JTextArea(sb.toString().trim()); t.setEditable(false); t.setOpaque(false); t.setFont(Theme.font(0, 13f)); t.setForeground(Theme.TEXT);
        out(Kit.section("Edit script", "Traceback of the minimum-cost transformation", t));
        complexity(EditDistance.getComplexityInfo());
    }

    private void aho(String text, String csv) {
        List<String> pats = new ArrayList<>(); for (String s : csv.split(",")) if (!s.trim().isEmpty()) pats.add(s.trim());
        AhoCorasick ac = new AhoCorasick(pats); List<AhoCorasick.Match> ms = ac.search(text);
        List<int[]> rs = new ArrayList<>(); StringBuilder sb = new StringBuilder();
        for (AhoCorasick.Match m : ms) { rs.add(new int[]{m.getPosition(), m.getPattern().length()}); sb.append("•  \"").append(m.getPattern()).append("\" at index ").append(m.getPosition()).append("\n"); }
        out(chips(Kit.chip("PATTERNS", String.valueOf(pats.size()), Theme.PRIMARY), Kit.chip("TOTAL MATCHES", String.valueOf(ms.size()), Theme.GOOD)));
        out(Kit.section("Text with all matches highlighted", null, Kit.highlight(text, rs, Theme.PRIMARY2)));
        JTextArea t = new JTextArea(ms.isEmpty() ? "No matches." : sb.toString().trim()); t.setEditable(false); t.setOpaque(false); t.setFont(Theme.font(0, 13f)); t.setForeground(Theme.TEXT);
        out(Kit.section("Match list", null, t)); complexity(AhoCorasick.getComplexityInfo());
    }

    private void miller(String ns, String rs) {
        PrimalityTest.PrimalityResult r = PrimalityTest.test(Long.parseLong(ns.trim()), Math.max(1, Integer.parseInt(rs.trim())));
        out(chips(Kit.chip("VERDICT", r.isProbablyPrime() ? "Probably prime" : "Composite", r.isProbablyPrime() ? Theme.GOOD : Theme.BAD),
                  Kit.chip("ROUNDS", String.valueOf(r.getRoundsTested()), Theme.PRIMARY), Kit.chip("CONFIDENCE", String.format("%.4f%%", r.getConfidence() * (r.getConfidence() <= 1 ? 100 : 1)), Theme.ACCENT)));
        out(Kit.section("Witness detail", null, Kit.wrap(r.getWitnessDetail(), 640, 0, 13f, Theme.TEXT)));
        complexity(PrimalityTest.getComplexityInfo());
    }

    private void mcm(String dims) {
        String[] parts = dims.split(","); int[] p = new int[parts.length]; for (int i = 0; i < p.length; i++) p[i] = Integer.parseInt(parts[i].trim());
        MatrixChainDP.MCMResult r = MatrixChainDP.solve(p); long[][] m = r.getMTable(); int n = p.length - 1;
        out(chips(Kit.chip("MIN MULTIPLICATIONS", String.valueOf(r.getMinMultiplications()), Theme.GOOD), Kit.chip("MATRICES", String.valueOf(n), Theme.PRIMARY),
                  Kit.chip("OPTIMAL ORDER", r.getOptimalParenthesization(), Theme.ACCENT)));
        String[] hdr = new String[n]; for (int i = 0; i < n; i++) hdr[i] = "A" + (i + 1); String[][] cells = new String[n][n]; boolean[][] hot = new boolean[n][n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) { cells[i][j] = j < i ? "" : String.valueOf(m[i + 1][j + 1]); hot[i][j] = i == 0 && j == n - 1; }
        out(Kit.section("Cost table m[i][j]", "Minimum scalar multiplications for the chain Ai…Aj", scrollX(new Kit.Grid(hdr, hdr, cells, hot, 64))));
        complexity(MatrixChainDP.getComplexityInfo());
    }

    private void sim(String a, String b) {
        Question q1 = new Question(), q2 = new Question(); q1.setQuestionText(a); q2.setQuestionText(b);
        DuplicateDetector.SimilarityReport r = DuplicateDetector.compare(q1, q2); double s = r.getSimilarityScore() * 100;
        Color c = r.getVerdict() == DuplicateDetector.MatchVerdict.DUPLICATE ? Theme.BAD : r.getVerdict() == DuplicateDetector.MatchVerdict.SIMILAR ? Theme.WARN : Theme.GOOD;
        out(chips(Kit.chip("COSINE SIMILARITY", String.format("%.1f%%", s), c), Kit.chip("VERDICT", r.getVerdict().name(), c),
                  Kit.chip("THRESHOLDS", "≥85% dup · 70–84% similar", Theme.MUTED)));
        Map<String, Double> bar = new LinkedHashMap<>(); bar.put("Similarity", s);
        out(Kit.section("Similarity meter", "Computed with hand-written TF-IDF vectors and cosine similarity", new Widgets.Bars(bar, 100, true, (k, v) -> c)));
        complexity(CosineSimilarity.getComplexityInfo() + "\n\n" + TFIDF.getComplexityInfo());
    }

    private JComponent scrollX(JComponent c) {
        JScrollPane sp = new JScrollPane(c, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        sp.setBorder(BorderFactory.createEmptyBorder()); sp.setOpaque(false); sp.getViewport().setOpaque(false); sp.getHorizontalScrollBar().setUI(new Widgets.ThinScroll());
        sp.setPreferredSize(new Dimension(100, c.getPreferredSize().height + 14)); return sp;
    }
}
