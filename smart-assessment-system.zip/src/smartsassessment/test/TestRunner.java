package smartsassessment.test;

import smartsassessment.algorithms.*;
import smartsassessment.model.*;
import smartsassessment.service.*;
import smartsassessment.storage.FileManager;

import java.io.File;
import java.math.BigInteger;
import java.util.*;

/**
 * Automated test suite executing verification across:
 * 1. All 18 Advanced Algorithms
 * 2. Question Bank operations & KMP Search
 * 3. Bloom and Difficulty Classifiers
 * 4. Duplicate Detection (TF-IDF & Cosine Similarity)
 * 5. Smart Assessment Generation with distribution constraints
 * 6. Automated Multi-Tier Evaluation
 * 7. File Persistence Round-Trip
 */
public class TestRunner {

    private static int totalTests = 0;
    private static int passedTests = 0;
    private static int failedTests = 0;

    public static void main(String[] args) {
        System.out.println("================================================================");
        System.out.println("       RUNNING ADVANCED ALGORITHMS & SMART ASSESSMENT SUITE     ");
        System.out.println("================================================================\n");

        testKMP();
        testZAlgorithm();
        testRabinKarp();
        testEditDistance();
        testDamerauLevenshtein();
        testWeightedEditDistance();
        testTFIDF();
        testCosineSimilarity();
        testSuffixArray();
        testLCPKasai();
        testAhoCorasick();
        testMatrixChainDP();
        testTSPBitmaskDP();
        testHamiltonianPath();
        testTreeDP();
        testSOSDP();
        testMaxFlow();
        testMillerRabin();
        testBloomClassifier();
        testDifficultyClassifier();
        testDuplicateDetector();
        testAssessmentGenerator();
        testAssessmentEvaluator();
        testFilePersistence();

        System.out.println("\n================================================================");
        System.out.printf("TEST SUMMARY: Total: %d | Passed: %d | Failed: %d%n", totalTests, passedTests, failedTests);
        if (failedTests == 0) {
            System.out.println("ALL TESTS PASSED WITH 100% SUCCESS!");
        } else {
            System.out.println("SOME TESTS FAILED! Please inspect errors above.");
        }
        System.out.println("================================================================");
    }

    private static void assertTrue(String testName, boolean condition) {
        totalTests++;
        if (condition) {
            passedTests++;
            System.out.println("  [PASS] " + testName);
        } else {
            failedTests++;
            System.err.println("  [FAIL] " + testName);
        }
    }

    private static void assertEquals(String testName, Object expected, Object actual) {
        totalTests++;
        if (Objects.equals(expected, actual)) {
            passedTests++;
            System.out.println("  [PASS] " + testName);
        } else {
            failedTests++;
            System.err.printf("  [FAIL] %s - Expected: %s, Got: %s%n", testName, expected, actual);
        }
    }

    // 1. KMP
    private static void testKMP() {
        System.out.println("--- Testing KMP ---");
        int[] pi = KMP.buildFailureFunction("ABABCABAB");
        assertEquals("KMP Failure Function Length", 9, pi.length);
        assertEquals("KMP Failure Function pi[4]", 0, pi[4]); // 'ABABC'
        assertEquals("KMP Failure Function pi[8]", 4, pi[8]); // 'ABABCABAB' matches 'ABAB'

        KMP.SearchResult res = KMP.search("ABABDABACDABABCABAB", "ABABCABAB");
        assertTrue("KMP Match Found", res.isFound());
        assertEquals("KMP Match Position", Arrays.asList(10), res.getPositions());
    }

    // 2. Z Algorithm
    private static void testZAlgorithm() {
        System.out.println("--- Testing Z-Algorithm ---");
        int[] z = ZAlgorithm.computeZArray("aabxaab");
        assertEquals("Z-Array length", 7, z.length);
        assertEquals("Z[0]", 7, z[0]);
        assertEquals("Z[1]", 1, z[1]);
        assertEquals("Z[2]", 0, z[2]);
        assertEquals("Z[4]", 3, z[4]);

        ZAlgorithm.ZResult res = ZAlgorithm.search("GEEKS FOR GEEKS", "GEEKS");
        assertEquals("Z-Algorithm Matches", Arrays.asList(0, 10), res.getMatchPositions());
    }

    // 3. Rabin-Karp
    private static void testRabinKarp() {
        System.out.println("--- Testing Rabin-Karp ---");
        RabinKarp.RKResult res = RabinKarp.search("AABAACAADAABAABA", "AABA");
        assertTrue("Rabin-Karp Found", res.isFound());
        assertEquals("Rabin-Karp Matching Positions", Arrays.asList(0, 9, 12), res.getMatchPositions());
    }

    // 4. Edit Distance (Wagner-Fischer)
    private static void testEditDistance() {
        System.out.println("--- Testing Edit Distance (Wagner-Fischer) ---");
        EditDistance.Result res = EditDistance.calculate("kitten", "sitting");
        assertEquals("Levenshtein Distance kitten -> sitting", 3, res.getDistance());
        assertEquals("Distance same string", 0, EditDistance.calculate("algorithm", "algorithm").getDistance());
    }

    // 5. Damerau-Levenshtein
    private static void testDamerauLevenshtein() {
        System.out.println("--- Testing Damerau-Levenshtein ---");
        DamerauLevenshtein.DLResult res = DamerauLevenshtein.calculate("CA", "AC");
        assertEquals("Damerau-Levenshtein Transposition CA -> AC", 1, res.getDistance());
        assertEquals("Damerau-Levenshtein Insertion", 1, DamerauLevenshtein.calculate("cat", "cats").getDistance());
    }

    // 6. Weighted Edit Distance
    private static void testWeightedEditDistance() {
        System.out.println("--- Testing Weighted Edit Distance ---");
        // Ins=1, Del=1, Sub=3. From "cat" to "hat", delete 'c' + insert 'h' = 2, which beats sub (3).
        WeightedEditDistance.WEDResult res = WeightedEditDistance.calculate("cat", "hat", 1, 1, 3);
        assertEquals("Weighted Cost Prefers Del+Ins over Sub", 2, res.getTotalCost());
    }

    // 7. TF-IDF
    private static void testTFIDF() {
        System.out.println("--- Testing TF-IDF ---");
        List<String> docs = Arrays.asList(
                "KMP string pattern matching algorithm",
                "Rabin Karp rolling hash pattern matching",
                "Dynamic programming matrix chain multiplication"
        );
        TFIDF model = new TFIDF(docs);
        assertTrue("TFIDF Vocabulary Built", model.getVocabulary().contains("pattern"));
        double[] vec = model.transform("pattern matching");
        assertTrue("Vector Dimension matches Vocab", vec.length == model.getVocabulary().size());
    }

    // 8. Cosine Similarity
    private static void testCosineSimilarity() {
        System.out.println("--- Testing Cosine Similarity ---");
        double[] v1 = {1.0, 2.0, 3.0};
        double[] v2 = {1.0, 2.0, 3.0};
        assertEquals("Cosine Similarity Identical", 1.0, Math.round(CosineSimilarity.compute(v1, v2) * 1000.0) / 1000.0);

        double[] v3 = {1.0, 0.0, 0.0};
        double[] v4 = {0.0, 1.0, 0.0};
        assertEquals("Cosine Similarity Orthogonal", 0.0, CosineSimilarity.compute(v3, v4));
    }

    // 9. Suffix Array
    private static void testSuffixArray() {
        System.out.println("--- Testing Suffix Array ---");
        SuffixArray sa = new SuffixArray("banana");
        int[] expectedSA = {5, 3, 1, 0, 4, 2};
        assertTrue("Suffix Array for 'banana'", Arrays.equals(expectedSA, sa.getSA()));

        List<Integer> occurrences = sa.search("ana");
        assertEquals("Binary Search 'ana' in Suffix Array", Arrays.asList(3, 1), occurrences);
    }

    // 10. Kasai LCP
    private static void testLCPKasai() {
        System.out.println("--- Testing Kasai LCP ---");
        LCPKasai.LCPResult res = LCPKasai.compute("banana");
        int[] expectedLCP = {0, 1, 3, 0, 0, 2};
        assertTrue("Kasai LCP Array for 'banana'", Arrays.equals(expectedLCP, res.getLcp()));
    }

    // 11. Aho-Corasick
    private static void testAhoCorasick() {
        System.out.println("--- Testing Aho-Corasick ---");
        List<String> patterns = Arrays.asList("he", "she", "his", "hers");
        AhoCorasick ac = new AhoCorasick(patterns);
        List<AhoCorasick.Match> matches = ac.search("ushers");

        Set<String> matchedPatterns = new HashSet<>();
        for (AhoCorasick.Match m : matches) {
            matchedPatterns.add(m.getPattern());
        }
        assertTrue("Aho-Corasick matches 'she'", matchedPatterns.contains("she"));
        assertTrue("Aho-Corasick matches 'he'", matchedPatterns.contains("he"));
        assertTrue("Aho-Corasick matches 'hers'", matchedPatterns.contains("hers"));
    }

    // 12. Matrix Chain DP
    private static void testMatrixChainDP() {
        System.out.println("--- Testing Matrix Chain DP ---");
        int[] p = {10, 100, 5, 50}; // 3 matrices: 10x100, 100x5, 5x50
        MatrixChainDP.MCMResult res = MatrixChainDP.solve(p);
        assertEquals("Matrix Chain Min Cost", 7500L, res.getMinMultiplications());
        assertEquals("Matrix Chain Parenthesization", "((A1 x A2) x A3)", res.getOptimalParenthesization());
    }

    // 13. TSP Bitmask DP
    private static void testTSPBitmaskDP() {
        System.out.println("--- Testing TSP Bitmask DP ---");
        int[][] dist = {
                {0, 10, 15, 20},
                {10, 0, 35, 25},
                {15, 35, 0, 30},
                {20, 25, 30, 0}
        };
        TSPBitmaskDP.TSPResult res = TSPBitmaskDP.solve(dist);
        assertEquals("TSP Optimal Tour Cost", 80, res.getMinCost());
        assertTrue("TSP Tour Contains Start City", res.getTour().get(0) == 0);
    }

    // 14. Hamiltonian Path
    private static void testHamiltonianPath() {
        System.out.println("--- Testing Hamiltonian Path ---");
        boolean[][] adj = new boolean[4][4];
        adj[0][1] = adj[1][0] = true;
        adj[1][2] = adj[2][1] = true;
        adj[2][3] = adj[3][2] = true;

        HamiltonianPath.HPResult res = HamiltonianPath.findPath(4, adj);
        assertTrue("Hamiltonian Path Exists in Line Graph", res.exists());
        assertEquals("Hamiltonian Path Length", 4, res.getPath().size());
    }

    // 15. Tree DP
    private static void testTreeDP() {
        System.out.println("--- Testing Tree DP ---");
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i < 5; i++) adj.add(new ArrayList<>());
        // Tree: 0-1, 0-2, 1-3, 1-4
        adj.get(0).add(1); adj.get(1).add(0);
        adj.get(0).add(2); adj.get(2).add(0);
        adj.get(1).add(3); adj.get(3).add(1);
        adj.get(1).add(4); adj.get(4).add(1);

        TreeDP.TreeResult res = TreeDP.analyze(5, adj);
        assertEquals("Tree Diameter", 3, res.getDiameter());
        assertEquals("Subtree size of Root 0", 5, res.getSubtreeSizes()[0]);
    }

    // 16. SOS DP
    private static void testSOSDP() {
        System.out.println("--- Testing SOS DP ---");
        // For N = 2 bits (4 masks: 00, 01, 10, 11)
        long[] a = {1, 2, 4, 8};
        // Mask 0 (00): a[0] = 1
        // Mask 1 (01): a[0] + a[1] = 1 + 2 = 3
        // Mask 2 (10): a[0] + a[2] = 1 + 4 = 5
        // Mask 3 (11): a[0] + a[1] + a[2] + a[3] = 1 + 2 + 4 + 8 = 15
        SOSDP.SOSResult res = SOSDP.compute(2, a);
        assertEquals("SOS DP F[0]", 1L, res.getSosSum()[0]);
        assertEquals("SOS DP F[1]", 3L, res.getSosSum()[1]);
        assertEquals("SOS DP F[2]", 5L, res.getSosSum()[2]);
        assertEquals("SOS DP F[3]", 15L, res.getSosSum()[3]);
    }

    // 17. Max Flow (Edmonds-Karp)
    private static void testMaxFlow() {
        System.out.println("--- Testing Max Flow (Edmonds-Karp) ---");
        List<MaxFlow.FlowEdge> edges = new ArrayList<>();
        edges.add(new MaxFlow.FlowEdge(0, 1, 10));
        edges.add(new MaxFlow.FlowEdge(0, 2, 10));
        edges.add(new MaxFlow.FlowEdge(1, 2, 2));
        edges.add(new MaxFlow.FlowEdge(1, 3, 4));
        edges.add(new MaxFlow.FlowEdge(1, 4, 8));
        edges.add(new MaxFlow.FlowEdge(2, 4, 9));
        edges.add(new MaxFlow.FlowEdge(3, 5, 10));
        edges.add(new MaxFlow.FlowEdge(4, 3, 6));
        edges.add(new MaxFlow.FlowEdge(4, 5, 10));

        MaxFlow.MaxFlowResult res = MaxFlow.computeMaxFlow(6, edges, 0, 5);
        assertEquals("Max Flow value", 19, res.getMaxFlow());
    }

    // 18. Miller-Rabin
    private static void testMillerRabin() {
        System.out.println("--- Testing Miller-Rabin Primality ---");
        assertTrue("17 is probably prime", PrimalityTest.test(17, 10).isProbablyPrime());
        assertTrue("104729 is probably prime", PrimalityTest.test(104729, 10).isProbablyPrime());
        assertTrue("15 is composite", !PrimalityTest.test(15, 10).isProbablyPrime());
        assertTrue("561 (Carmichael number) is composite", !PrimalityTest.test(561, 10).isProbablyPrime());

        BigInteger largePrime = new BigInteger("1000000007");
        assertTrue("10^9+7 BigInteger is prime", PrimalityTest.testBigInteger(largePrime, 10).isProbablyPrime());
    }

    // 19. Bloom Classifier
    private static void testBloomClassifier() {
        System.out.println("--- Testing Bloom Classifier ---");
        assertEquals("Bloom: Define -> REMEMBER", BloomLevel.REMEMBER, BloomClassifier.classify("Define what is KMP."));
        assertEquals("Bloom: Calculate -> APPLY", BloomLevel.APPLY, BloomClassifier.classify("Calculate the failure function."));
        assertEquals("Bloom: Design -> CREATE", BloomLevel.CREATE, BloomClassifier.classify("Design an optimal automaton."));
    }

    // 20. Difficulty Classifier
    private static void testDifficultyClassifier() {
        System.out.println("--- Testing Difficulty Classifier ---");
        DifficultyLevel diffEasy = DifficultyClassifier.classify("Define KMP.", QuestionType.MCQ, BloomLevel.REMEMBER);
        assertEquals("Remember MCQ -> EASY", DifficultyLevel.EASY, diffEasy);

        DifficultyLevel diffHard = DifficultyClassifier.classify(
                "Critically evaluate and design a bitmask dynamic programming recurrence for Hamiltonian path with proof.",
                QuestionType.DESCRIPTIVE, BloomLevel.CREATE);
        assertEquals("Complex Descriptive -> HARD", DifficultyLevel.HARD, diffHard);
    }

    // 21. Duplicate Detector
    private static void testDuplicateDetector() {
        System.out.println("--- Testing Duplicate Detector ---");
        Question q1 = new Question("Q1", "Algo", "M2", "KMP",
                "What is the time complexity of the KMP algorithm?",
                QuestionType.MCQ, "A", "B", "C", "D", "A", "",
                DifficultyLevel.EASY, BloomLevel.REMEMBER, 2);

        Question q2 = new Question("Q2", "Algo", "M2", "KMP",
                "What is the asymptotic time complexity of KMP algorithm?",
                QuestionType.MCQ, "A", "B", "C", "D", "A", "",
                DifficultyLevel.EASY, BloomLevel.REMEMBER, 2);

        DuplicateDetector.SimilarityReport rep = DuplicateDetector.compare(q1, q2);
        assertTrue("Near identical questions flagged as DUPLICATE or SIMILAR",
                rep.getVerdict() == DuplicateDetector.MatchVerdict.DUPLICATE ||
                rep.getVerdict() == DuplicateDetector.MatchVerdict.SIMILAR);
    }

    // 22. Assessment Generator
    private static void testAssessmentGenerator() {
        System.out.println("--- Testing Assessment Generator ---");
        QuestionBank bank = new QuestionBank();
        for (int i = 1; i <= 10; i++) {
            bank.addQuestion(new Question("QA" + i, "Algo", "Module 2", "KMP",
                    "Question " + i + " regarding KMP failure function and matching",
                    QuestionType.MCQ, "A", "B", "C", "D", "A", "",
                    (i <= 3) ? DifficultyLevel.EASY : ((i <= 8) ? DifficultyLevel.MEDIUM : DifficultyLevel.HARD),
                    (i <= 4) ? BloomLevel.REMEMBER : BloomLevel.UNDERSTAND, 2));
        }

        Map<DifficultyLevel, Integer> diffDist = new HashMap<>();
        diffDist.put(DifficultyLevel.EASY, 30);
        diffDist.put(DifficultyLevel.MEDIUM, 50);
        diffDist.put(DifficultyLevel.HARD, 20);

        Map<BloomLevel, Integer> bloomDist = new HashMap<>();
        bloomDist.put(BloomLevel.REMEMBER, 40);
        bloomDist.put(BloomLevel.UNDERSTAND, 60);
        bloomDist.put(BloomLevel.APPLY, 0);
        bloomDist.put(BloomLevel.ANALYZE, 0);
        bloomDist.put(BloomLevel.EVALUATE, 0);
        bloomDist.put(BloomLevel.CREATE, 0);

        AssessmentGenerator.GenerationResult genRes = AssessmentGenerator.generate(
                bank, "Test Midterm", "Module 2", null, 5, 30, diffDist, bloomDist, QuestionType.MCQ
        );

        assertTrue("Assessment Generation Success", genRes.isSuccess());
        assertEquals("Generated Paper has 5 Questions", 5, genRes.getSelectedQuestions().size());
    }

    // 23. Assessment Evaluator
    private static void testAssessmentEvaluator() {
        System.out.println("--- Testing Assessment Evaluator ---");
        Assessment a = new Assessment("A999", "Trial", "Algo", "M2",
                Collections.emptyList(), Collections.emptyList(), 4, 20, "2026-09-17");
        Student s = new Student("S999", "Test User", "test@univ.edu", "CS");

        Question qMCQ = new Question("Q1", "Algo", "M2", "KMP", "What is KMP?",
                QuestionType.MCQ, "A", "B", "C", "D", "A", "", DifficultyLevel.EASY, BloomLevel.REMEMBER, 2);
        Question qShort = new Question("Q2", "Algo", "M2", "KMP", "Define failure function",
                QuestionType.SHORT_ANSWER, "", "", "", "", "longest proper prefix which is also suffix", "",
                DifficultyLevel.MEDIUM, BloomLevel.UNDERSTAND, 2);

        List<Question> qList = Arrays.asList(qMCQ, qShort);
        Map<String, String> answers = new HashMap<>();
        answers.put("Q1", "A"); // Correct
        answers.put("Q2", "longest prefix which is suffix"); // Near match

        Performance perf = AssessmentEvaluator.evaluate(a, s, qList, answers);
        assertTrue("MCQ Awarded full 2 marks", perf.getAnswers().get(0).getMarksAwarded() == 2);
        assertTrue("Short Answer awarded partial/full marks", perf.getAnswers().get(1).getMarksAwarded() >= 1);
        assertTrue("Total score >= 3", perf.getScore() >= 3);
    }

    // 24. File Persistence
    private static void testFilePersistence() {
        System.out.println("--- Testing File Persistence ---");
        String tempQFile = "data/test_temp_questions.txt";
        List<Question> orig = new ArrayList<>();
        orig.add(new Question("QT1", "Algo", "Module 1", "Search", "Sample text with | pipe symbol?",
                QuestionType.MCQ, "A", "B", "C", "D", "A", "Expl", DifficultyLevel.EASY, BloomLevel.REMEMBER, 2));

        FileManager.saveQuestions(orig, tempQFile);
        List<Question> loaded = FileManager.loadQuestions(tempQFile);

        assertEquals("Persisted question count matches", 1, loaded.size());
        assertEquals("Persisted question ID matches", "QT1", loaded.get(0).getQuestionId());
        assertEquals("Persisted question text handles pipes", "Sample text with | pipe symbol?", loaded.get(0).getQuestionText());

        new File(tempQFile).delete();
    }
}
