package smartsassessment.service;

import smartsassessment.model.BloomLevel;
import smartsassessment.model.DifficultyLevel;
import smartsassessment.model.Question;
import smartsassessment.model.QuestionType;
import smartsassessment.util.IdGenerator;

import java.util.*;

/**
 * Rule-based question generator producing pedagogically sound questions
 * across all syllabus modules and topics without external API calls.
 */
public class QuestionGenerator {

    private static class Template {
        String textTemplate;
        String optA;
        String optB;
        String optC;
        String optD;
        String correctAns;
        String explanationTemplate;
        BloomLevel bloom;
        DifficultyLevel diff;
        QuestionType type;

        Template(String textTemplate, String optA, String optB, String optC, String optD,
                 String correctAns, String explanationTemplate, BloomLevel bloom, DifficultyLevel diff, QuestionType type) {
            this.textTemplate = textTemplate;
            this.optA = optA;
            this.optB = optB;
            this.optC = optC;
            this.optD = optD;
            this.correctAns = correctAns;
            this.explanationTemplate = explanationTemplate;
            this.bloom = bloom;
            this.diff = diff;
            this.type = type;
        }
    }

    private static final Map<String, List<Template>> TEMPLATE_REGISTRY = new HashMap<>();

    static {
        // Module 2 - String Algorithms templates
        List<Template> kmpTemplates = new ArrayList<>();
        kmpTemplates.add(new Template(
                "What is the asymptotic time complexity of preprocessing the failure function (pi table) in the KMP algorithm for pattern of length m?",
                "O(m)", "O(m^2)", "O(n + m)", "O(log m)",
                "A", "KMP builds its prefix failure table in linear O(m) time.",
                BloomLevel.REMEMBER, DifficultyLevel.EASY, QuestionType.MCQ));
        kmpTemplates.add(new Template(
                "In KMP pattern matching, how does the failure function avoid redundant character comparisons in the text?",
                "By backtracking the text pointer to the start of the current match window",
                "By shifting the pattern forward using the longest proper prefix that is also a suffix",
                "By sorting the text characters into a hash table",
                "By skipping characters randomly using a polynomial hash",
                "B", "KMP utilizes the longest prefix-suffix information to shift the pattern without rewinding the text pointer.",
                BloomLevel.UNDERSTAND, DifficultyLevel.MEDIUM, QuestionType.MCQ));
        kmpTemplates.add(new Template(
                "Given pattern 'ABABC', calculate the failure function array pi[0..4].",
                "pi = [0, 0, 1, 2, 0]", "pi = [0, 1, 2, 3, 0]", "pi = [0, 0, 0, 1, 2]", "pi = [1, 2, 1, 2, 0]",
                "A", "For 'ABABC': 'A'->0, 'AB'->0, 'ABA'->1 ('A'), 'ABAB'->2 ('AB'), 'ABABC'->0.",
                BloomLevel.APPLY, DifficultyLevel.MEDIUM, QuestionType.MCQ));
        kmpTemplates.add(new Template(
                "Explain the structural difference between the KMP failure function and the Z-algorithm's Z-array.",
                "", "", "", "",
                "KMP failure function pi[i] computes the length of the longest proper prefix of pattern[0..i] that is also a suffix of pattern[0..i], whereas Z[i] computes the length of the longest substring starting at s[i] that matches the prefix of s.",
                "KMP is prefix-suffix oriented whereas Z-algorithm is prefix-substring oriented.",
                BloomLevel.ANALYZE, DifficultyLevel.HARD, QuestionType.SHORT_ANSWER));
        kmpTemplates.add(new Template(
                "Analyze why the overall matching phase of KMP runs in strictly O(n) time even though the inner while-loop can execute multiple times.",
                "", "", "", "",
                "Because the text index pointer i advances by 1 in every iteration of the outer loop, and the pattern pointer j can only decrease as many times as it was previously incremented (at most n times in total), making the amortized cost per step O(1).",
                "Amortized potential function argument on pointer advances.",
                BloomLevel.EVALUATE, DifficultyLevel.HARD, QuestionType.DESCRIPTIVE));
        TEMPLATE_REGISTRY.put("kmp", kmpTemplates);

        // Rabin-Karp templates
        List<Template> rkTemplates = new ArrayList<>();
        rkTemplates.add(new Template(
                "What technique does the Rabin-Karp algorithm use to achieve O(1) hash updates across sliding text windows?",
                "Polynomial rolling hash with modular arithmetic",
                "Binary search over suffix trees",
                "Prefix sum array of ASCII characters",
                "Hamming distance bitmasks",
                "A", "Rabin-Karp subtracts the high-order term and adds the new character in O(1) using polynomial rolling hash.",
                BloomLevel.REMEMBER, DifficultyLevel.EASY, QuestionType.MCQ));
        rkTemplates.add(new Template(
                "What is the worst-case time complexity of Rabin-Karp when multiple spurious hash collisions occur?",
                "O(n + m)", "O(n * m)", "O(n log m)", "O(m^2)",
                "B", "If hash collisions occur at every position, verification takes O(m) for all n positions, yielding O(nm).",
                BloomLevel.UNDERSTAND, DifficultyLevel.MEDIUM, QuestionType.MCQ));
        TEMPLATE_REGISTRY.put("rabin-karp", rkTemplates);

        // Suffix Array & LCP templates
        List<Template> saTemplates = new ArrayList<>();
        saTemplates.add(new Template(
                "What is the time complexity of Kasai's algorithm for constructing the LCP array from a given Suffix Array?",
                "O(n)", "O(n log n)", "O(n^2)", "O(log n)",
                "A", "Kasai's algorithm runs in strictly linear O(n) time because the common prefix length h decreases by at most 1 per step.",
                BloomLevel.REMEMBER, DifficultyLevel.EASY, QuestionType.MCQ));
        saTemplates.add(new Template(
                "Explain the key conceptual insight behind the SA-IS (Suffix Array by Induced Sorting) linear-time algorithm.",
                "", "", "", "",
                "SA-IS classifies suffixes into S-type and L-type, isolates Leftmost S-type (LMS) suffixes, sorts LMS substrings recursively, and induces the full suffix ordering through forward and backward bucket scans.",
                "Induced sorting via LMS characters and bucket pointers.",
                BloomLevel.ANALYZE, DifficultyLevel.HARD, QuestionType.DESCRIPTIVE));
        TEMPLATE_REGISTRY.put("suffix array", saTemplates);
        TEMPLATE_REGISTRY.put("lcp kasai", saTemplates);

        // Module 3 - Dynamic Programming templates
        List<Template> mcmTemplates = new ArrayList<>();
        mcmTemplates.add(new Template(
                "In Matrix Chain Multiplication, what is the asymptotic runtime using dynamic programming for n matrices?",
                "O(n^3)", "O(n^2)", "O(2^n)", "O(n log n)",
                "A", "MCM evaluates O(n^2) subproblems, each requiring O(n) split-point evaluations, resulting in O(n^3).",
                BloomLevel.REMEMBER, DifficultyLevel.EASY, QuestionType.MCQ));
        mcmTemplates.add(new Template(
                "Formulate the dynamic programming recurrence relation for Matrix Chain Multiplication cost m[i][j].",
                "", "", "", "",
                "m[i][j] = 0 if i == j; otherwise min_{i <= k < j} { m[i][k] + m[k+1][j] + p_{i-1} * p_k * p_j }.",
                "Interval DP recurrence partitioning at index k.",
                BloomLevel.APPLY, DifficultyLevel.HARD, QuestionType.SHORT_ANSWER));
        TEMPLATE_REGISTRY.put("matrix chain", mcmTemplates);

        // TSP Bitmask templates
        List<Template> tspTemplates = new ArrayList<>();
        tspTemplates.add(new Template(
                "In the Held-Karp Bitmask DP algorithm for TSP, what do the state dimensions DP[mask][u] represent?",
                "The minimum cost to visit all cities in the subset 'mask', ending at city 'u'",
                "The maximum flow from source mask to sink u",
                "The shortest path from 0 to u ignoring unvisited cities",
                "The number of spanning trees covering the subset mask",
                "A", "State DP[mask][u] tracks the minimum cost tour covering the visited bitmask subset terminating at u.",
                BloomLevel.UNDERSTAND, DifficultyLevel.MEDIUM, QuestionType.MCQ));
        TEMPLATE_REGISTRY.put("tsp bitmask", tspTemplates);

        // Max Flow templates
        List<Template> mfTemplates = new ArrayList<>();
        mfTemplates.add(new Template(
                "What is the theoretical worst-case time complexity of the Edmonds-Karp maximum flow algorithm?",
                "O(V * E^2)", "O(V^2 * E)", "O(E * log V)", "O(V^3)",
                "A", "Edmonds-Karp uses BFS to guarantee shortest augmenting paths, terminating in at most O(VE) augmentations for O(VE^2) total time.",
                BloomLevel.REMEMBER, DifficultyLevel.MEDIUM, QuestionType.MCQ));
        TEMPLATE_REGISTRY.put("max flow", mfTemplates);

        // Primality testing templates
        List<Template> ptTemplates = new ArrayList<>();
        ptTemplates.add(new Template(
                "Why is the Miller-Rabin primality test classified as a randomised Monte Carlo algorithm?",
                "Because it has a bounded probability of falsely declaring a composite number as probably prime, but never declares a prime as composite",
                "Because it generates random primes indefinitely without terminating",
                "Because its runtime varies unpredictably with constant factor errors",
                "Because it relies on brute force trial division with random intervals",
                "A", "Miller-Rabin has one-sided error: primes are always recognized, while composites have error probability <= (1/4)^k.",
                BloomLevel.UNDERSTAND, DifficultyLevel.MEDIUM, QuestionType.MCQ));
        TEMPLATE_REGISTRY.put("primality test", ptTemplates);
        TEMPLATE_REGISTRY.put("miller-rabin", ptTemplates);
    }

    /**
     * Generates a list of questions tailored to specified topic, module, and constraints.
     */
    public static List<Question> generateQuestions(String topic, String module, String content,
                                                   int count, QuestionType preferredType,
                                                   DifficultyLevel preferredDiff, BloomLevel preferredBloom) {
        List<Question> generated = new ArrayList<>();
        String normalizedTopic = topic != null ? topic.trim().toLowerCase() : "general";

        List<Template> matchedTemplates = new ArrayList<>();
        for (Map.Entry<String, List<Template>> entry : TEMPLATE_REGISTRY.entrySet()) {
            if (normalizedTopic.contains(entry.getKey()) || entry.getKey().contains(normalizedTopic)) {
                matchedTemplates.addAll(entry.getValue());
            }
        }

        // If no specific topic templates matched, generate algorithmic templates from topic name & content
        if (matchedTemplates.isEmpty()) {
            matchedTemplates = buildDynamicTemplates(topic, module, content);
        }

        Set<String> generatedTexts = new HashSet<>();
        int templateIdx = 0;

        for (int i = 0; i < count; i++) {
            Template tmpl;
            if (templateIdx < matchedTemplates.size()) {
                tmpl = matchedTemplates.get(templateIdx++);
            } else {
                // Synthesize varied algorithmic question variant
                tmpl = createDynamicVariant(topic, module, content, i + 1, preferredType, preferredDiff, preferredBloom);
            }

            if (generatedTexts.contains(tmpl.textTemplate)) {
                tmpl = createDynamicVariant(topic, module, content, i + 10, preferredType, preferredDiff, preferredBloom);
            }
            generatedTexts.add(tmpl.textTemplate);

            Question q = new Question(
                    IdGenerator.nextQuestionId(),
                    "Advanced Algorithms",
                    module,
                    topic,
                    tmpl.textTemplate,
                    tmpl.type,
                    tmpl.optA, tmpl.optB, tmpl.optC, tmpl.optD,
                    tmpl.correctAns,
                    tmpl.explanationTemplate,
                    tmpl.diff,
                    tmpl.bloom,
                    tmpl.type == QuestionType.MCQ ? 2 : (tmpl.type == QuestionType.SHORT_ANSWER ? 5 : 10)
            );

            generated.add(q);
        }

        return generated;
    }

    private static List<Template> buildDynamicTemplates(String topic, String module, String content) {
        List<Template> list = new ArrayList<>();
        String desc = (content != null && !content.isEmpty()) ? content : topic;

        list.add(new Template(
                "What is the primary computational objective of the " + topic + " algorithm?",
                "To optimize asymptotic time and space resource efficiency for " + topic,
                "To sort all input elements into ascending alphabetical order",
                "To perform randomized linear regression on graph nodes",
                "To compress arbitrary text files into Huffman binary trees",
                "A", "The primary objective of " + topic + " relates to " + desc,
                BloomLevel.REMEMBER, DifficultyLevel.EASY, QuestionType.MCQ));

        list.add(new Template(
                "Explain how " + topic + " exploits optimal substructure or recurrence relations in " + module + ".",
                "", "", "", "",
                "The algorithm breaks down problem instances of " + topic + " into smaller subproblems and combines their optimal solutions.",
                "Subproblem decomposition and state space representation for " + topic,
                BloomLevel.UNDERSTAND, DifficultyLevel.MEDIUM, QuestionType.SHORT_ANSWER));

        list.add(new Template(
                "Analyze the worst-case and average-case asymptotic complexity of " + topic + " and discuss practical constraints.",
                "", "", "", "",
                "Detailed mathematical breakdown of time and space bounds for " + topic + " with respect to input dimensions.",
                "Complexity analysis and boundary considerations.",
                BloomLevel.ANALYZE, DifficultyLevel.HARD, QuestionType.DESCRIPTIVE));

        return list;
    }

    private static Template createDynamicVariant(String topic, String module, String content, int variantId,
                                                QuestionType type, DifficultyLevel diff, BloomLevel bloom) {
        String[] prefixes = {
                "Investigate the edge-case performance of ",
                "Design a modified version of ",
                "Evaluate the correctness invariant of ",
                "Compare the memory overhead of ",
                "Formulate an optimal recurrence for "
        };
        String prefix = prefixes[variantId % prefixes.length];

        if (type == QuestionType.MCQ) {
            return new Template(
                    "Which of the following assertions regarding " + topic + " (Variant #" + variantId + ") is mathematically valid?",
                    "It guarantees optimal bounds under standard computational model assumptions",
                    "It requires exponential time on all input sequences",
                    "It can only execute on directed acyclic graphs",
                    "It cannot be implemented with deterministic state transitions",
                    "A", "Standard theoretical properties hold for " + topic,
                    bloom, diff, QuestionType.MCQ);
        } else if (type == QuestionType.SHORT_ANSWER) {
            return new Template(
                    prefix + topic + " when applied to sparse or degenerate inputs.",
                    "", "", "", "",
                    "Key edge cases require verifying empty inputs, repeated elements, and single-node transitions.",
                    "Edge case analysis for " + topic,
                    bloom, diff, QuestionType.SHORT_ANSWER);
        } else {
            return new Template(
                    "Critically assess " + topic + " within " + module + " (Scenario #" + variantId + "), providing mathematical proofs of correctness.",
                    "", "", "", "",
                    "Comprehensive algorithmic derivation, loop invariants, and asymptotic proof.",
                    "In-depth theoretical appraisal.",
                    bloom, diff, QuestionType.DESCRIPTIVE);
        }
    }
}
