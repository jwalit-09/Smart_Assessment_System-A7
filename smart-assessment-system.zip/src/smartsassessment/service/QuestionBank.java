package smartsassessment.service;

import smartsassessment.algorithms.KMP;
import smartsassessment.model.BloomLevel;
import smartsassessment.model.DifficultyLevel;
import smartsassessment.model.Question;
import smartsassessment.model.QuestionType;

import java.util.ArrayList;
import java.util.List;

/**
 * Repository and management service for Assessment Questions.
 * Supports adding, removing, updating, querying, filtering, and KMP-powered searching.
 */
public class QuestionBank {

    private final List<Question> questions;

    public QuestionBank() {
        this.questions = new ArrayList<>();
    }

    public QuestionBank(List<Question> initialQuestions) {
        this.questions = new ArrayList<>(initialQuestions != null ? initialQuestions : new ArrayList<>());
    }

    public boolean addQuestion(Question question) {
        if (question == null || question.getQuestionId() == null) {
            return false;
        }
        for (Question q : questions) {
            if (q.getQuestionId().equalsIgnoreCase(question.getQuestionId())) {
                return false; // Duplicate ID
            }
        }
        questions.add(question);
        return true;
    }

    public boolean removeQuestion(String questionId) {
        if (questionId == null) return false;
        return questions.removeIf(q -> q.getQuestionId().equalsIgnoreCase(questionId));
    }

    public boolean updateQuestion(Question updated) {
        if (updated == null || updated.getQuestionId() == null) return false;
        for (int i = 0; i < questions.size(); i++) {
            if (questions.get(i).getQuestionId().equalsIgnoreCase(updated.getQuestionId())) {
                questions.set(i, updated);
                return true;
            }
        }
        return false;
    }

    public Question findQuestionById(String id) {
        if (id == null) return null;
        for (Question q : questions) {
            if (q.getQuestionId().equalsIgnoreCase(id)) {
                return q;
            }
        }
        return null;
    }

    /**
     * Searches for questions matching pattern in text or topic using custom KMP string matching.
     */
    public List<Question> searchQuestion(String pattern) {
        List<Question> results = new ArrayList<>();
        if (pattern == null || pattern.trim().isEmpty()) {
            return results;
        }

        String lowerPattern = pattern.trim().toLowerCase();

        for (Question q : questions) {
            String targetText = (q.getQuestionText() + " " + q.getTopic() + " " + q.getExplanation()).toLowerCase();
            KMP.SearchResult match = KMP.search(targetText, lowerPattern);
            if (match.isFound()) {
                results.add(q);
            }
        }

        return results;
    }

    public void displayAllQuestions() {
        if (questions.isEmpty()) {
            System.out.println("  [Question Bank is currently empty]");
            return;
        }
        System.out.println("\n=========================================================================================");
        System.out.printf("%-6s | %-10s | %-16s | %-12s | %-7s | %-10s | %-5s%n",
                "ID", "Module", "Topic", "Type", "Diff", "Bloom", "Marks");
        System.out.println("-----------------------------------------------------------------------------------------");
        for (Question q : questions) {
            System.out.printf("%-6s | %-10s | %-16s | %-12s | %-7s | %-10s | %-5d%n",
                    q.getQuestionId(),
                    truncate(q.getModule(), 10),
                    truncate(q.getTopic(), 16),
                    q.getQuestionType(),
                    q.getDifficulty(),
                    q.getBloomLevel(),
                    q.getMarks());
        }
        System.out.println("=========================================================================================");
        System.out.println("Total questions: " + questions.size());
    }

    private String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() > max ? s.substring(0, max - 3) + "..." : s;
    }

    public List<Question> filterByModule(String module) {
        List<Question> res = new ArrayList<>();
        if (module == null) return res;
        for (Question q : questions) {
            if (q.getModule() != null && q.getModule().equalsIgnoreCase(module.trim())) {
                res.add(q);
            }
        }
        return res;
    }

    public List<Question> filterByTopic(String topic) {
        List<Question> res = new ArrayList<>();
        if (topic == null) return res;
        for (Question q : questions) {
            if (q.getTopic() != null && q.getTopic().equalsIgnoreCase(topic.trim())) {
                res.add(q);
            }
        }
        return res;
    }

    public List<Question> filterByDifficulty(DifficultyLevel difficulty) {
        List<Question> res = new ArrayList<>();
        for (Question q : questions) {
            if (q.getDifficulty() == difficulty) {
                res.add(q);
            }
        }
        return res;
    }

    public List<Question> filterByBloomLevel(BloomLevel bloomLevel) {
        List<Question> res = new ArrayList<>();
        for (Question q : questions) {
            if (q.getBloomLevel() == bloomLevel) {
                res.add(q);
            }
        }
        return res;
    }

    public List<Question> filterByType(QuestionType type) {
        List<Question> res = new ArrayList<>();
        for (Question q : questions) {
            if (q.getQuestionType() == type) {
                res.add(q);
            }
        }
        return res;
    }

    public int getQuestionCount() {
        return questions.size();
    }

    public List<Question> getQuestions() {
        return new ArrayList<>(questions);
    }
}
