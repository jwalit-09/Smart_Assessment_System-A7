package smartsassessment.service;

import smartsassessment.model.BloomLevel;
import smartsassessment.model.DifficultyLevel;
import smartsassessment.model.QuestionType;

/**
 * Predicts question difficulty tier (EASY, MEDIUM, HARD) based on multiple pedagogical factors:
 * - Bloom's Taxonomy cognitive level
 * - Question format (MCQ, SHORT_ANSWER, DESCRIPTIVE)
 * - Concept count and algorithmic complexity indicators
 * - Reasoning and calculation requirements
 */
public class DifficultyClassifier {

    public static class DifficultyAnalysis {
        private final DifficultyLevel predictedLevel;
        private final int score;
        private final String rationale;

        public DifficultyAnalysis(DifficultyLevel predictedLevel, int score, String rationale) {
            this.predictedLevel = predictedLevel;
            this.score = score;
            this.rationale = rationale;
        }

        public DifficultyLevel getPredictedLevel() { return predictedLevel; }
        public int getScore() { return score; }
        public String getRationale() { return rationale; }
    }

    /**
     * Classifies difficulty based on question properties.
     */
    public static DifficultyLevel classify(String questionText, QuestionType type, BloomLevel bloom) {
        return analyze(questionText, type, bloom).getPredictedLevel();
    }

    public static DifficultyAnalysis analyze(String questionText, QuestionType type, BloomLevel bloom) {
        if (questionText == null) questionText = "";
        String text = questionText.toLowerCase();

        int score = 0;
        StringBuilder rationale = new StringBuilder();

        // 1. Cognitive Level weighting (0 - 5 points)
        switch (bloom) {
            case REMEMBER:
                score += 1;
                rationale.append("Bloom: REMEMBER (+1). ");
                break;
            case UNDERSTAND:
                score += 2;
                rationale.append("Bloom: UNDERSTAND (+2). ");
                break;
            case APPLY:
                score += 3;
                rationale.append("Bloom: APPLY (+3). ");
                break;
            case ANALYZE:
                score += 4;
                rationale.append("Bloom: ANALYZE (+4). ");
                break;
            case EVALUATE:
                score += 5;
                rationale.append("Bloom: EVALUATE (+5). ");
                break;
            case CREATE:
                score += 5;
                rationale.append("Bloom: CREATE (+5). ");
                break;
        }

        // 2. Question Type weighting (1 - 3 points)
        switch (type) {
            case MCQ:
                score += 1;
                rationale.append("Format: MCQ (+1). ");
                break;
            case SHORT_ANSWER:
                score += 2;
                rationale.append("Format: Short Answer (+2). ");
                break;
            case DESCRIPTIVE:
                score += 3;
                rationale.append("Format: Descriptive (+3). ");
                break;
        }

        // 3. Algorithmic Complexity / Concept density markers (+1 to +2 points)
        String[] advancedKeywords = {
                "dynamic programming", "bitmask", "hamiltonian", "rerooting", "sos dp",
                "kasai", "aho-corasick", "miller-rabin", "max flow", "edmonds-karp",
                "matrix chain", "recurrence", "asymptotic", "np-hard", "proof"
        };
        int advancedHits = 0;
        for (String kw : advancedKeywords) {
            if (text.contains(kw)) {
                advancedHits++;
            }
        }
        if (advancedHits >= 2) {
            score += 2;
            rationale.append("High algorithmic concept density (+2). ");
        } else if (advancedHits == 1) {
            score += 1;
            rationale.append("Moderate algorithmic complexity (+1). ");
        }

        // 4. Calculation / Multi-step requirement (+1 point)
        if (text.contains("calculate") || text.contains("compute") || text.contains("trace") ||
            text.contains("derive") || text.contains("dp table") || text.contains("matrix")) {
            score += 1;
            rationale.append("Multi-step calculation/tracing required (+1). ");
        }

        // Determine tier based on total composite score:
        // <= 4: EASY
        // 5 - 7: MEDIUM
        // >= 8: HARD
        DifficultyLevel level;
        if (score <= 4) {
            level = DifficultyLevel.EASY;
        } else if (score <= 7) {
            level = DifficultyLevel.MEDIUM;
        } else {
            level = DifficultyLevel.HARD;
        }

        return new DifficultyAnalysis(level, score, rationale.toString().trim());
    }
}
