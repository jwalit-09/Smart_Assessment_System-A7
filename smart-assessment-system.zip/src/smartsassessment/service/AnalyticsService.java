package smartsassessment.service;

import smartsassessment.model.Performance;

import java.util.*;

/**
 * Performance Analytics and Reporting Engine.
 * Computes cohort and individual analytics, identifies weak knowledge areas,
 * and calculates dimensional metrics across modules, topics, difficulties, and Bloom levels.
 */
public class AnalyticsService {

    public static class OverallAnalytics {
        private final int totalAssessmentsTaken;
        private final double averagePercentage;
        private final double highestPercentage;
        private final double lowestPercentage;
        private final double averageAccuracy;
        private final Map<String, Double> moduleAverages;
        private final Map<String, Double> topicAverages;
        private final Map<String, Double> difficultyAverages;
        private final Map<String, Double> bloomAverages;
        private final List<String> weakAreas;

        public OverallAnalytics(int totalAssessmentsTaken, double averagePercentage,
                                double highestPercentage, double lowestPercentage,
                                double averageAccuracy, Map<String, Double> moduleAverages,
                                Map<String, Double> topicAverages, Map<String, Double> difficultyAverages,
                                Map<String, Double> bloomAverages, List<String> weakAreas) {
            this.totalAssessmentsTaken = totalAssessmentsTaken;
            this.averagePercentage = averagePercentage;
            this.highestPercentage = highestPercentage;
            this.lowestPercentage = lowestPercentage;
            this.averageAccuracy = averageAccuracy;
            this.moduleAverages = moduleAverages;
            this.topicAverages = topicAverages;
            this.difficultyAverages = difficultyAverages;
            this.bloomAverages = bloomAverages;
            this.weakAreas = weakAreas;
        }

        public int getTotalAssessmentsTaken() { return totalAssessmentsTaken; }
        public double getAveragePercentage() { return averagePercentage; }
        public double getHighestPercentage() { return highestPercentage; }
        public double getLowestPercentage() { return lowestPercentage; }
        public double getAverageAccuracy() { return averageAccuracy; }
        public Map<String, Double> getModuleAverages() { return moduleAverages; }
        public Map<String, Double> getTopicAverages() { return topicAverages; }
        public Map<String, Double> getDifficultyAverages() { return difficultyAverages; }
        public Map<String, Double> getBloomAverages() { return bloomAverages; }
        public List<String> getWeakAreas() { return weakAreas; }

        public void printReport() {
            System.out.println("\n========================================================================");
            System.out.println("                     PERFORMANCE ANALYTICS DASHBOARD                    ");
            System.out.println("========================================================================");
            System.out.printf("Total Submissions Evaluated: %d%n", totalAssessmentsTaken);
            System.out.printf("Cohort Average Percentage:   %.2f%%%n", averagePercentage);
            System.out.printf("Highest Score Achieved:      %.2f%%%n", highestPercentage);
            System.out.printf("Lowest Score Achieved:       %.2f%%%n", lowestPercentage);
            System.out.printf("Average Question Accuracy:   %.2f%%%n", averageAccuracy);

            System.out.println("\n--- Module-Wise Performance ---");
            printSortedMap(moduleAverages, "%");

            System.out.println("\n--- Topic-Wise Performance ---");
            printSortedMap(topicAverages, "%");

            System.out.println("\n--- Difficulty-Wise Performance ---");
            printSortedMap(difficultyAverages, "%");

            System.out.println("\n--- Bloom's Taxonomy Cognitive Performance ---");
            printSortedMap(bloomAverages, "%");

            System.out.println("\n--- Identified Diagnostic Weak Areas (< 65% Score) ---");
            if (weakAreas.isEmpty()) {
                System.out.println("  Great job! No significant weak areas detected across tested topics.");
            } else {
                for (String weak : weakAreas) {
                    System.out.println("  [!] " + weak);
                }
            }
            System.out.println("========================================================================");
        }

        private void printSortedMap(Map<String, Double> map, String unit) {
            if (map == null || map.isEmpty()) {
                System.out.println("  (No data available)");
                return;
            }
            List<Map.Entry<String, Double>> list = new ArrayList<>(map.entrySet());
            list.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
            for (Map.Entry<String, Double> e : list) {
                System.out.printf("  %-24s: %6.2f%s%n", e.getKey(), e.getValue(), unit);
            }
        }
    }

    /**
     * Computes cohort analytics across all stored results.
     */
    public static OverallAnalytics computeAnalytics(List<Performance> results) {
        if (results == null || results.isEmpty()) {
            return new OverallAnalytics(0, 0, 0, 0, 0,
                    Collections.emptyMap(), Collections.emptyMap(),
                    Collections.emptyMap(), Collections.emptyMap(), Collections.emptyList());
        }

        int count = results.size();
        double sumPct = 0;
        double maxPct = Double.MIN_VALUE;
        double minPct = Double.MAX_VALUE;
        double sumAcc = 0;

        Map<String, List<Double>> moduleScores = new HashMap<>();
        Map<String, List<Double>> topicScores = new HashMap<>();
        Map<String, List<Double>> diffScores = new HashMap<>();
        Map<String, List<Double>> bloomScores = new HashMap<>();

        for (Performance p : results) {
            double pct = p.getPercentage();
            sumPct += pct;
            maxPct = Math.max(maxPct, pct);
            minPct = Math.min(minPct, pct);
            sumAcc += p.getAccuracy();

            accumulateMap(moduleScores, p.getModuleBreakdown());
            accumulateMap(topicScores, p.getTopicBreakdown());
            accumulateMap(diffScores, p.getDifficultyBreakdown());
            accumulateMap(bloomScores, p.getBloomBreakdown());
        }

        Map<String, Double> moduleAvg = averageMap(moduleScores);
        Map<String, Double> topicAvg = averageMap(topicScores);
        Map<String, Double> diffAvg = averageMap(diffScores);
        Map<String, Double> bloomAvg = averageMap(bloomScores);

        List<String> weakAreas = new ArrayList<>();
        for (Map.Entry<String, Double> entry : topicAvg.entrySet()) {
            if (entry.getValue() < 65.0) {
                weakAreas.add(String.format("Topic '%s': Scoring at %.1f%% - recommended review of fundamental recurrence/matching algorithms.",
                        entry.getKey(), entry.getValue()));
            }
        }

        return new OverallAnalytics(
                count,
                sumPct / count,
                maxPct,
                minPct,
                sumAcc / count,
                moduleAvg,
                topicAvg,
                diffAvg,
                bloomAvg,
                weakAreas
        );
    }

    private static void accumulateMap(Map<String, List<Double>> dest, Map<String, Double> src) {
        if (src == null) return;
        for (Map.Entry<String, Double> entry : src.entrySet()) {
            dest.computeIfAbsent(entry.getKey(), k -> new ArrayList<>()).add(entry.getValue());
        }
    }

    private static Map<String, Double> averageMap(Map<String, List<Double>> map) {
        Map<String, Double> avg = new HashMap<>();
        for (Map.Entry<String, List<Double>> entry : map.entrySet()) {
            double sum = 0;
            for (double d : entry.getValue()) sum += d;
            avg.put(entry.getKey(), Math.round((sum / entry.getValue().size()) * 10.0) / 10.0);
        }
        return avg;
    }
}
