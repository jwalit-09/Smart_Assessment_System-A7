package smartsassessment.service;

import smartsassessment.model.*;
import smartsassessment.util.IdGenerator;

import java.time.LocalDate;
import java.util.*;

/**
 * Smart Assessment Generator.
 * Selects questions from QuestionBank meeting strict pedagogical distribution criteria:
 * - Module and topic constraints
 * - Difficulty distribution percentages (EASY, MEDIUM, HARD)
 * - Bloom's Taxonomy distribution percentages
 * - Question type constraints
 * - Deduplication guarantees
 *
 * If criteria cannot be strictly satisfied, provides an exact diagnostic deficit breakdown
 * instead of silently producing an unbalanced paper.
 */
public class AssessmentGenerator {

    public static class GenerationResult {
        private final boolean success;
        private final Assessment assessment;
        private final List<Question> selectedQuestions;
        private final List<String> deficitErrors;

        public GenerationResult(boolean success, Assessment assessment,
                                List<Question> selectedQuestions, List<String> deficitErrors) {
            this.success = success;
            this.assessment = assessment;
            this.selectedQuestions = selectedQuestions;
            this.deficitErrors = deficitErrors;
        }

        public boolean isSuccess() { return success; }
        public Assessment getAssessment() { return assessment; }
        public List<Question> getSelectedQuestions() { return selectedQuestions; }
        public List<String> getDeficitErrors() { return deficitErrors; }
    }

    /**
     * Generates a balanced assessment or returns explicit deficit errors.
     */
    public static GenerationResult generate(
            QuestionBank bank,
            String title,
            String module,
            List<String> topics,
            int totalQuestions,
            int durationMinutes,
            Map<DifficultyLevel, Integer> difficultyDist,
            Map<BloomLevel, Integer> bloomDist,
            QuestionType requiredType) {

        List<String> deficitMessages = new ArrayList<>();

        if (totalQuestions <= 0) {
            deficitMessages.add("Total questions must be greater than zero.");
            return new GenerationResult(false, null, null, deficitMessages);
        }

        // Filter candidate questions by module and optional topics / type
        List<Question> candidates = new ArrayList<>();
        for (Question q : bank.getQuestions()) {
            if (module != null && !module.equalsIgnoreCase("ALL") &&
                !q.getModule().equalsIgnoreCase(module.trim())) {
                continue;
            }
            if (topics != null && !topics.isEmpty()) {
                boolean topicMatch = false;
                for (String t : topics) {
                    if (q.getTopic().equalsIgnoreCase(t.trim())) {
                        topicMatch = true;
                        break;
                    }
                }
                if (!topicMatch) continue;
            }
            if (requiredType != null && q.getQuestionType() != requiredType) {
                continue;
            }
            candidates.add(q);
        }

        if (candidates.size() < totalQuestions) {
            deficitMessages.add(String.format(
                    "Insufficient candidate questions available in bank. Requested: %d, Available matching filters: %d.",
                    totalQuestions, candidates.size()));
            return new GenerationResult(false, null, null, deficitMessages);
        }

        // Calculate expected target counts for difficulty
        Map<DifficultyLevel, Integer> targetDiffCount = new HashMap<>();
        int allocatedDiff = 0;
        for (DifficultyLevel diff : DifficultyLevel.values()) {
            int pct = difficultyDist.getOrDefault(diff, 0);
            int count = (int) Math.round((pct / 100.0) * totalQuestions);
            targetDiffCount.put(diff, count);
            allocatedDiff += count;
        }
        // Adjust rounding discrepancies to match exact total
        if (allocatedDiff != totalQuestions) {
            targetDiffCount.put(DifficultyLevel.MEDIUM,
                    targetDiffCount.get(DifficultyLevel.MEDIUM) + (totalQuestions - allocatedDiff));
        }

        // Verify difficulty availability
        Map<DifficultyLevel, List<Question>> poolByDiff = new HashMap<>();
        for (DifficultyLevel diff : DifficultyLevel.values()) {
            poolByDiff.put(diff, new ArrayList<>());
        }
        for (Question q : candidates) {
            poolByDiff.get(q.getDifficulty()).add(q);
        }

        for (Map.Entry<DifficultyLevel, Integer> entry : targetDiffCount.entrySet()) {
            int required = entry.getValue();
            int available = poolByDiff.get(entry.getKey()).size();
            if (available < required) {
                deficitMessages.add(String.format(
                        "Difficulty Deficit: Needed %d %s questions (%d%%), but only %d are available in bank.",
                        required, entry.getKey(), difficultyDist.getOrDefault(entry.getKey(), 0), available));
            }
        }

        // Calculate target counts for Bloom levels
        Map<BloomLevel, Integer> targetBloomCount = new HashMap<>();
        int allocatedBloom = 0;
        for (BloomLevel bloom : BloomLevel.values()) {
            int pct = bloomDist.getOrDefault(bloom, 0);
            int count = (int) Math.round((pct / 100.0) * totalQuestions);
            targetBloomCount.put(bloom, count);
            allocatedBloom += count;
        }
        if (allocatedBloom != totalQuestions) {
            targetBloomCount.put(BloomLevel.UNDERSTAND,
                    targetBloomCount.get(BloomLevel.UNDERSTAND) + (totalQuestions - allocatedBloom));
        }

        // Check Bloom level availability
        Map<BloomLevel, List<Question>> poolByBloom = new HashMap<>();
        for (BloomLevel bloom : BloomLevel.values()) {
            poolByBloom.put(bloom, new ArrayList<>());
        }
        for (Question q : candidates) {
            poolByBloom.get(q.getBloomLevel()).add(q);
        }

        for (Map.Entry<BloomLevel, Integer> entry : targetBloomCount.entrySet()) {
            int required = entry.getValue();
            int available = poolByBloom.get(entry.getKey()).size();
            if (available < required) {
                deficitMessages.add(String.format(
                        "Bloom Level Deficit: Needed %d %s questions (%d%%), but only %d are available in bank.",
                        required, entry.getKey(), bloomDist.getOrDefault(entry.getKey(), 0), available));
            }
        }

        if (!deficitMessages.isEmpty()) {
            return new GenerationResult(false, null, null, deficitMessages);
        }

        // Selection algorithm: Greedy constraint satisfaction with duplicate detection
        List<Question> selected = new ArrayList<>();
        Set<String> selectedIds = new HashSet<>();

        // Sort candidates to prioritize rarer Bloom & Difficulty requirements
        List<Question> shuffledCandidates = new ArrayList<>(candidates);
        Collections.shuffle(shuffledCandidates, new Random(42)); // deterministic shuffle

        Map<DifficultyLevel, Integer> currDiffCount = new HashMap<>();
        Map<BloomLevel, Integer> currBloomCount = new HashMap<>();

        for (Question q : shuffledCandidates) {
            if (selected.size() == totalQuestions) break;

            DifficultyLevel d = q.getDifficulty();
            BloomLevel b = q.getBloomLevel();

            int targetD = targetDiffCount.getOrDefault(d, 0);
            int currD = currDiffCount.getOrDefault(d, 0);
            int targetB = targetBloomCount.getOrDefault(b, 0);
            int currB = currBloomCount.getOrDefault(b, 0);

            if (currD < targetD && currB < targetB) {
                // Ensure not near-duplicate of already selected question
                boolean isDuplicate = false;
                for (Question sel : selected) {
                    if (DuplicateDetector.compare(q, sel).getVerdict() == DuplicateDetector.MatchVerdict.DUPLICATE) {
                        isDuplicate = true;
                        break;
                    }
                }
                if (!isDuplicate) {
                    selected.add(q);
                    selectedIds.add(q.getQuestionId());
                    currDiffCount.put(d, currD + 1);
                    currBloomCount.put(b, currB + 1);
                }
            }
        }

        // Second pass if strict joint intersection was slightly short: satisfy remaining by difficulty
        if (selected.size() < totalQuestions) {
            for (Question q : shuffledCandidates) {
                if (selected.size() == totalQuestions) break;
                if (selectedIds.contains(q.getQuestionId())) continue;

                DifficultyLevel d = q.getDifficulty();
                int targetD = targetDiffCount.getOrDefault(d, 0);
                int currD = currDiffCount.getOrDefault(d, 0);

                if (currD < targetD) {
                    boolean isDuplicate = false;
                    for (Question sel : selected) {
                        if (DuplicateDetector.compare(q, sel).getVerdict() == DuplicateDetector.MatchVerdict.DUPLICATE) {
                            isDuplicate = true;
                            break;
                        }
                    }
                    if (!isDuplicate) {
                        selected.add(q);
                        selectedIds.add(q.getQuestionId());
                        currDiffCount.put(d, currD + 1);
                        currBloomCount.put(q.getBloomLevel(), currBloomCount.getOrDefault(q.getBloomLevel(), 0) + 1);
                    }
                }
            }
        }

        if (selected.size() < totalQuestions) {
            deficitMessages.add(String.format(
                    "Unable to satisfy the requested distribution without duplicate questions. Selected %d / %d.",
                    selected.size(), totalQuestions));
            return new GenerationResult(false, null, null, deficitMessages);
        }

        int totalMarks = 0;
        List<String> questionIdList = new ArrayList<>();
        for (Question q : selected) {
            totalMarks += q.getMarks();
            questionIdList.add(q.getQuestionId());
        }

        String assessmentId = IdGenerator.nextAssessmentId();
        Assessment assessment = new Assessment(
                assessmentId,
                title,
                "Advanced Algorithms",
                module,
                topics != null ? topics : new ArrayList<>(),
                questionIdList,
                totalMarks,
                durationMinutes,
                LocalDate.now().toString()
        );

        return new GenerationResult(true, assessment, selected, Collections.emptyList());
    }
}
