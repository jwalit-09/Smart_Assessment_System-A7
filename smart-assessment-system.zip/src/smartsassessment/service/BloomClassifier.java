package smartsassessment.service;

import smartsassessment.model.BloomLevel;

import java.util.*;

/**
 * Classifies educational questions into Bloom's Revised Taxonomy levels
 * based on keyword patterns, cognitive verbs, and syntactic structure.
 */
public class BloomClassifier {

    private static final Map<BloomLevel, List<String>> KEYWORD_RULES = new LinkedHashMap<>();

    static {
        KEYWORD_RULES.put(BloomLevel.CREATE, Arrays.asList(
                "design", "develop", "create", "formulate", "construct", "devise", "synthesize", "generate", "invent"
        ));
        KEYWORD_RULES.put(BloomLevel.EVALUATE, Arrays.asList(
                "evaluate", "justify", "critically assess", "judge", "validate", "appraise", "defend", "critique", "verify"
        ));
        KEYWORD_RULES.put(BloomLevel.ANALYZE, Arrays.asList(
                "compare", "analyze", "differentiate", "distinguish", "deconstruct", "examine", "contrast", "break down", "categorize"
        ));
        KEYWORD_RULES.put(BloomLevel.APPLY, Arrays.asList(
                "calculate", "implement", "apply", "execute", "solve", "compute", "simulate", "run", "trace", "use"
        ));
        KEYWORD_RULES.put(BloomLevel.UNDERSTAND, Arrays.asList(
                "explain", "describe", "summarize", "interpret", "illustrate", "discuss", "clarify", "outline", "paraphrase"
        ));
        KEYWORD_RULES.put(BloomLevel.REMEMBER, Arrays.asList(
                "define", "what is", "list", "state", "recall", "name", "identify", "which of the following", "mention", "state the"
        ));
    }

    /**
     * Classifies a question text into the appropriate BloomLevel.
     */
    public static BloomLevel classify(String questionText) {
        if (questionText == null || questionText.trim().isEmpty()) {
            return BloomLevel.REMEMBER;
        }

        String lower = questionText.toLowerCase();

        // Higher-order cognitive verbs take precedence if matched
        for (Map.Entry<BloomLevel, List<String>> entry : KEYWORD_RULES.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (lower.contains(keyword)) {
                    return entry.getKey();
                }
            }
        }

        return BloomLevel.UNDERSTAND;
    }

    /**
     * Explains the classification rationale for a given question.
     */
    public static String getClassificationRationale(String questionText, BloomLevel level) {
        String lower = questionText.toLowerCase();
        List<String> keywords = KEYWORD_RULES.get(level);
        if (keywords != null) {
            for (String kw : keywords) {
                if (lower.contains(kw)) {
                    return "Matched action verb / keyword: '" + kw + "' -> classified as " + level;
                }
            }
        }
        return "Defaulted based on general cognitive requirement -> " + level;
    }
}
