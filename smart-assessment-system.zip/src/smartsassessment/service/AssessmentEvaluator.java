package smartsassessment.service;

import smartsassessment.algorithms.CosineSimilarity;
import smartsassessment.algorithms.EditDistance;
import smartsassessment.algorithms.TFIDF;
import smartsassessment.model.*;
import smartsassessment.util.IdGenerator;

import java.time.LocalDate;
import java.util.*;

/**
 * Automatic Assessment Evaluation Service.
 * Evaluates student responses across:
 * 1. MCQ: Strict option verification (A, B, C, D)
 * 2. SHORT_ANSWER: Levenshtein edit-distance tolerance & keyword overlap
 * 3. DESCRIPTIVE: Concept keyword coverage and TF-IDF / Cosine semantic similarity with partial marking
 */
public class AssessmentEvaluator {

    public static Performance evaluate(Assessment assessment, Student student,
                                       List<Question> questions, Map<String, String> studentAnswers) {
        List<Answer> evaluatedAnswers = new ArrayList<>();
        int totalScore = 0;
        int totalMarks = 0;
        int correctCount = 0;

        Map<String, int[]> topicScores = new HashMap<>(); // [earned, max]
        Map<String, int[]> moduleScores = new HashMap<>();
        Map<String, int[]> diffScores = new HashMap<>();
        Map<String, int[]> bloomScores = new HashMap<>();

        for (Question q : questions) {
            String studentAns = studentAnswers.getOrDefault(q.getQuestionId(), "").trim();
            int maxMarks = q.getMarks();
            totalMarks += maxMarks;

            int awardedMarks = 0;
            boolean isCorrect = false;
            String feedback;

            if (q.getQuestionType() == QuestionType.MCQ) {
                // Exact choice check
                String correctChoice = q.getCorrectAnswer() != null ? q.getCorrectAnswer().trim().toUpperCase() : "";
                String userChoice = studentAns.toUpperCase();

                if (userChoice.equals(correctChoice) ||
                    (correctChoice.startsWith("A") && userChoice.startsWith("A")) ||
                    (correctChoice.startsWith("B") && userChoice.startsWith("B")) ||
                    (correctChoice.startsWith("C") && userChoice.startsWith("C")) ||
                    (correctChoice.startsWith("D") && userChoice.startsWith("D"))) {
                    awardedMarks = maxMarks;
                    isCorrect = true;
                    correctCount++;
                    feedback = "Correct choice selected.";
                } else {
                    awardedMarks = 0;
                    feedback = "Incorrect. Correct choice was: " + correctChoice;
                }
            } else if (q.getQuestionType() == QuestionType.SHORT_ANSWER) {
                // Short answer: keyword matching and edit distance
                awardedMarks = evaluateShortAnswer(studentAns, q.getCorrectAnswer(), maxMarks);
                isCorrect = (awardedMarks >= (maxMarks * 0.7));
                if (isCorrect) correctCount++;
                feedback = String.format("Score: %d/%d based on keyword matching and term similarity.", awardedMarks, maxMarks);
            } else {
                // Descriptive: concept keyword coverage & semantic similarity
                awardedMarks = evaluateDescriptive(studentAns, q.getCorrectAnswer(), q.getExplanation(), maxMarks);
                isCorrect = (awardedMarks >= (maxMarks * 0.6));
                if (isCorrect) correctCount++;
                feedback = String.format("Score: %d/%d based on concept coverage and rubric keywords.", awardedMarks, maxMarks);
            }

            totalScore += awardedMarks;

            Answer ans = new Answer(
                    assessment.getAssessmentId(),
                    q.getQuestionId(),
                    student.getStudentId(),
                    studentAns,
                    awardedMarks,
                    maxMarks,
                    isCorrect,
                    feedback
            );
            evaluatedAnswers.add(ans);

            // Accumulate breakdown scores
            accumulate(topicScores, q.getTopic(), awardedMarks, maxMarks);
            accumulate(moduleScores, q.getModule(), awardedMarks, maxMarks);
            accumulate(diffScores, q.getDifficulty().name(), awardedMarks, maxMarks);
            accumulate(bloomScores, q.getBloomLevel().name(), awardedMarks, maxMarks);
        }

        double percentage = (totalMarks > 0) ? ((double) totalScore / totalMarks) * 100.0 : 0.0;
        double accuracy = (!questions.isEmpty()) ? ((double) correctCount / questions.size()) * 100.0 : 0.0;

        Performance perf = new Performance(
                IdGenerator.nextResultId(),
                student.getStudentId(),
                student.getName(),
                assessment.getAssessmentId(),
                totalScore,
                totalMarks,
                percentage,
                accuracy,
                LocalDate.now().toString(),
                evaluatedAnswers
        );

        perf.setTopicBreakdown(toPercentageMap(topicScores));
        perf.setModuleBreakdown(toPercentageMap(moduleScores));
        perf.setDifficultyBreakdown(toPercentageMap(diffScores));
        perf.setBloomBreakdown(toPercentageMap(bloomScores));

        return perf;
    }

    private static int evaluateShortAnswer(String studentAns, String correctAns, int maxMarks) {
        if (studentAns == null || studentAns.trim().isEmpty()) return 0;
        if (correctAns == null || correctAns.trim().isEmpty()) return maxMarks;

        String sClean = studentAns.trim().toLowerCase();
        String cClean = correctAns.trim().toLowerCase();

        // Exact match
        if (sClean.equals(cClean)) return maxMarks;

        // Levenshtein distance check for minor typos
        EditDistance.Result ed = EditDistance.calculate(sClean, cClean);
        int maxLen = Math.max(sClean.length(), cClean.length());
        double editSim = (maxLen > 0) ? 1.0 - ((double) ed.getDistance() / maxLen) : 1.0;
        if (editSim >= 0.80) {
            return (int) Math.round(maxMarks * editSim);
        }

        // Token overlap
        List<String> sTokens = TFIDF.tokenize(sClean);
        List<String> cTokens = TFIDF.tokenize(cClean);
        if (cTokens.isEmpty()) return 0;

        int matches = 0;
        for (String ct : cTokens) {
            if (sTokens.contains(ct)) {
                matches++;
            }
        }
        double overlap = (double) matches / cTokens.size();
        return (int) Math.round(maxMarks * overlap);
    }

    private static int evaluateDescriptive(String studentAns, String correctAns, String explanation, int maxMarks) {
        if (studentAns == null || studentAns.trim().isEmpty()) return 0;

        String reference = (correctAns != null ? correctAns : "") + " " + (explanation != null ? explanation : "");
        if (reference.trim().isEmpty()) return (int) (maxMarks * 0.7);

        // Vector cosine similarity
        List<String> corpus = Arrays.asList(studentAns, reference);
        TFIDF tfidf = new TFIDF(corpus);
        double[] sVec = tfidf.transform(studentAns);
        double[] refVec = tfidf.transform(reference);
        double similarity = CosineSimilarity.compute(sVec, refVec);

        // Keyword coverage
        List<String> refTokens = TFIDF.tokenize(reference);
        List<String> sTokens = TFIDF.tokenize(studentAns);
        Set<String> uniqueRef = new HashSet<>(refTokens);
        int hits = 0;
        for (String rt : uniqueRef) {
            if (sTokens.contains(rt)) {
                hits++;
            }
        }
        double coverage = uniqueRef.isEmpty() ? 0.0 : (double) hits / uniqueRef.size();

        // Weighted combination: 60% semantic similarity + 40% keyword coverage
        double compositeScore = (0.60 * similarity) + (0.40 * coverage);
        int awarded = (int) Math.round(maxMarks * compositeScore);
        return Math.max(0, Math.min(maxMarks, awarded));
    }

    private static void accumulate(Map<String, int[]> map, String key, int earned, int max) {
        if (key == null) key = "Unknown";
        int[] pair = map.getOrDefault(key, new int[2]);
        pair[0] += earned;
        pair[1] += max;
        map.put(key, pair);
    }

    private static Map<String, Double> toPercentageMap(Map<String, int[]> counts) {
        Map<String, Double> pctMap = new HashMap<>();
        for (Map.Entry<String, int[]> entry : counts.entrySet()) {
            int earned = entry.getValue()[0];
            int max = entry.getValue()[1];
            double pct = (max > 0) ? ((double) earned / max) * 100.0 : 0.0;
            pctMap.put(entry.getKey(), Math.round(pct * 10.0) / 10.0);
        }
        return pctMap;
    }

    public static void displayEvaluationReport(Performance perf, List<Question> questions) {
        System.out.println("\n========================================================================");
        System.out.println("                        ASSESSMENT EVALUATION REPORT                    ");
        System.out.println("========================================================================");
        System.out.printf("Result ID:     %s%n", perf.getResultId());
        System.out.printf("Student:       %s (%s)%n", perf.getStudentName(), perf.getStudentId());
        System.out.printf("Assessment ID: %s%n", perf.getAssessmentId());
        System.out.printf("Date:          %s%n", perf.getSubmissionDate());
        System.out.printf("Score:         %d / %d  (%.1f%%)%n", perf.getScore(), perf.getTotalMarks(), perf.getPercentage());
        System.out.printf("Accuracy:      %.1f%%%n", perf.getAccuracy());
        System.out.println("------------------------------------------------------------------------");

        Map<String, Question> qMap = new HashMap<>();
        for (Question q : questions) {
            qMap.put(q.getQuestionId(), q);
        }

        System.out.println("\nDetailed Question Breakdown:");
        for (int i = 0; i < perf.getAnswers().size(); i++) {
            Answer a = perf.getAnswers().get(i);
            Question q = qMap.get(a.getQuestionId());
            System.out.printf("\n[Q%d] %s (%s, %s, %d Marks)%n",
                    (i + 1),
                    q != null ? q.getQuestionText() : "Question " + a.getQuestionId(),
                    q != null ? q.getDifficulty() : "",
                    q != null ? q.getBloomLevel() : "",
                    a.getMaxMarks());

            System.out.println("  Student Answer:  " + (a.getStudentAnswer().isEmpty() ? "(No Answer Provided)" : a.getStudentAnswer()));
            System.out.println("  Correct Answer:  " + (q != null ? q.getCorrectAnswer() : "N/A"));
            System.out.printf("  Marks Awarded:   %d / %d%n", a.getMarksAwarded(), a.getMaxMarks());
            System.out.println("  Feedback:        " + a.getFeedback());
        }
        System.out.println("\n========================================================================");
    }
}
