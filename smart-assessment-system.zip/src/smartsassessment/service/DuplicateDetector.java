package smartsassessment.service;

import smartsassessment.algorithms.CosineSimilarity;
import smartsassessment.algorithms.TFIDF;
import smartsassessment.model.Question;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Detects duplicate and highly similar questions using TF-IDF and Cosine Similarity.
 * Thresholds:
 *   >= 0.85: DUPLICATE
 *   0.70 - 0.84: SIMILAR
 *   < 0.70: DIFFERENT
 */
public class DuplicateDetector {

    public enum MatchVerdict {
        DUPLICATE,
        SIMILAR,
        DIFFERENT
    }

    public static class SimilarityReport {
        private final Question questionA;
        private final Question questionB;
        private final double similarityScore;
        private final MatchVerdict verdict;

        public SimilarityReport(Question questionA, Question questionB, double similarityScore, MatchVerdict verdict) {
            this.questionA = questionA;
            this.questionB = questionB;
            this.similarityScore = similarityScore;
            this.verdict = verdict;
        }

        public Question getQuestionA() { return questionA; }
        public Question getQuestionB() { return questionB; }
        public double getSimilarityScore() { return similarityScore; }
        public MatchVerdict getVerdict() { return verdict; }

        public void printSummary() {
            System.out.println("\n------------------------------------------------------------");
            System.out.printf("Comparison: [%s] vs [%s]%n", questionA.getQuestionId(), questionB.getQuestionId());
            System.out.println("Question A: " + questionA.getQuestionText());
            System.out.println("Question B: " + questionB.getQuestionText());
            System.out.printf("Cosine Similarity: %.2f%%%n", similarityScore * 100);
            System.out.println("Decision:          " + verdict);
            System.out.println("------------------------------------------------------------");
        }
    }

    /**
     * Compares two questions using TF-IDF and Cosine Similarity.
     */
    public static SimilarityReport compare(Question q1, Question q2) {
        List<String> corpus = Arrays.asList(q1.getQuestionText(), q2.getQuestionText());
        TFIDF model = new TFIDF(corpus);

        double[] v1 = model.transform(q1.getQuestionText());
        double[] v2 = model.transform(q2.getQuestionText());

        double similarity = CosineSimilarity.compute(v1, v2);

        MatchVerdict verdict;
        if (similarity >= 0.85) {
            verdict = MatchVerdict.DUPLICATE;
        } else if (similarity >= 0.70) {
            verdict = MatchVerdict.SIMILAR;
        } else {
            verdict = MatchVerdict.DIFFERENT;
        }

        return new SimilarityReport(q1, q2, similarity, verdict);
    }

    /**
     * Compares a candidate question against a collection of existing questions.
     */
    public static List<SimilarityReport> checkAgainstBank(Question candidate, List<Question> bank) {
        List<SimilarityReport> matches = new ArrayList<>();
        if (candidate == null || bank == null || bank.isEmpty()) {
            return matches;
        }

        List<String> corpus = new ArrayList<>();
        corpus.add(candidate.getQuestionText());
        for (Question q : bank) {
            corpus.add(q.getQuestionText());
        }

        TFIDF model = new TFIDF(corpus);
        double[] candidateVec = model.transform(candidate.getQuestionText());

        for (Question q : bank) {
            if (candidate.getQuestionId() != null && candidate.getQuestionId().equals(q.getQuestionId())) {
                continue; // Don't self-compare
            }

            double[] qVec = model.transform(q.getQuestionText());
            double score = CosineSimilarity.compute(candidateVec, qVec);

            MatchVerdict verdict;
            if (score >= 0.85) {
                verdict = MatchVerdict.DUPLICATE;
            } else if (score >= 0.70) {
                verdict = MatchVerdict.SIMILAR;
            } else {
                verdict = MatchVerdict.DIFFERENT;
            }

            if (verdict != MatchVerdict.DIFFERENT) {
                matches.add(new SimilarityReport(candidate, q, score, verdict));
            }
        }

        return matches;
    }

    /**
     * Scans the entire bank for any pairwise duplicate or similar questions.
     */
    public static List<SimilarityReport> scanAllPairs(List<Question> bank) {
        List<SimilarityReport> reports = new ArrayList<>();
        if (bank == null || bank.size() < 2) return reports;

        List<String> corpus = new ArrayList<>();
        for (Question q : bank) {
            corpus.add(q.getQuestionText());
        }
        TFIDF model = new TFIDF(corpus);

        List<double[]> vectors = new ArrayList<>();
        for (Question q : bank) {
            vectors.add(model.transform(q.getQuestionText()));
        }

        for (int i = 0; i < bank.size(); i++) {
            for (int j = i + 1; j < bank.size(); j++) {
                double score = CosineSimilarity.compute(vectors.get(i), vectors.get(j));
                if (score >= 0.70) {
                    MatchVerdict verdict = (score >= 0.85) ? MatchVerdict.DUPLICATE : MatchVerdict.SIMILAR;
                    reports.add(new SimilarityReport(bank.get(i), bank.get(j), score, verdict));
                }
            }
        }

        return reports;
    }
}
