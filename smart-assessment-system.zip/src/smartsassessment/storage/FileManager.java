package smartsassessment.storage;

import smartsassessment.model.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * File I/O manager for persistent text-based storage of:
 * - questions.txt
 * - students.txt
 * - assessments.txt
 * - results.txt
 * - content.txt
 * Uses robust pipe-delimited records with escaping.
 */
public class FileManager {

    private static final String DELIMITER = "\\|";
    private static final String SEP = "|";

    private static void ensureFileExists(File file) {
        try {
            if (file.getParentFile() != null && !file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException e) {
            System.err.println("  [Storage Warning] Could not initialize file: " + file.getPath());
        }
    }

    // ==========================================
    // QUESTIONS
    // ==========================================
    public static void saveQuestions(List<Question> questions, String filePath) {
        File file = new File(filePath);
        ensureFileExists(file);

        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8))) {
            writer.println("# QuestionId|Subject|Module|Topic|Type|Difficulty|Bloom|Marks|CorrectAns|OptA|OptB|OptC|OptD|Explanation|QuestionText");
            for (Question q : questions) {
                String line = String.join(SEP,
                        escape(q.getQuestionId()),
                        escape(q.getSubject()),
                        escape(q.getModule()),
                        escape(q.getTopic()),
                        escape(q.getQuestionType().name()),
                        escape(q.getDifficulty().name()),
                        escape(q.getBloomLevel().name()),
                        String.valueOf(q.getMarks()),
                        escape(q.getCorrectAnswer()),
                        escape(q.getOptionA()),
                        escape(q.getOptionB()),
                        escape(q.getOptionC()),
                        escape(q.getOptionD()),
                        escape(q.getExplanation()),
                        escape(q.getQuestionText())
                );
                writer.println(line);
            }
        } catch (IOException e) {
            System.err.println("  [Error] Failed to save questions: " + e.getMessage());
        }
    }

    public static List<Question> loadQuestions(String filePath) {
        List<Question> list = new ArrayList<>();
        File file = new File(filePath);
        if (!file.exists()) return list;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;

                String[] parts = line.split(DELIMITER, -1);
                if (parts.length >= 15) {
                    Question q = new Question(
                            unescape(parts[0]),
                            unescape(parts[1]),
                            unescape(parts[2]),
                            unescape(parts[3]),
                            unescape(parts[14]),
                            QuestionType.valueOf(parts[4]),
                            unescape(parts[9]),
                            unescape(parts[10]),
                            unescape(parts[11]),
                            unescape(parts[12]),
                            unescape(parts[8]),
                            unescape(parts[13]),
                            DifficultyLevel.valueOf(parts[5]),
                            BloomLevel.valueOf(parts[6]),
                            Integer.parseInt(parts[7])
                    );
                    list.add(q);
                }
            }
        } catch (Exception e) {
            System.err.println("  [Error] Failed to load questions from " + filePath + ": " + e.getMessage());
        }
        return list;
    }

    // ==========================================
    // STUDENTS
    // ==========================================
    public static void saveStudents(List<Student> students, String filePath) {
        File file = new File(filePath);
        ensureFileExists(file);

        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8))) {
            writer.println("# StudentId|Name|Email|Department|CompletedAssessments");
            for (Student s : students) {
                String completed = String.join(",", s.getCompletedAssessments());
                String line = String.join(SEP,
                        escape(s.getStudentId()),
                        escape(s.getName()),
                        escape(s.getEmail()),
                        escape(s.getDepartment()),
                        escape(completed)
                );
                writer.println(line);
            }
        } catch (IOException e) {
            System.err.println("  [Error] Failed to save students: " + e.getMessage());
        }
    }

    public static List<Student> loadStudents(String filePath) {
        List<Student> list = new ArrayList<>();
        File file = new File(filePath);
        if (!file.exists()) return list;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;

                String[] parts = line.split(DELIMITER, -1);
                if (parts.length >= 4) {
                    Student s = new Student(
                            unescape(parts[0]),
                            unescape(parts[1]),
                            unescape(parts[2]),
                            unescape(parts[3])
                    );
                    if (parts.length >= 5 && !parts[4].trim().isEmpty()) {
                        String[] assessments = unescape(parts[4]).split(",");
                        for (String aId : assessments) {
                            if (!aId.trim().isEmpty()) s.addCompletedAssessment(aId.trim());
                        }
                    }
                    list.add(s);
                }
            }
        } catch (Exception e) {
            System.err.println("  [Error] Failed to load students: " + e.getMessage());
        }
        return list;
    }

    // ==========================================
    // ASSESSMENTS
    // ==========================================
    public static void saveAssessments(List<Assessment> assessments, String filePath) {
        File file = new File(filePath);
        ensureFileExists(file);

        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8))) {
            writer.println("# AssessmentId|Title|Subject|Module|Topics|QuestionIds|TotalMarks|DurationMins|CreatedDate");
            for (Assessment a : assessments) {
                String topics = String.join(",", a.getTopics());
                String qIds = String.join(",", a.getQuestionIds());
                String line = String.join(SEP,
                        escape(a.getAssessmentId()),
                        escape(a.getTitle()),
                        escape(a.getSubject()),
                        escape(a.getModule()),
                        escape(topics),
                        escape(qIds),
                        String.valueOf(a.getTotalMarks()),
                        String.valueOf(a.getDurationMinutes()),
                        escape(a.getCreatedDate())
                );
                writer.println(line);
            }
        } catch (IOException e) {
            System.err.println("  [Error] Failed to save assessments: " + e.getMessage());
        }
    }

    public static List<Assessment> loadAssessments(String filePath) {
        List<Assessment> list = new ArrayList<>();
        File file = new File(filePath);
        if (!file.exists()) return list;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;

                String[] parts = line.split(DELIMITER, -1);
                if (parts.length >= 9) {
                    List<String> topics = new ArrayList<>();
                    if (!parts[4].trim().isEmpty()) {
                        topics.addAll(Arrays.asList(unescape(parts[4]).split(",")));
                    }
                    List<String> qIds = new ArrayList<>();
                    if (!parts[5].trim().isEmpty()) {
                        qIds.addAll(Arrays.asList(unescape(parts[5]).split(",")));
                    }

                    Assessment a = new Assessment(
                            unescape(parts[0]),
                            unescape(parts[1]),
                            unescape(parts[2]),
                            unescape(parts[3]),
                            topics,
                            qIds,
                            Integer.parseInt(parts[6]),
                            Integer.parseInt(parts[7]),
                            unescape(parts[8])
                    );
                    list.add(a);
                }
            }
        } catch (Exception e) {
            System.err.println("  [Error] Failed to load assessments: " + e.getMessage());
        }
        return list;
    }

    // ==========================================
    // RESULTS / PERFORMANCES
    // ==========================================
    public static void saveResults(List<Performance> results, String filePath) {
        File file = new File(filePath);
        ensureFileExists(file);

        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8))) {
            writer.println("# ResultId|StudentId|StudentName|AssessmentId|Score|TotalMarks|Pct|Accuracy|Date|AnswersSerialized");
            for (Performance p : results) {
                StringBuilder ansSb = new StringBuilder();
                for (int i = 0; i < p.getAnswers().size(); i++) {
                    Answer a = p.getAnswers().get(i);
                    // Encode answer: qId~studentAns~marks~maxMarks~isCorrect~feedback
                    ansSb.append(escapeSub(a.getQuestionId())).append("~")
                         .append(escapeSub(a.getStudentAnswer())).append("~")
                         .append(a.getMarksAwarded()).append("~")
                         .append(a.getMaxMarks()).append("~")
                         .append(a.isCorrect()).append("~")
                         .append(escapeSub(a.getFeedback()));
                    if (i < p.getAnswers().size() - 1) {
                        ansSb.append(";");
                    }
                }

                String line = String.join(SEP,
                        escape(p.getResultId()),
                        escape(p.getStudentId()),
                        escape(p.getStudentName()),
                        escape(p.getAssessmentId()),
                        String.valueOf(p.getScore()),
                        String.valueOf(p.getTotalMarks()),
                        String.format(Locale.US, "%.2f", p.getPercentage()),
                        String.format(Locale.US, "%.2f", p.getAccuracy()),
                        escape(p.getSubmissionDate()),
                        escape(ansSb.toString())
                );
                writer.println(line);
            }
        } catch (IOException e) {
            System.err.println("  [Error] Failed to save results: " + e.getMessage());
        }
    }

    public static List<Performance> loadResults(String filePath) {
        List<Performance> list = new ArrayList<>();
        File file = new File(filePath);
        if (!file.exists()) return list;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;

                String[] parts = line.split(DELIMITER, -1);
                if (parts.length >= 10) {
                    List<Answer> answers = new ArrayList<>();
                    String serializedAns = unescape(parts[9]);
                    if (!serializedAns.trim().isEmpty()) {
                        String[] ansTokens = serializedAns.split(";");
                        for (String tok : ansTokens) {
                            String[] f = tok.split("~", -1);
                            if (f.length >= 6) {
                                Answer a = new Answer(
                                        unescape(parts[3]),
                                        unescapeSub(f[0]),
                                        unescape(parts[1]),
                                        unescapeSub(f[1]),
                                        Integer.parseInt(f[2]),
                                        Integer.parseInt(f[3]),
                                        Boolean.parseBoolean(f[4]),
                                        unescapeSub(f[5])
                                );
                                answers.add(a);
                            }
                        }
                    }

                    Performance p = new Performance(
                            unescape(parts[0]),
                            unescape(parts[1]),
                            unescape(parts[2]),
                            unescape(parts[3]),
                            Integer.parseInt(parts[4]),
                            Integer.parseInt(parts[5]),
                            Double.parseDouble(parts[6]),
                            Double.parseDouble(parts[7]),
                            unescape(parts[8]),
                            answers
                    );
                    list.add(p);
                }
            }
        } catch (Exception e) {
            System.err.println("  [Error] Failed to load results: " + e.getMessage());
        }
        return list;
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("|", "\\p").replace("\n", "\\n").replace("\r", "");
    }

    private static String unescape(String s) {
        if (s == null) return "";
        return s.replace("\\n", "\n").replace("\\p", "|").replace("\\\\", "\\");
    }

    private static String escapeSub(String s) {
        if (s == null) return "";
        return s.replace("~", "\\t").replace(";", "\\c");
    }

    private static String unescapeSub(String s) {
        if (s == null) return "";
        return s.replace("\\c", ";").replace("\\t", "~");
    }
}
