package smartsassessment.storage;

import smartsassessment.model.*;
import smartsassessment.service.QuestionBank;
import smartsassessment.util.IdGenerator;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Coordinates persistent storage with in-memory application repositories.
 * Auto-seeds 60+ comprehensive Advanced Algorithms questions across Modules 1, 2, and 3
 * whenever data files are initialized or when manually triggered from the menu.
 */
public class DataManager {

    private final String dataDir;
    private final String questionsFile;
    private final String studentsFile;
    private final String assessmentsFile;
    private final String resultsFile;
    private final String contentFile;

    private QuestionBank questionBank;
    private List<Student> students;
    private List<Assessment> assessments;
    private List<Performance> results;

    public DataManager(String baseDataDir) {
        this.dataDir = baseDataDir;
        this.questionsFile = baseDataDir + File.separator + "questions.txt";
        this.studentsFile = baseDataDir + File.separator + "students.txt";
        this.assessmentsFile = baseDataDir + File.separator + "assessments.txt";
        this.resultsFile = baseDataDir + File.separator + "results.txt";
        this.contentFile = baseDataDir + File.separator + "content.txt";

        this.questionBank = new QuestionBank();
        this.students = new ArrayList<>();
        this.assessments = new ArrayList<>();
        this.results = new ArrayList<>();
    }

    public void init() {
        File dir = new File(dataDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        loadAllData();

        if (questionBank.getQuestionCount() == 0) {
            System.out.println("  [System] No existing questions found. Seeding 60+ Advanced Algorithms sample questions...");
            loadSampleData();
            saveAllData();
        }
    }

    public void loadAllData() {
        List<Question> loadedQuestions = FileManager.loadQuestions(questionsFile);
        this.questionBank = new QuestionBank(loadedQuestions);
        this.students = FileManager.loadStudents(studentsFile);
        this.assessments = FileManager.loadAssessments(assessmentsFile);
        this.results = FileManager.loadResults(resultsFile);

        // Update ID generator sequences to avoid duplicate IDs
        int maxQ = 100;
        for (Question q : questionBank.getQuestions()) {
            try {
                if (q.getQuestionId().startsWith("Q")) {
                    maxQ = Math.max(maxQ, Integer.parseInt(q.getQuestionId().substring(1)));
                }
            } catch (Exception ignored) {}
        }
        IdGenerator.updateQuestionCounter(maxQ);

        int maxS = 100;
        for (Student s : students) {
            try {
                if (s.getStudentId().startsWith("S")) {
                    maxS = Math.max(maxS, Integer.parseInt(s.getStudentId().substring(1)));
                }
            } catch (Exception ignored) {}
        }
        IdGenerator.updateStudentCounter(maxS);

        int maxA = 100;
        for (Assessment a : assessments) {
            try {
                if (a.getAssessmentId().startsWith("A")) {
                    maxA = Math.max(maxA, Integer.parseInt(a.getAssessmentId().substring(1)));
                }
            } catch (Exception ignored) {}
        }
        IdGenerator.updateAssessmentCounter(maxA);

        int maxR = 100;
        for (Performance p : results) {
            try {
                if (p.getResultId().startsWith("R")) {
                    maxR = Math.max(maxR, Integer.parseInt(p.getResultId().substring(1)));
                }
            } catch (Exception ignored) {}
        }
        IdGenerator.updateResultCounter(maxR);
    }

    public void saveAllData() {
        FileManager.saveQuestions(questionBank.getQuestions(), questionsFile);
        FileManager.saveStudents(students, studentsFile);
        FileManager.saveAssessments(assessments, assessmentsFile);
        FileManager.saveResults(results, resultsFile);
    }

    public QuestionBank getQuestionBank() { return questionBank; }
    public List<Student> getStudents() { return students; }
    public List<Assessment> getAssessments() { return assessments; }
    public List<Performance> getResults() { return results; }

    public Student findStudentById(String id) {
        if (id == null) return null;
        for (Student s : students) {
            if (s.getStudentId().equalsIgnoreCase(id.trim())) return s;
        }
        return null;
    }

    public Assessment findAssessmentById(String id) {
        if (id == null) return null;
        for (Assessment a : assessments) {
            if (a.getAssessmentId().equalsIgnoreCase(id.trim())) return a;
        }
        return null;
    }

    public void addStudent(Student s) {
        if (s != null && findStudentById(s.getStudentId()) == null) {
            students.add(s);
        }
    }

    public void addAssessment(Assessment a) {
        if (a != null && findAssessmentById(a.getAssessmentId()) == null) {
            assessments.add(a);
        }
    }

    public void addResult(Performance p) {
        if (p != null) {
            results.add(p);
            Student s = findStudentById(p.getStudentId());
            if (s != null) {
                s.addCompletedAssessment(p.getAssessmentId());
            }
        }
    }

    /**
     * Seeds sample data meeting requirements:
     * - Module 1 (TextHack as a System): 10 questions
     * - Module 2 (String Algorithms): 25 questions
     * - Module 3 (Advanced Dynamic Programming): 25 questions
     * - Full distribution of MCQ, Short Answer, Descriptive
     * - All difficulty levels (EASY, MEDIUM, HARD)
     * - All Bloom levels (REMEMBER, UNDERSTAND, APPLY, ANALYZE, EVALUATE, CREATE)
     */
    public void loadSampleData() {
        List<Question> sampleList = new ArrayList<>();

        // =========================================================================
        // MODULE 1: TextHack as a System (10 questions: Q101 - Q110)
        // =========================================================================
        sampleList.add(new Question("Q101", "Advanced Algorithms", "Module 1", "Pattern Search",
                "What is the theoretical lower bound for general exact pattern matching in text of length n with pattern length m?",
                QuestionType.MCQ, "Ω(n / m)", "Ω(n + m)", "Ω(m log n)", "Ω(log n)",
                "A", "Under the Boyer-Moore sublinear model over large alphabets, best-case lower bound is Ω(n / m).",
                DifficultyLevel.EASY, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q102", "Advanced Algorithms", "Module 1", "Fuzzy Matching",
                "Which heuristic distinguishes fuzzy string search from strict exact pattern search?",
                QuestionType.MCQ, "Allowance of up to k edit errors or distance tolerance",
                "Requirement of identical ASCII byte sequences",
                "Restricting search exclusively to palindromes",
                "Using only prime number string lengths",
                "A", "Fuzzy matching permits mismatching characters or edit distance <= k.",
                DifficultyLevel.EASY, BloomLevel.UNDERSTAND, 2));

        sampleList.add(new Question("Q103", "Advanced Algorithms", "Module 1", "Document Similarity",
                "Calculate the cosine similarity between two orthogonal term vectors [1, 0, 0] and [0, 1, 0].",
                QuestionType.MCQ, "0.0", "1.0", "0.5", "-1.0",
                "A", "The dot product of orthogonal vectors is 0, so cosine similarity is 0.0.",
                DifficultyLevel.MEDIUM, BloomLevel.APPLY, 2));

        sampleList.add(new Question("Q104", "Advanced Algorithms", "Module 1", "Citation-flow Analysis",
                "In academic citation-flow network analysis, which graph structure must citation trees naturally satisfy?",
                QuestionType.MCQ, "Directed Acyclic Graph (DAG) under chronological ordering",
                "Complete Bipartite Graph",
                "Eulerian Cycle",
                "Self-referential strongly connected tournament",
                "A", "Because a paper can only cite previously published literature, valid citation networks form DAGs.",
                DifficultyLevel.MEDIUM, BloomLevel.UNDERSTAND, 2));

        sampleList.add(new Question("Q105", "Advanced Algorithms", "Module 1", "Project Scheduling",
                "Which algorithmic method is used to determine early and late event times in PERT/CPM project scheduling?",
                QuestionType.MCQ, "Topological sorting on a DAG followed by longest path DP",
                "Kruskal's Minimum Spanning Tree algorithm",
                "Kosaraju's strongly connected components algorithm",
                "Floyd-Warshall all-pairs shortest paths",
                "A", "Critical Path Method (CPM) uses topological sorting and dynamic programming on a DAG.",
                DifficultyLevel.MEDIUM, BloomLevel.APPLY, 2));

        sampleList.add(new Question("Q106", "Advanced Algorithms", "Module 1", "Large-prime Primality Testing",
                "Explain why the Miller-Rabin primality test is preferred over deterministic trial division for large RSA cryptographic primes.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "Trial division requires O(sqrt(n)) time which is exponential in bit length (O(2^(b/2))), whereas Miller-Rabin runs in polynomial time O(k * b^3) with negligible error rate (1/4)^k.",
                "Polynomial time complexity vs exponential bit-length trial division.",
                DifficultyLevel.HARD, BloomLevel.ANALYZE, 5));

        sampleList.add(new Question("Q107", "Advanced Algorithms", "Module 1", "Maximum Flow",
                "State and explain the Max-Flow Min-Cut Theorem and its significance in network flow systems.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "The maximum amount of flow passing from source to sink equals the total capacity of the minimum capacity cut separating source and sink in the network.",
                "Equivalence of maximum flow value and minimum s-t cut capacity.",
                DifficultyLevel.HARD, BloomLevel.UNDERSTAND, 5));

        sampleList.add(new Question("Q108", "Advanced Algorithms", "Module 1", "Approximation Algorithms",
                "Define what makes an algorithm a 2-approximation algorithm for an NP-hard minimization problem.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "A polynomial-time algorithm that guarantees the cost of its returned solution is at most 2 times the cost of the true optimal solution for all instances.",
                "Approximation ratio bounded by alpha = 2 in polynomial time.",
                DifficultyLevel.MEDIUM, BloomLevel.REMEMBER, 5));

        sampleList.add(new Question("Q109", "Advanced Algorithms", "Module 1", "Algorithm Selection",
                "Evaluate the trade-offs between Las Vegas and Monte Carlo randomised algorithms in algorithmic design.",
                QuestionType.DESCRIPTIVE, "", "", "", "",
                "Las Vegas algorithms always guarantee complete correctness but have a randomized execution time (e.g. Randomized QuickSort), whereas Monte Carlo algorithms have deterministic runtime but carry a small, bounded probability of error (e.g. Miller-Rabin primality testing).",
                "Runtime guarantee vs correctness guarantee trade-off.",
                DifficultyLevel.HARD, BloomLevel.EVALUATE, 10));

        sampleList.add(new Question("Q110", "Advanced Algorithms", "Module 1", "Asymptotic Complexity",
                "Design a comprehensive framework for selecting the optimal string matching algorithm (Naive, KMP, Rabin-Karp, Aho-Corasick) given text size, pattern count, and alphabet characteristics.",
                QuestionType.DESCRIPTIVE, "", "", "", "",
                "For single patterns: use KMP when alphabet is small or worst-case linear bounds are needed; use Rabin-Karp when searching multiple equal-length patterns or streaming hash fingerprints. For multi-pattern dictionary search: use Aho-Corasick in O(n + sum(m)) time.",
                "Algorithm selection taxonomy based on dictionary size, streaming constraints, and alphabet size.",
                DifficultyLevel.HARD, BloomLevel.CREATE, 10));

        // =========================================================================
        // MODULE 2: String Algorithms (25 questions: Q201 - Q225)
        // =========================================================================
        sampleList.add(new Question("Q201", "Advanced Algorithms", "Module 2", "Naive Pattern Matching",
                "What is the worst-case time complexity of the Naive Pattern Matching algorithm when searching pattern of length m in text of length n?",
                QuestionType.MCQ, "O((n - m + 1) * m)", "O(n + m)", "O(n log m)", "O(m^2)",
                "A", "In the worst case (e.g. text 'AAAAAAAAAB' and pattern 'AAB'), every position performs m comparisons.",
                DifficultyLevel.EASY, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q202", "Advanced Algorithms", "Module 2", "KMP",
                "What does the failure function array pi[i] in KMP represent?",
                QuestionType.MCQ, "The length of the longest proper prefix of pattern[0..i] that is also a suffix",
                "The index of the first character mismatch in text",
                "The ASCII sum of characters in pattern[0..i]",
                "The number of distinct substrings in pattern[0..i]",
                "A", "pi[i] stores the length of the longest proper prefix that matches a suffix of pattern[0..i].",
                DifficultyLevel.EASY, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q203", "Advanced Algorithms", "Module 2", "Failure Function",
                "Compute the KMP failure function array pi for the pattern 'AABAACA'.",
                QuestionType.MCQ, "[0, 1, 0, 1, 2, 0, 1]", "[0, 1, 2, 0, 1, 2, 3]", "[0, 0, 1, 2, 3, 0, 1]", "[1, 2, 0, 1, 2, 0, 1]",
                "A", "Prefix-suffix matches: 'A'->0, 'AA'->1, 'AAB'->0, 'AABA'->1, 'AABAA'->2, 'AABAAC'->0, 'AABAACA'->1.",
                DifficultyLevel.MEDIUM, BloomLevel.APPLY, 2));

        sampleList.add(new Question("Q204", "Advanced Algorithms", "Module 2", "Z Algorithm",
                "What is the value of Z[0] typically defined as in standard Z-array implementations for string of length n?",
                QuestionType.MCQ, "n (or undefined)", "0", "1", "-1",
                "A", "Z[0] is often set to n (length of string) or left unused because the whole string trivially matches itself.",
                DifficultyLevel.EASY, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q205", "Advanced Algorithms", "Module 2", "Z Algorithm",
                "What is the value of Z[2] for the string 'aabxaab'?",
                QuestionType.MCQ, "0", "3", "1", "4",
                "A", "s[2..6] is 'bxaab'; s[0] is 'a'. First character 'b' != 'a', so longest matching prefix has length 0.",
                DifficultyLevel.MEDIUM, BloomLevel.APPLY, 2));

        sampleList.add(new Question("Q206", "Advanced Algorithms", "Module 2", "Rabin-Karp",
                "Which polynomial rolling hash formula is used in Rabin-Karp to roll window hash H from index i to i+1?",
                QuestionType.MCQ, "H_{i+1} = (base * (H_i - text[i] * base^(m-1)) + text[i+m]) mod M",
                "H_{i+1} = (H_i + text[i+m] - text[i]) mod M",
                "H_{i+1} = (H_i * base + text[i]) mod M",
                "H_{i+1} = (H_i ^ text[i+m]) mod M",
                "A", "Rolling hash subtracts highest degree term and adds incoming character.",
                DifficultyLevel.MEDIUM, BloomLevel.UNDERSTAND, 2));

        sampleList.add(new Question("Q207", "Advanced Algorithms", "Module 2", "Double Hashing",
                "Why is double hashing employed in large-scale string fingerprinting systems?",
                QuestionType.MCQ, "To dramatically reduce hash collision probability to negligible levels (e.g. 1 / (M1 * M2))",
                "To double the pattern search speed in memory",
                "To compress the pattern into half as many characters",
                "To eliminate the need for prime moduli",
                "A", "Two independent prime moduli reduce collision probability from 1/M to 1/(M1*M2).",
                DifficultyLevel.MEDIUM, BloomLevel.UNDERSTAND, 2));

        sampleList.add(new Question("Q208", "Advanced Algorithms", "Module 2", "Aho-Corasick",
                "In the Aho-Corasick automaton, failure links are constructed using which graph traversal strategy?",
                QuestionType.MCQ, "Breadth-First Search (BFS) level-by-level starting from root",
                "Depth-First Search (DFS) post-order traversal",
                "Dijkstra's shortest path algorithm",
                "Prim's minimum spanning tree traversal",
                "A", "Failure links point to nodes at strictly smaller depths, requiring BFS queue order.",
                DifficultyLevel.MEDIUM, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q209", "Advanced Algorithms", "Module 2", "Aho-Corasick",
                "Given patterns {'he', 'she', 'his', 'hers'} in Aho-Corasick, what is the target of the failure link from node 'sh'?",
                QuestionType.MCQ, "Node 'h'", "Root node", "Node 's'", "Node 'he'",
                "A", "The longest proper suffix of 'sh' present in the trie is 'h'.",
                DifficultyLevel.MEDIUM, BloomLevel.APPLY, 2));

        sampleList.add(new Question("Q210", "Advanced Algorithms", "Module 2", "Suffix Arrays",
                "What is the Suffix Array SA for the string 'banana' with 0-indexed suffixes?",
                QuestionType.MCQ, "[5, 3, 1, 0, 4, 2]", "[0, 1, 2, 3, 4, 5]", "[5, 4, 3, 2, 1, 0]", "[1, 3, 5, 0, 2, 4]",
                "A", "Suffixes sorted: 'a'(5), 'ana'(3), 'anana'(1), 'banana'(0), 'na'(4), 'nana'(2).",
                DifficultyLevel.MEDIUM, BloomLevel.APPLY, 2));

        sampleList.add(new Question("Q211", "Advanced Algorithms", "Module 2", "Kasai Algorithm",
                "What invariant allows Kasai's LCP algorithm to achieve linear O(n) execution time?",
                QuestionType.MCQ, "LCP[rank[i]] >= LCP[rank[i - 1]] - 1",
                "LCP[i] <= LCP[i - 1] + 1",
                "LCP[i] is always monotonically increasing",
                "LCP values cannot exceed log n",
                "A", "Dropping the first character of suffix i-1 reduces matching prefix length by at most 1.",
                DifficultyLevel.HARD, BloomLevel.ANALYZE, 2));

        sampleList.add(new Question("Q212", "Advanced Algorithms", "Module 2", "SA-IS Conceptual Construction",
                "In the SA-IS algorithm, how is a suffix s[i..n-1] classified as S-type?",
                QuestionType.MCQ, "If suffix i is lexicographically smaller than suffix i+1 (s[i] < s[i+1] or s[i]==s[i+1] and i+1 is S-type)",
                "If suffix i has an even starting index",
                "If suffix i starts with a vowel character",
                "If suffix i is shorter than n/2",
                "A", "S-type suffixes are lexicographically smaller than their right neighbor.",
                DifficultyLevel.HARD, BloomLevel.UNDERSTAND, 2));

        sampleList.add(new Question("Q213", "Advanced Algorithms", "Module 2", "Suffix Automata",
                "What is the maximum number of states and transitions in a Suffix Automaton for a string of length n?",
                QuestionType.MCQ, "At most 2n - 1 states and 3n - 4 transitions",
                "At most n^2 states and n^2 transitions",
                "At most n states and 2n transitions",
                "At most 2^n states and 3^n transitions",
                "A", "Suffix Automata maintain linear bounds: at most 2n-1 states and 3n-4 transitions for n >= 2.",
                DifficultyLevel.HARD, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q214", "Advanced Algorithms", "Module 2", "Suffix Trees",
                "Which algorithm constructs a compacted Suffix Tree in online linear O(n) time?",
                QuestionType.MCQ, "Ukkonen's Algorithm", "Dijkstra's Algorithm", "Tarjan's Algorithm", "Hopcroft's Algorithm",
                "A", "Ukkonen's algorithm achieves online O(n) construction using suffix links and active points.",
                DifficultyLevel.EASY, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q215", "Advanced Algorithms", "Module 2", "KMP",
                "Explain the amortized complexity argument proving that KMP pattern searching executes in strictly linear time O(n).",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "The text pointer i advances once in each outer loop step (n steps total). The pattern pointer j is incremented at most n times. Each failure link transition j = pi[j-1] decrements j by at least 1 without moving i back. Since j cannot be decremented more times than it was incremented, total while-loop iterations are bounded by n, giving O(n) total time.",
                "Potential function / amortized decrement bound on j.",
                DifficultyLevel.MEDIUM, BloomLevel.UNDERSTAND, 5));

        sampleList.add(new Question("Q216", "Advanced Algorithms", "Module 2", "Z Algorithm",
                "Describe how the Z-algorithm maintains the [L, R] interval to achieve linear time complexity without backtracking.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "It maintains [L, R] as the segment with the maximum right boundary matching a prefix of s. For index i <= R, Z[i] is initialized to min(R - i + 1, Z[i - L]). Only characters beyond R are compared explicitly, extending R monotonically to the right and ensuring each character is compared at most twice.",
                "Monotonic extension of R-boundary bounds character comparisons to 2n.",
                DifficultyLevel.MEDIUM, BloomLevel.ANALYZE, 5));

        sampleList.add(new Question("Q217", "Advanced Algorithms", "Module 2", "Rabin-Karp",
                "Calculate the polynomial hash of the string 'CAT' using base b = 10, modulus M = 101, where ASCII A=65, C=67, T=84.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "Hash = (67 * 10^2 + 65 * 10^1 + 84 * 10^0) mod 101 = (6700 + 650 + 84) mod 101 = 7434 mod 101 = 61.",
                "7434 mod 101 = 61.",
                DifficultyLevel.MEDIUM, BloomLevel.APPLY, 5));

        sampleList.add(new Question("Q218", "Advanced Algorithms", "Module 2", "Aho-Corasick",
                "Explain how output links (dictionary suffix links) in Aho-Corasick handle patterns that are proper substrings of other patterns.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "When a node u is reached, it may represent a valid pattern, but its proper suffixes might also be patterns in the dictionary. Output links follow failure paths directly to the next node representing an accepting pattern state, allowing all overlapping matches to be enumerated without traversing empty failure chains.",
                "Direct shortcuts along failure links to accepting pattern states.",
                DifficultyLevel.HARD, BloomLevel.UNDERSTAND, 5));

        sampleList.add(new Question("Q219", "Advanced Algorithms", "Module 2", "LCP",
                "Given Suffix Array SA = [5, 3, 1, 0, 4, 2] for text 'banana', calculate the Kasai LCP array.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "Suffixes sorted: 'a', 'ana', 'anana', 'banana', 'na', 'nana'. LCP between 'a' and 'ana' is 1; 'ana' and 'anana' is 3; 'anana' and 'banana' is 0; 'banana' and 'na' is 0; 'na' and 'nana' is 2. LCP array = [0, 1, 3, 0, 0, 2].",
                "LCP array for banana is [0, 1, 3, 0, 0, 2].",
                DifficultyLevel.HARD, BloomLevel.APPLY, 5));

        sampleList.add(new Question("Q220", "Advanced Algorithms", "Module 2", "Suffix Arrays",
                "Compare the space and time characteristics of Suffix Arrays versus Suffix Trees in practical search engine systems.",
                QuestionType.DESCRIPTIVE, "", "", "", "",
                "Suffix Trees require 10-20 times more memory than the text due to pointer overhead per node and edge label indices. Suffix Arrays require only 4n bytes (an integer array of indices) and together with Kasai's LCP array (4n bytes) provide identical query capabilities in smaller memory footprints with superior cache locality.",
                "Memory footprint and cache locality advantages of suffix arrays over pointer-heavy trees.",
                DifficultyLevel.HARD, BloomLevel.ANALYZE, 10));

        sampleList.add(new Question("Q221", "Advanced Algorithms", "Module 2", "Polynomial Rolling Hash",
                "Analyze the probability of a hash collision in Rabin-Karp when searching for a pattern of length m in text of length n using a prime modulus M.",
                QuestionType.DESCRIPTIVE, "", "", "", "",
                "For a pattern and any text window, if their hashes match while strings differ, collision occurs. Assuming a uniform hash distribution over prime field Z_M, the collision probability for a single comparison is <= 1/M. Across n - m + 1 sliding windows, the expected number of spurious collisions is at most (n - m + 1) / M, which is negligible when M > 10^9.",
                "Collision probability upper bounded by n/M using union bound.",
                DifficultyLevel.HARD, BloomLevel.EVALUATE, 10));

        sampleList.add(new Question("Q222", "Advanced Algorithms", "Module 2", "Failure Links",
                "Design and demonstrate the state machine transitions for an Aho-Corasick automaton recognizing keywords {'apple', 'apply', 'app'}.",
                QuestionType.DESCRIPTIVE, "", "", "", "",
                "Trie branches at 'appl': child 'e' accepts 'apple', child 'y' accepts 'apply'. Node 'app' is an accepting state for 'app'. Failure link of 'appl' points to root. Output link of 'apple' points to 'app'. If 'apple' matches, output list reports both 'apple' and 'app'.",
                "Trie branching, failure link fallback, and dictionary output chain.",
                DifficultyLevel.HARD, BloomLevel.CREATE, 10));

        sampleList.add(new Question("Q223", "Advanced Algorithms", "Module 2", "Trie",
                "What is the worst-case space complexity of inserting k patterns of total length L into a standard Trie over alphabet of size sigma?",
                QuestionType.MCQ, "O(L * sigma)", "O(L + sigma)", "O(k * sigma)", "O(L^2)",
                "A", "Each trie node can store up to sigma child pointers, yielding at most L * sigma pointers.",
                DifficultyLevel.EASY, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q224", "Advanced Algorithms", "Module 2", "String Algorithms",
                "Which problem can be solved in O(n) time using a Suffix Array combined with its LCP array?",
                QuestionType.MCQ, "Finding the Longest Repeated Substring in a text",
                "Sorting an array of arbitrary numbers",
                "Finding the shortest path in a weighted graph",
                "Testing graph 3-colorability",
                "A", "The maximum value in the LCP array corresponds to the length of the longest repeated substring.",
                DifficultyLevel.MEDIUM, BloomLevel.UNDERSTAND, 2));

        sampleList.add(new Question("Q225", "Advanced Algorithms", "Module 2", "Failure Function",
                "Can the KMP failure function pi[i] ever be equal to i + 1 for proper prefixes?",
                QuestionType.MCQ, "No, because a proper prefix cannot equal the entire string pattern[0..i]",
                "Yes, if all characters in the pattern are identical",
                "Yes, for even index positions only",
                "Yes, if the string is a palindrome",
                "A", "By definition, a proper prefix must be strictly shorter than the string itself, so pi[i] <= i.",
                DifficultyLevel.EASY, BloomLevel.UNDERSTAND, 2));

        // =========================================================================
        // MODULE 3: Advanced Dynamic Programming (25 questions: Q301 - Q325)
        // =========================================================================
        sampleList.add(new Question("Q301", "Advanced Algorithms", "Module 3", "Dynamic Programming",
                "What are the two core properties that a problem must possess to be efficiently solved using Dynamic Programming?",
                QuestionType.MCQ, "Optimal Substructure and Overlapping Subproblems",
                "Greedy Choice Property and Independence",
                "Polynomial Reducibility and Completeness",
                "Markovian Memorylessness and Bipartiteness",
                "A", "Optimal substructure allows building from smaller optimal subproblems; overlapping subproblems allows memoization.",
                DifficultyLevel.EASY, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q302", "Advanced Algorithms", "Module 3", "Levenshtein Distance",
                "What is the Levenshtein edit distance between 'kitten' and 'sitting'?",
                QuestionType.MCQ, "3", "2", "4", "1",
                "A", "Operations: replace 'k' with 's', replace 'e' with 'i', insert 'g' at end = 3 operations.",
                DifficultyLevel.EASY, BloomLevel.APPLY, 2));

        sampleList.add(new Question("Q303", "Advanced Algorithms", "Module 3", "Damerau-Levenshtein",
                "What is the Damerau-Levenshtein distance between 'CA' and 'AC'?",
                QuestionType.MCQ, "1", "2", "0", "3",
                "A", "Damerau-Levenshtein supports adjacent transposition with cost 1 ('CA' -> 'AC').",
                DifficultyLevel.EASY, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q304", "Advanced Algorithms", "Module 3", "Weighted Edit Distance",
                "Calculate the weighted edit distance from 'cat' to 'hat' given Insert=1, Delete=1, Substitute=3.",
                QuestionType.MCQ, "2 (Delete 'c' + Insert 'h')", "3 (Substitute 'c' with 'h')", "1", "4",
                "A", "Substituting costs 3, but deleting 'c' (cost 1) and inserting 'h' (cost 1) costs 2, which is cheaper.",
                DifficultyLevel.MEDIUM, BloomLevel.APPLY, 2));

        sampleList.add(new Question("Q305", "Advanced Algorithms", "Module 3", "Needleman-Wunsch",
                "Which biological sequence alignment model is computed by the Needleman-Wunsch dynamic programming algorithm?",
                QuestionType.MCQ, "Global Alignment of two entire sequences",
                "Local Alignment of optimal high-scoring regions",
                "Multiple Sequence Alignment over all species",
                "Secondary structure folding prediction",
                "A", "Needleman-Wunsch computes global sequence alignment from end to end.",
                DifficultyLevel.EASY, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q306", "Advanced Algorithms", "Module 3", "Smith-Waterman",
                "How does the Smith-Waterman local alignment recurrence differ from Needleman-Wunsch global alignment?",
                QuestionType.MCQ, "Smith-Waterman resets cell scores to 0 whenever the recurrence values become negative",
                "Smith-Waterman does not allow insertions or deletions",
                "Smith-Waterman runs in linear O(n) time using greedy choice",
                "Smith-Waterman only aligns protein sequences rather than DNA",
                "A", "Resetting negative scores to 0 (dp[i][j] = max(0, ...)) isolates local high-scoring regions.",
                DifficultyLevel.MEDIUM, BloomLevel.UNDERSTAND, 2));

        sampleList.add(new Question("Q307", "Advanced Algorithms", "Module 3", "Gap Penalties",
                "Why are affine gap penalties (cost = open + k * extend) biologically superior to constant linear gap penalties?",
                QuestionType.MCQ, "A single insertion or deletion of k contiguous bases is biologically more likely than k independent single mutations",
                "They simplify the dynamic programming table from 2D to 1D",
                "They prevent any gaps from occurring in alignment",
                "They make the algorithm execute in sublinear time",
                "A", "Contiguous insertions/deletions usually occur as a single biological event.",
                DifficultyLevel.MEDIUM, BloomLevel.UNDERSTAND, 2));

        sampleList.add(new Question("Q308", "Advanced Algorithms", "Module 3", "Interval DP",
                "What is the typical state formulation and iteration order for Interval Dynamic Programming?",
                QuestionType.MCQ, "DP[i][j] representing subproblem on interval [i..j], iterated by increasing interval length len = 2..n",
                "DP[i] representing prefix [0..i], iterated from 0 to n",
                "DP[mask] representing subsets, iterated by bit count",
                "DP[u] representing tree depth, iterated top-down",
                "A", "Interval DP solves subproblems on contiguous ranges [i..j] ordered by interval length.",
                DifficultyLevel.MEDIUM, BloomLevel.UNDERSTAND, 2));

        sampleList.add(new Question("Q309", "Advanced Algorithms", "Module 3", "Matrix-Chain Multiplication",
                "Given matrices A1(10x100), A2(100x5), A3(5x50), calculate the minimum scalar multiplications required.",
                QuestionType.MCQ, "7,500 multiplications: (A1 x A2) x A3", "55,000 multiplications: A1 x (A2 x A3)", "25,000 multiplications", "10,000 multiplications",
                "A", "(A1 x A2) costs 10*100*5 = 5,000; resulting (10x5) x A3(5x50) costs 10*5*50 = 2,500. Total = 7,500.",
                DifficultyLevel.MEDIUM, BloomLevel.APPLY, 2));

        sampleList.add(new Question("Q310", "Advanced Algorithms", "Module 3", "Optimal BST",
                "What is the time complexity of constructing an Optimal Binary Search Tree for n keys using dynamic programming?",
                QuestionType.MCQ, "O(n^3) standard, reducible to O(n^2) via Knuth's optimization",
                "O(2^n) standard, reducible to O(n log n)",
                "O(n log n) using Huffman coding",
                "O(n^4)",
                "A", "Interval DP evaluates n intervals with n splits = O(n^3); Knuth's quadrangle inequality achieves O(n^2).",
                DifficultyLevel.HARD, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q311", "Advanced Algorithms", "Module 3", "Bitmask DP",
                "In Bitmask DP, how is the submask iteration idiom 'sub = (sub - 1) & mask' verified to visit all submasks in O(3^n) total time?",
                QuestionType.MCQ, "By the Binomial Theorem: sum_{k=0}^n (n choose k) * 2^k = (1 + 2)^n = 3^n",
                "Because each number is checked in O(1) time up to 2^n",
                "Because bitwise AND always divides the state space by 3",
                "Because all even numbers are skipped",
                "A", "Iterating submasks for all masks sums (n choose k)*2^k = (2+1)^n = 3^n.",
                DifficultyLevel.HARD, BloomLevel.ANALYZE, 2));

        sampleList.add(new Question("Q312", "Advanced Algorithms", "Module 3", "TSP Bitmask DP",
                "What is the state definition in the Held-Karp algorithm for solving the Travelling Salesman Problem?",
                QuestionType.MCQ, "DP[mask][u]: minimum cost to visit all cities in the bitmask, ending at city u",
                "DP[u][v]: shortest path between city u and city v",
                "DP[mask]: minimum spanning tree weight of cities in mask",
                "DP[i]: minimum cost tour of length i",
                "A", "State DP[mask][u] tracks the subset of visited vertices and current location u.",
                DifficultyLevel.MEDIUM, BloomLevel.UNDERSTAND, 2));

        sampleList.add(new Question("Q313", "Advanced Algorithms", "Module 3", "Hamiltonian Path",
                "What is the asymptotic complexity of determining whether an n-vertex graph contains a Hamiltonian Path using bitmask DP?",
                QuestionType.MCQ, "O(2^n * n^2)", "O(n!)", "O(n^3)", "O(2^n * n)",
                "A", "There are 2^n * n states, and each state evaluates transitions to at most n neighbors = O(2^n * n^2).",
                DifficultyLevel.MEDIUM, BloomLevel.REMEMBER, 2));

        sampleList.add(new Question("Q314", "Advanced Algorithms", "Module 3", "Tree DP",
                "In Tree DP, how is the diameter of an unweighted tree calculated in O(n) time during a single post-order DFS traversal?",
                QuestionType.MCQ, "For each node, compute top two maximum child depths d1, d2; track max(d1 + d2) across all nodes",
                "By running Dijkstra's algorithm from all n nodes",
                "By sorting the tree leaves in ascending order",
                "By computing the determinant of the tree adjacency matrix",
                "A", "The diameter passing through any node u as its apex is the sum of the two deepest branches.",
                DifficultyLevel.MEDIUM, BloomLevel.UNDERSTAND, 2));

        sampleList.add(new Question("Q315", "Advanced Algorithms", "Module 3", "Rerooting",
                "Describe the mathematical relation used in Tree DP Rerooting to update the sum of distances when moving the root from parent u to child v.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "distSum[v] = distSum[u] - subtreeSize[v] + (N - subtreeSize[v]). Nodes in v's subtree move 1 step closer, while all N - subtreeSize[v] nodes outside move 1 step further.",
                "Rerooting transition: distSum[v] = distSum[u] - size[v] + (N - size[v]).",
                DifficultyLevel.HARD, BloomLevel.APPLY, 5));

        sampleList.add(new Question("Q316", "Advanced Algorithms", "Module 3", "SOS DP",
                "Explain the bitwise prefix recurrence relation used in Sum Over Subsets (SOS) DP.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "dp[mask][i] = dp[mask][i - 1] if bit i is 0; otherwise dp[mask][i - 1] + dp[mask ^ (1 << i)][i - 1]. This builds submask sums dimension-by-dimension across all n bits in O(n * 2^n) time.",
                "SOS DP bitwise prefix relaxation: dp[mask][i] sums without and with bit i.",
                DifficultyLevel.HARD, BloomLevel.UNDERSTAND, 5));

        sampleList.add(new Question("Q317", "Advanced Algorithms", "Module 3", "Inclusion-Exclusion",
                "How does the Principle of Inclusion-Exclusion relate to bitmask dynamic programming over finite sets?",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "The union of sets |U A_i| = sum_{emptyset != S subseteq [n]} (-1)^{|S| - 1} |cap_{i in S} A_i|. In bitmask DP, each subset S is represented as a bitmask, and parity is given by the bit count popcount(mask) mod 2.",
                "Parity of subset bit count (-1)^(|S|-1) weights intersection terms.",
                DifficultyLevel.HARD, BloomLevel.ANALYZE, 5));

        sampleList.add(new Question("Q318", "Advanced Algorithms", "Module 3", "Wagner-Fischer",
                "Given strings s1 = 'INTENTION' and s2 = 'EXECUTION', write the Wagner-Fischer DP recurrence and state base conditions.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "Base cases: dp[i][0] = i, dp[0][j] = j. Recurrence: if s1[i-1] == s2[j-1], dp[i][j] = dp[i-1][j-1]; else 1 + min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]).",
                "Standard Wagner-Fischer 2D recurrence and base boundaries.",
                DifficultyLevel.MEDIUM, BloomLevel.APPLY, 5));

        sampleList.add(new Question("Q319", "Advanced Algorithms", "Module 3", "Set-Cover Variants",
                "Formulate the Exact Cover problem as a bitmask DP recurrence over an universe of n elements.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "Let dp[mask] be true if elements in mask can be partitioned by disjoint available subsets. dp[mask | subset] = true if dp[mask] == true and (mask & subset) == 0.",
                "Bitmask transition verifying disjoint subset union.",
                DifficultyLevel.HARD, BloomLevel.APPLY, 5));

        sampleList.add(new Question("Q320", "Advanced Algorithms", "Module 3", "Optimal Substructure",
                "Explain why Longest Simple Path in a general graph lacks optimal substructure while Shortest Path possesses it.",
                QuestionType.SHORT_ANSWER, "", "", "", "",
                "Subpaths of a longest simple path may share vertices with other subpaths, violating the simplicity constraint (cycles). Independent subproblems are not disjoint, whereas subpaths of shortest paths are unconditionally optimal without vertex conflict.",
                "Subproblem independence violation caused by simple path vertex non-repetition.",
                DifficultyLevel.HARD, BloomLevel.EVALUATE, 5));

        sampleList.add(new Question("Q321", "Advanced Algorithms", "Module 3", "Matrix-Chain DP",
                "Critically assess why a greedy strategy of multiplying matrices with smallest adjacent dimensions first fails to achieve global optimality.",
                QuestionType.DESCRIPTIVE, "", "", "", "",
                "A local greedy choice generates an intermediate matrix that may severely increase dimensions for all subsequent multiplications in the chain. Dynamic programming evaluates all O(n^2) interval partitions globally, accounting for downstream multiplication costs that greedy local choices ignore.",
                "Local greedy greedily creates suboptimal intermediate matrix dimensions.",
                DifficultyLevel.HARD, BloomLevel.EVALUATE, 10));

        sampleList.add(new Question("Q322", "Advanced Algorithms", "Module 3", "TSP Bitmask DP",
                "Design the complete state transition table and path reconstruction algorithm for TSP with n = 4 cities using bitmask DP.",
                QuestionType.DESCRIPTIVE, "", "", "", "",
                "State dp[mask][u] for 2^4 = 16 masks and 4 cities. Base dp[1][0] = 0. Iterate mask from 1 to 15. For each city u in mask, and unvisited city v not in mask, dp[mask | (1<<v)][v] = min(..., dp[mask][u] + dist[u][v]), saving parent pointers. Final cost = min_{u>0} (dp[15][u] + dist[u][0]). Backtrack parent pointers from 15 to reconstruct tour.",
                "Held-Karp step-by-step state construction and parent pointer traceback.",
                DifficultyLevel.HARD, BloomLevel.CREATE, 10));

        sampleList.add(new Question("Q323", "Advanced Algorithms", "Module 3", "Tree DP",
                "Design a Tree DP algorithm to find the Maximum Weight Independent Set (MWIS) on a general tree with node weights.",
                QuestionType.DESCRIPTIVE, "", "", "", "",
                "For each node u, maintain dp[u][0] (u is not included in independent set) and dp[u][1] (u is included). Recurrences: dp[u][1] = weight[u] + sum_{v in children} dp[v][0]. dp[u][0] = sum_{v in children} max(dp[v][0], dp[v][1]). Traverse tree in post-order DFS; maximum weight is max(dp[root][0], dp[root][1]).",
                "Two-state dynamic programming per node on tree hierarchy.",
                DifficultyLevel.HARD, BloomLevel.CREATE, 10));

        sampleList.add(new Question("Q324", "Advanced Algorithms", "Module 3", "SOS DP",
                "Analyze the asymptotic improvement of Sum-Over-Subsets DP (O(N * 2^N)) versus naive submask enumeration (O(3^N)) for N = 20.",
                QuestionType.DESCRIPTIVE, "", "", "", "",
                "For N = 20: 3^20 = 3,486,784,401 operations (approx 3.5 billion), which takes several seconds or minutes. SOS DP requires N * 2^N = 20 * 1,048,576 = 20,971,520 operations (approx 21 million), executing in a few milliseconds on standard CPUs, achieving a 166x performance speedup.",
                "Concrete numerical speedup comparison for N=20 demonstrating practical feasibility.",
                DifficultyLevel.HARD, BloomLevel.ANALYZE, 10));

        sampleList.add(new Question("Q325", "Advanced Algorithms", "Module 3", "Damerau-Levenshtein",
                "Differentiate between Restricted Damerau-Levenshtein (Optimal String Alignment) and True Damerau-Levenshtein distance.",
                QuestionType.DESCRIPTIVE, "", "", "", "",
                "Optimal String Alignment (OSA) does not allow multiple edit operations on the same substring (e.g. 'CA' -> 'AC' transposition cannot be combined with an insertion inside the transposed pair). True Damerau-Levenshtein allows arbitrary operations on the same characters and requires a modified DP tracking character position lookups, satisfying metric triangle inequality.",
                "Triangle inequality and multiple operation allowance distinction between OSA and True Damerau.",
                DifficultyLevel.HARD, BloomLevel.EVALUATE, 10));

        // Load into question bank
        for (Question q : sampleList) {
            this.questionBank.addQuestion(q);
        }

        // =========================================================================
        // SAMPLE STUDENTS
        // =========================================================================
        this.students.clear();
        this.students.add(new Student("S101", "A Sai Charan Reddy", "saicharan@university.edu", "Computer Science"));
        this.students.add(new Student("S102", "Priya Sharma", "priya.sharma@university.edu", "Data Science"));
        this.students.add(new Student("S103", "Rahul Verma", "rahul.verma@university.edu", "Information Technology"));
        this.students.add(new Student("S104", "Ananya Iyer", "ananya.iyer@university.edu", "Computer Science"));

        // =========================================================================
        // SAMPLE PRE-GENERATED ASSESSMENTS
        // =========================================================================
        this.assessments.clear();
        Assessment a1 = new Assessment(
                "A101",
                "Advanced String Algorithms Midterm",
                "Advanced Algorithms",
                "Module 2",
                Arrays.asList("KMP", "Z Algorithm", "Rabin-Karp", "Suffix Arrays"),
                Arrays.asList("Q201", "Q202", "Q203", "Q204", "Q206", "Q210", "Q215"),
                17,
                45,
                LocalDate.now().minusDays(3).toString()
        );
        this.assessments.add(a1);

        Assessment a2 = new Assessment(
                "A102",
                "Dynamic Programming Comprehensive Exam",
                "Advanced Algorithms",
                "Module 3",
                Arrays.asList("Levenshtein Distance", "Matrix-Chain Multiplication", "TSP Bitmask DP", "Tree DP"),
                Arrays.asList("Q301", "Q302", "Q303", "Q309", "Q312", "Q314", "Q318"),
                17,
                60,
                LocalDate.now().minusDays(1).toString()
        );
        this.assessments.add(a2);

        // =========================================================================
        // SAMPLE RESULTS
        // =========================================================================
        this.results.clear();
        List<Answer> sampleAnswers = new ArrayList<>();
        sampleAnswers.add(new Answer("A101", "Q201", "S101", "A", 2, 2, true, "Correct choice selected."));
        sampleAnswers.add(new Answer("A101", "Q202", "S101", "A", 2, 2, true, "Correct choice selected."));
        sampleAnswers.add(new Answer("A101", "Q203", "S101", "A", 2, 2, true, "Correct choice selected."));
        sampleAnswers.add(new Answer("A101", "Q204", "S101", "A", 2, 2, true, "Correct choice selected."));
        sampleAnswers.add(new Answer("A101", "Q206", "S101", "A", 2, 2, true, "Correct choice selected."));
        sampleAnswers.add(new Answer("A101", "Q210", "S101", "A", 2, 2, true, "Correct choice selected."));
        sampleAnswers.add(new Answer("A101", "Q215", "S101",
                "Text pointer i advances by 1 in each step. Pattern pointer j cannot decrement more than it incremented.",
                4, 5, true, "Score: 4/5 based on keyword matching and term similarity."));

        Performance p1 = new Performance(
                "R101", "S101", "A Sai Charan Reddy", "A101",
                16, 17, 94.1, 100.0,
                LocalDate.now().minusDays(2).toString(),
                sampleAnswers
        );
        p1.getModuleBreakdown().put("Module 2", 94.1);
        p1.getTopicBreakdown().put("KMP", 85.7);
        p1.getTopicBreakdown().put("Z Algorithm", 100.0);
        p1.getTopicBreakdown().put("Rabin-Karp", 100.0);
        p1.getTopicBreakdown().put("Suffix Arrays", 100.0);
        p1.getDifficultyBreakdown().put("EASY", 100.0);
        p1.getDifficultyBreakdown().put("MEDIUM", 90.9);
        p1.getBloomBreakdown().put("REMEMBER", 100.0);
        p1.getBloomBreakdown().put("APPLY", 100.0);
        p1.getBloomBreakdown().put("UNDERSTAND", 80.0);

        this.results.add(p1);
        this.students.get(0).addCompletedAssessment("A101");
    }
}
