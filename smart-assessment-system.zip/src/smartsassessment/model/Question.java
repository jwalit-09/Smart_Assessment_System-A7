package smartsassessment.model;

import java.io.Serializable;

/**
 * Encapsulates an assessment question with full pedagogical metadata.
 */
public class Question implements Serializable {
    private static final long serialVersionUID = 1L;

    private String questionId;
    private String subject;
    private String module;
    private String topic;
    private String questionText;
    private QuestionType questionType;
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private String correctAnswer;
    private String explanation;
    private DifficultyLevel difficulty;
    private BloomLevel bloomLevel;
    private int marks;

    public Question() {
        this.questionType = QuestionType.MCQ;
        this.difficulty = DifficultyLevel.MEDIUM;
        this.bloomLevel = BloomLevel.UNDERSTAND;
        this.marks = 2;
    }

    public Question(String questionId, String subject, String module, String topic,
                    String questionText, QuestionType questionType,
                    String optionA, String optionB, String optionC, String optionD,
                    String correctAnswer, String explanation,
                    DifficultyLevel difficulty, BloomLevel bloomLevel, int marks) {
        this.questionId = questionId;
        this.subject = subject;
        this.module = module;
        this.topic = topic;
        this.questionText = questionText;
        this.questionType = questionType;
        this.optionA = optionA != null ? optionA : "";
        this.optionB = optionB != null ? optionB : "";
        this.optionC = optionC != null ? optionC : "";
        this.optionD = optionD != null ? optionD : "";
        this.correctAnswer = correctAnswer;
        this.explanation = explanation != null ? explanation : "";
        this.difficulty = difficulty != null ? difficulty : DifficultyLevel.MEDIUM;
        this.bloomLevel = bloomLevel != null ? bloomLevel : BloomLevel.UNDERSTAND;
        this.marks = marks;
    }

    // Getters and Setters
    public String getQuestionId() { return questionId; }
    public void setQuestionId(String questionId) { this.questionId = questionId; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    public String getTopic() { return topic; }
    public void setTopic(String topic) { this.topic = topic; }

    public String getQuestionText() { return questionText; }
    public void setQuestionText(String questionText) { this.questionText = questionText; }

    public QuestionType getQuestionType() { return questionType; }
    public void setQuestionType(QuestionType questionType) { this.questionType = questionType; }

    public String getOptionA() { return optionA; }
    public void setOptionA(String optionA) { this.optionA = optionA; }

    public String getOptionB() { return optionB; }
    public void setOptionB(String optionB) { this.optionB = optionB; }

    public String getOptionC() { return optionC; }
    public void setOptionC(String optionC) { this.optionC = optionC; }

    public String getOptionD() { return optionD; }
    public void setOptionD(String optionD) { this.optionD = optionD; }

    public String getCorrectAnswer() { return correctAnswer; }
    public void setCorrectAnswer(String correctAnswer) { this.correctAnswer = correctAnswer; }

    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }

    public DifficultyLevel getDifficulty() { return difficulty; }
    public void setDifficulty(DifficultyLevel difficulty) { this.difficulty = difficulty; }

    public BloomLevel getBloomLevel() { return bloomLevel; }
    public void setBloomLevel(BloomLevel bloomLevel) { this.bloomLevel = bloomLevel; }

    public int getMarks() { return marks; }
    public void setMarks(int marks) { this.marks = marks; }

    public String getFormattedDisplay() {
        StringBuilder sb = new StringBuilder();
        sb.append("========================================\n");
        sb.append("Question ID: ").append(questionId).append("\n");
        sb.append("Subject:     ").append(subject).append("\n");
        sb.append("Module:      ").append(module).append("\n");
        sb.append("Topic:       ").append(topic).append("\n");
        sb.append("Type:        ").append(questionType).append("\n");
        sb.append("Difficulty:  ").append(difficulty).append("\n");
        sb.append("Bloom Level: ").append(bloomLevel).append("\n");
        sb.append("Marks:       ").append(marks).append("\n\n");
        sb.append("Question:\n").append(questionText).append("\n");

        if (questionType == QuestionType.MCQ) {
            sb.append("\nOptions:\n");
            sb.append("  A. ").append(optionA).append("\n");
            sb.append("  B. ").append(optionB).append("\n");
            sb.append("  C. ").append(optionC).append("\n");
            sb.append("  D. ").append(optionD).append("\n");
        }

        sb.append("\nCorrect Answer: ").append(correctAnswer).append("\n");
        if (explanation != null && !explanation.isEmpty()) {
            sb.append("Explanation:    ").append(explanation).append("\n");
        }
        sb.append("========================================");
        return sb.toString();
    }

    @Override
    public String toString() {
        return "[" + questionId + "] (" + module + " - " + topic + " | " + difficulty + " | " + bloomLevel + " | " + marks + " marks) " +
                (questionText.length() > 60 ? questionText.substring(0, 57) + "..." : questionText);
    }
}
