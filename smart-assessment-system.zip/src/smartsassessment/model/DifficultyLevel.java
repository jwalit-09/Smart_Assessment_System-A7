package smartsassessment.model;

/**
 * Question difficulty tiers.
 */
public enum DifficultyLevel {
    EASY,
    MEDIUM,
    HARD
}
