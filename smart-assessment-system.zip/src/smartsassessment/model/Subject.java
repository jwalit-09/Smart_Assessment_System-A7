package smartsassessment.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Encapsulates an academic subject containing course modules.
 */
public class Subject implements Serializable {
    private static final long serialVersionUID = 1L;

    private String subjectId;
    private String subjectCode;
    private String name;
    private String description;
    private List<Module> modules;

    public Subject() {
        this.modules = new ArrayList<>();
    }

    public Subject(String subjectId, String subjectCode, String name, String description, List<Module> modules) {
        this.subjectId = subjectId;
        this.subjectCode = subjectCode;
        this.name = name;
        this.description = description;
        this.modules = modules != null ? modules : new ArrayList<>();
    }

    public String getSubjectId() { return subjectId; }
    public void setSubjectId(String subjectId) { this.subjectId = subjectId; }

    public String getSubjectCode() { return subjectCode; }
    public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public List<Module> getModules() { return modules; }
    public void setModules(List<Module> modules) { this.modules = modules; }

    public Module getModuleByNumber(int number) {
        for (Module m : modules) {
            if (m.getModuleNumber() == number) {
                return m;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "[" + subjectCode + "] " + name + " (" + modules.size() + " modules)";
    }
}
