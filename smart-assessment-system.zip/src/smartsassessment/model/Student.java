package smartsassessment.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Encapsulates student registration and academic history.
 */
public class Student implements Serializable {
    private static final long serialVersionUID = 1L;

    private String studentId;
    private String name;
    private String email;
    private String department;
    private List<String> completedAssessments;

    public Student() {
        this.completedAssessments = new ArrayList<>();
    }

    public Student(String studentId, String name, String email, String department) {
        this.studentId = studentId;
        this.name = name;
        this.email = email;
        this.department = department;
        this.completedAssessments = new ArrayList<>();
    }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public List<String> getCompletedAssessments() { return completedAssessments; }
    public void setCompletedAssessments(List<String> completedAssessments) { this.completedAssessments = completedAssessments; }

    public void addCompletedAssessment(String assessmentId) {
        if (!completedAssessments.contains(assessmentId)) {
            completedAssessments.add(assessmentId);
        }
    }

    @Override
    public String toString() {
        return "[" + studentId + "] " + name + " (" + department + ") - " + email;
    }
}
