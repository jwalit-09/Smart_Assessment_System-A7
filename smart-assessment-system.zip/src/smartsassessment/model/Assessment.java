package smartsassessment.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Encapsulates a generated assessment paper containing a structured set of questions.
 */
public class Assessment implements Serializable {
    private static final long serialVersionUID = 1L;

    private String assessmentId;
    private String title;
    private String subject;
    private String module;
    private List<String> topics;
    private List<String> questionIds;
    private int totalMarks;
    private int durationMinutes;
    private String createdDate;

    public Assessment() {
        this.topics = new ArrayList<>();
        this.questionIds = new ArrayList<>();
    }

    public Assessment(String assessmentId, String title, String subject, String module,
                      List<String> topics, List<String> questionIds, int totalMarks,
                      int durationMinutes, String createdDate) {
        this.assessmentId = assessmentId;
        this.title = title;
        this.subject = subject;
        this.module = module;
        this.topics = topics != null ? topics : new ArrayList<>();
        this.questionIds = questionIds != null ? questionIds : new ArrayList<>();
        this.totalMarks = totalMarks;
        this.durationMinutes = durationMinutes;
        this.createdDate = createdDate;
    }

    public String getAssessmentId() { return assessmentId; }
    public void setAssessmentId(String assessmentId) { this.assessmentId = assessmentId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    public List<String> getTopics() { return topics; }
    public void setTopics(List<String> topics) { this.topics = topics; }

    public List<String> getQuestionIds() { return questionIds; }
    public void setQuestionIds(List<String> questionIds) { this.questionIds = questionIds; }

    public int getTotalMarks() { return totalMarks; }
    public void setTotalMarks(int totalMarks) { this.totalMarks = totalMarks; }

    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }

    public String getCreatedDate() { return createdDate; }
    public void setCreatedDate(String createdDate) { this.createdDate = createdDate; }

    @Override
    public String toString() {
        return "[" + assessmentId + "] " + title + " | " + module + " (" + questionIds.size() + " Qs, " + totalMarks + " Marks, " + durationMinutes + " mins)";
    }
}
