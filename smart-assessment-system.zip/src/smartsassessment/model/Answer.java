package smartsassessment.model;

import java.io.Serializable;

/**
 * Encapsulates a student's answer to a specific question in an assessment along with awarded marks and feedback.
 */
public class Answer implements Serializable {
    private static final long serialVersionUID = 1L;

    private String assessmentId;
    private String questionId;
    private String studentId;
    private String studentAnswer;
    private int marksAwarded;
    private int maxMarks;
    private boolean correct;
    private String feedback;

    public Answer() {
    }

    public Answer(String assessmentId, String questionId, String studentId, String studentAnswer,
                  int marksAwarded, int maxMarks, boolean correct, String feedback) {
        this.assessmentId = assessmentId;
        this.questionId = questionId;
        this.studentId = studentId;
        this.studentAnswer = studentAnswer != null ? studentAnswer : "";
        this.marksAwarded = marksAwarded;
        this.maxMarks = maxMarks;
        this.correct = correct;
        this.feedback = feedback != null ? feedback : "";
    }

    public String getAssessmentId() { return assessmentId; }
    public void setAssessmentId(String assessmentId) { this.assessmentId = assessmentId; }

    public String getQuestionId() { return questionId; }
    public void setQuestionId(String questionId) { this.questionId = questionId; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getStudentAnswer() { return studentAnswer; }
    public void setStudentAnswer(String studentAnswer) { this.studentAnswer = studentAnswer; }

    public int getMarksAwarded() { return marksAwarded; }
    public void setMarksAwarded(int marksAwarded) { this.marksAwarded = marksAwarded; }

    public int getMaxMarks() { return maxMarks; }
    public void setMaxMarks(int maxMarks) { this.maxMarks = maxMarks; }

    public boolean isCorrect() { return correct; }
    public void setCorrect(boolean correct) { this.correct = correct; }

    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }

    @Override
    public String toString() {
        return "Q: " + questionId + " | Ans: " + studentAnswer + " | Score: " + marksAwarded + "/" + maxMarks + " (" + (correct ? "Correct" : "Incorrect") + ")";
    }
}
