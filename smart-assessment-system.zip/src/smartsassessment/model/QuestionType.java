package smartsassessment.model;

/**
 * Supported assessment question types.
 */
public enum QuestionType {
    MCQ,
    SHORT_ANSWER,
    DESCRIPTIVE
}
