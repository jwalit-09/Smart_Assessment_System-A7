package smartsassessment.model;

/**
 * Bloom's Taxonomy cognitive levels.
 */
public enum BloomLevel {
    REMEMBER,
    UNDERSTAND,
    APPLY,
    ANALYZE,
    EVALUATE,
    CREATE
}
