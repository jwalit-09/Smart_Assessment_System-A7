package smartsassessment.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Encapsulates an academic syllabus module with its topics.
 */
public class Module implements Serializable {
    private static final long serialVersionUID = 1L;

    private int moduleNumber;
    private String title;
    private String description;
    private List<String> topics;

    public Module() {
        this.topics = new ArrayList<>();
    }

    public Module(int moduleNumber, String title, String description, List<String> topics) {
        this.moduleNumber = moduleNumber;
        this.title = title;
        this.description = description;
        this.topics = topics != null ? topics : new ArrayList<>();
    }

    public int getModuleNumber() { return moduleNumber; }
    public void setModuleNumber(int moduleNumber) { this.moduleNumber = moduleNumber; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public List<String> getTopics() { return topics; }
    public void setTopics(List<String> topics) { this.topics = topics; }

    @Override
    public String toString() {
        return "Module " + moduleNumber + ": " + title + " (" + topics.size() + " topics)";
    }
}
