package smartsassessment.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Encapsulates performance analytics for an assessment attempt by a student.
 */
public class Performance implements Serializable {
    private static final long serialVersionUID = 1L;

    private String resultId;
    private String studentId;
    private String studentName;
    private String assessmentId;
    private int score;
    private int totalMarks;
    private double percentage;
    private double accuracy;
    private String submissionDate;
    private List<Answer> answers;

    private Map<String, Double> topicBreakdown;
    private Map<String, Double> moduleBreakdown;
    private Map<String, Double> difficultyBreakdown;
    private Map<String, Double> bloomBreakdown;

    public Performance() {
        this.answers = new ArrayList<>();
        this.topicBreakdown = new HashMap<>();
        this.moduleBreakdown = new HashMap<>();
        this.difficultyBreakdown = new HashMap<>();
        this.bloomBreakdown = new HashMap<>();
    }

    public Performance(String resultId, String studentId, String studentName, String assessmentId,
                       int score, int totalMarks, double percentage, double accuracy,
                       String submissionDate, List<Answer> answers) {
        this.resultId = resultId;
        this.studentId = studentId;
        this.studentName = studentName;
        this.assessmentId = assessmentId;
        this.score = score;
        this.totalMarks = totalMarks;
        this.percentage = percentage;
        this.accuracy = accuracy;
        this.submissionDate = submissionDate;
        this.answers = answers != null ? answers : new ArrayList<>();
        this.topicBreakdown = new HashMap<>();
        this.moduleBreakdown = new HashMap<>();
        this.difficultyBreakdown = new HashMap<>();
        this.bloomBreakdown = new HashMap<>();
    }

    public String getResultId() { return resultId; }
    public void setResultId(String resultId) { this.resultId = resultId; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getAssessmentId() { return assessmentId; }
    public void setAssessmentId(String assessmentId) { this.assessmentId = assessmentId; }

    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }

    public int getTotalMarks() { return totalMarks; }
    public void setTotalMarks(int totalMarks) { this.totalMarks = totalMarks; }

    public double getPercentage() { return percentage; }
    public void setPercentage(double percentage) { this.percentage = percentage; }

    public double getAccuracy() { return accuracy; }
    public void setAccuracy(double accuracy) { this.accuracy = accuracy; }

    public String getSubmissionDate() { return submissionDate; }
    public void setSubmissionDate(String submissionDate) { this.submissionDate = submissionDate; }

    public List<Answer> getAnswers() { return answers; }
    public void setAnswers(List<Answer> answers) { this.answers = answers; }

    public Map<String, Double> getTopicBreakdown() { return topicBreakdown; }
    public void setTopicBreakdown(Map<String, Double> topicBreakdown) { this.topicBreakdown = topicBreakdown; }

    public Map<String, Double> getModuleBreakdown() { return moduleBreakdown; }
    public void setModuleBreakdown(Map<String, Double> moduleBreakdown) { this.moduleBreakdown = moduleBreakdown; }

    public Map<String, Double> getDifficultyBreakdown() { return difficultyBreakdown; }
    public void setDifficultyBreakdown(Map<String, Double> difficultyBreakdown) { this.difficultyBreakdown = difficultyBreakdown; }

    public Map<String, Double> getBloomBreakdown() { return bloomBreakdown; }
    public void setBloomBreakdown(Map<String, Double> bloomBreakdown) { this.bloomBreakdown = bloomBreakdown; }

    @Override
    public String toString() {
        return "[" + resultId + "] Student: " + studentName + " (" + studentId + ") | Score: " +
                score + "/" + totalMarks + " (" + String.format("%.1f", percentage) + "%) | Accuracy: " +
                String.format("%.1f", accuracy) + "% | Date: " + submissionDate;
    }
}
