package smartsassessment;

import smartsassessment.algorithms.*;
import smartsassessment.model.*;
import smartsassessment.service.*;
import smartsassessment.storage.DataManager;
import smartsassessment.util.IdGenerator;
import smartsassessment.util.InputUtil;
import smartsassessment.util.ValidationUtil;

import java.io.File;
import java.math.BigInteger;
import java.util.*;

/**
 * Main entry point for the Smart Assessment and Question Bank System.
 * Controls the console user interface, application life cycle, and menu routing.
 */
public class Main {

    private static DataManager dataManager;

    public static void main(String[] args) {
        String baseDir = determineDataDirectory();
        dataManager = new DataManager(baseDir);
        dataManager.init();

        boolean running = true;
        while (running) {
            displayMainMenu();
            int choice = InputUtil.readIntInRange("Select an option (1-13): ", 1, 13);
            System.out.println();

            switch (choice) {
                case 1:
                    handleQuestionBank();
                    break;
                case 2:
                    handleGenerateQuestions();
                    break;
                case 3:
                    handleSearchQuestions();
                    break;
                case 4:
                    handleClassifyQuestions();
                    break;
                case 5:
                    handleDetectDuplicates();
                    break;
                case 6:
                    handleCreateAssessment();
                    break;
                case 7:
                    handleStudentAssessment();
                    break;
                case 8:
                    handleEvaluateAssessment();
                    break;
                case 9:
                    handleAnalytics();
                    break;
                case 10:
                    handleAlgorithmLab();
                    break;
                case 11:
                    handleLoadSampleData();
                    break;
                case 12:
                    handleSaveData();
                    break;
                case 13:
                    System.out.println("Saving all data before exit...");
                    dataManager.saveAllData();
                    System.out.println("Data saved successfully. Thank you for using Smart Assessment System!");
                    running = false;
                    break;
            }
        }
    }

    private static String determineDataDirectory() {
        // Look for existing 'data' directory or place in current execution directory
        File currentData = new File("data");
        if (currentData.exists() && currentData.isDirectory()) {
            return currentData.getAbsolutePath();
        }
        File projectRoot = new File(System.getProperty("user.dir"), "data");
        return projectRoot.getAbsolutePath();
    }

    private static void displayMainMenu() {
        System.out.println("\n========================================");
        System.out.println("   SMART ASSESSMENT AND QUESTION BANK   ");
        System.out.println("========================================");
        System.out.println(" 1. Question Bank");
        System.out.println(" 2. Generate Questions");
        System.out.println(" 3. Search Questions");
        System.out.println(" 4. Classify Questions");
        System.out.println(" 5. Detect Duplicate Questions");
        System.out.println(" 6. Create Smart Assessment");
        System.out.println(" 7. Student Assessment");
        System.out.println(" 8. Evaluate Assessment");
        System.out.println(" 9. Performance Analytics");
        System.out.println("10. Algorithm Lab");
        System.out.println("11. Load Sample Data");
        System.out.println("12. Save Data");
        System.out.println("13. Exit");
        System.out.println("========================================");
    }

    // =========================================================================
    // 1. QUESTION BANK SUBMENU
    // =========================================================================
    private static void handleQuestionBank() {
        boolean inBank = true;
        while (inBank) {
            System.out.println("\n--- QUESTION BANK MANAGEMENT ---");
            System.out.println("1. Display All Questions");
            System.out.println("2. Add Question");
            System.out.println("3. Find Question by ID");
            System.out.println("4. Update Question");
            System.out.println("5. Remove Question");
            System.out.println("6. Filter Questions");
            System.out.println("7. Back to Main Menu");

            int ch = InputUtil.readIntInRange("Select option (1-7): ", 1, 7);
            switch (ch) {
                case 1:
                    dataManager.getQuestionBank().displayAllQuestions();
                    InputUtil.pause();
                    break;
                case 2:
                    addNewQuestion();
                    break;
                case 3:
                    String id = InputUtil.readNonEmptyString("Enter Question ID (e.g. Q101): ");
                    Question q = dataManager.getQuestionBank().findQuestionById(id);
                    if (q != null) {
                        System.out.println(q.getFormattedDisplay());
                    } else {
                        System.out.println("  [Error] Question with ID '" + id + "' not found.");
                    }
                    InputUtil.pause();
                    break;
                case 4:
                    updateExistingQuestion();
                    break;
                case 5:
                    String remId = InputUtil.readNonEmptyString("Enter Question ID to remove: ");
                    boolean rem = dataManager.getQuestionBank().removeQuestion(remId);
                    if (rem) {
                        System.out.println("  Question " + remId + " removed successfully.");
                        dataManager.saveAllData();
                    } else {
                        System.out.println("  [Error] Question not found.");
                    }
                    InputUtil.pause();
                    break;
                case 6:
                    handleFilterQuestions();
                    break;
                case 7:
                    inBank = false;
                    break;
            }
        }
    }

    private static void addNewQuestion() {
        System.out.println("\n--- ADD NEW QUESTION ---");
        String module = InputUtil.readNonEmptyString("Enter Module (e.g. Module 1, Module 2, Module 3): ");
        String topic = InputUtil.readNonEmptyString("Enter Topic: ");
        String text = InputUtil.readNonEmptyString("Enter Question Text: ");
        QuestionType type = InputUtil.readEnum("Select Question Type:", QuestionType.class);

        String optA = "", optB = "", optC = "", optD = "";
        String correctAns;
        if (type == QuestionType.MCQ) {
            optA = InputUtil.readNonEmptyString("Enter Option A: ");
            optB = InputUtil.readNonEmptyString("Enter Option B: ");
            optC = InputUtil.readNonEmptyString("Enter Option C: ");
            optD = InputUtil.readNonEmptyString("Enter Option D: ");
            while (true) {
                correctAns = InputUtil.readNonEmptyString("Enter Correct Answer (A/B/C/D): ").toUpperCase();
                if (ValidationUtil.isValidOptionChoice(correctAns)) break;
                System.out.println("  Please enter A, B, C, or D.");
            }
        } else {
            correctAns = InputUtil.readNonEmptyString("Enter Model / Keyword Answer: ");
        }

        String explanation = InputUtil.readString("Enter Explanation / Keywords (optional): ");

        BloomLevel bloom = BloomClassifier.classify(text);
        System.out.println("  Predicted Bloom Level: " + bloom);
        if (InputUtil.readConfirmation("Do you want to manually change the Bloom Level?")) {
            bloom = InputUtil.readEnum("Select Bloom Level:", BloomLevel.class);
        }

        DifficultyLevel diff = DifficultyClassifier.classify(text, type, bloom);
        System.out.println("  Predicted Difficulty: " + diff);
        if (InputUtil.readConfirmation("Do you want to manually change the Difficulty?")) {
            diff = InputUtil.readEnum("Select Difficulty Level:", DifficultyLevel.class);
        }

        int marks = InputUtil.readIntInRange("Enter Marks (1-20): ", 1, 20);

        String qId = IdGenerator.nextQuestionId();
        Question newQ = new Question(
                qId, "Advanced Algorithms", module, topic, text, type,
                optA, optB, optC, optD, correctAns, explanation, diff, bloom, marks
        );

        // Duplicate check against existing bank
        List<DuplicateDetector.SimilarityReport> dupes =
                DuplicateDetector.checkAgainstBank(newQ, dataManager.getQuestionBank().getQuestions());
        if (!dupes.isEmpty()) {
            System.out.println("\n  [Warning] Similar or duplicate questions detected in Question Bank:");
            for (DuplicateDetector.SimilarityReport rep : dupes) {
                rep.printSummary();
            }
            if (!InputUtil.readConfirmation("Do you still wish to add this question?")) {
                System.out.println("  Question creation discarded.");
                return;
            }
        }

        dataManager.getQuestionBank().addQuestion(newQ);
        dataManager.saveAllData();
        System.out.println("\n  Question added successfully with ID: " + qId);
        InputUtil.pause();
    }

    private static void updateExistingQuestion() {
        String id = InputUtil.readNonEmptyString("Enter Question ID to update: ");
        Question q = dataManager.getQuestionBank().findQuestionById(id);
        if (q == null) {
            System.out.println("  [Error] Question not found.");
            InputUtil.pause();
            return;
        }

        System.out.println("\nCurrently editing: " + q);
        String text = InputUtil.readString("Enter new question text (press enter to keep current): ");
        if (!text.isEmpty()) q.setQuestionText(text);

        if (q.getQuestionType() == QuestionType.MCQ) {
            String oA = InputUtil.readString("Enter Option A (press enter to keep): ");
            if (!oA.isEmpty()) q.setOptionA(oA);
            String oB = InputUtil.readString("Enter Option B (press enter to keep): ");
            if (!oB.isEmpty()) q.setOptionB(oB);
            String oC = InputUtil.readString("Enter Option C (press enter to keep): ");
            if (!oC.isEmpty()) q.setOptionC(oC);
            String oD = InputUtil.readString("Enter Option D (press enter to keep): ");
            if (!oD.isEmpty()) q.setOptionD(oD);
        }

        String ans = InputUtil.readString("Enter Correct Answer (press enter to keep): ");
        if (!ans.isEmpty()) q.setCorrectAnswer(ans);

        if (InputUtil.readConfirmation("Change Bloom Level?")) {
            q.setBloomLevel(InputUtil.readEnum("Select Bloom Level:", BloomLevel.class));
        }

        if (InputUtil.readConfirmation("Change Difficulty?")) {
            q.setDifficulty(InputUtil.readEnum("Select Difficulty:", DifficultyLevel.class));
        }

        String marksStr = InputUtil.readString("Enter new marks (press enter to keep current " + q.getMarks() + "): ");
        if (!marksStr.isEmpty()) {
            try {
                q.setMarks(Integer.parseInt(marksStr));
            } catch (Exception ignored) {}
        }

        dataManager.getQuestionBank().updateQuestion(q);
        dataManager.saveAllData();
        System.out.println("  Question updated successfully.");
        InputUtil.pause();
    }

    private static void handleFilterQuestions() {
        System.out.println("\n--- FILTER QUESTIONS ---");
        System.out.println("1. Filter by Module");
        System.out.println("2. Filter by Topic");
        System.out.println("3. Filter by Difficulty");
        System.out.println("4. Filter by Bloom Level");
        System.out.println("5. Filter by Question Type");

        int ch = InputUtil.readIntInRange("Select filter (1-5): ", 1, 5);
        List<Question> filtered = new ArrayList<>();

        switch (ch) {
            case 1:
                String mod = InputUtil.readNonEmptyString("Enter Module name (e.g. Module 2): ");
                filtered = dataManager.getQuestionBank().filterByModule(mod);
                break;
            case 2:
                String top = InputUtil.readNonEmptyString("Enter Topic name: ");
                filtered = dataManager.getQuestionBank().filterByTopic(top);
                break;
            case 3:
                DifficultyLevel diff = InputUtil.readEnum("Select Difficulty:", DifficultyLevel.class);
                filtered = dataManager.getQuestionBank().filterByDifficulty(diff);
                break;
            case 4:
                BloomLevel blm = InputUtil.readEnum("Select Bloom Level:", BloomLevel.class);
                filtered = dataManager.getQuestionBank().filterByBloomLevel(blm);
                break;
            case 5:
                QuestionType tp = InputUtil.readEnum("Select Question Type:", QuestionType.class);
                filtered = dataManager.getQuestionBank().filterByType(tp);
                break;
        }

        System.out.println("\nFiltered Results (" + filtered.size() + " matches):");
        for (Question q : filtered) {
            System.out.println("  " + q);
        }
        InputUtil.pause();
    }

    // =========================================================================
    // 2. QUESTION GENERATION
    // =========================================================================
    private static void handleGenerateQuestions() {
        System.out.println("\n--- RULE-BASED QUESTION GENERATOR ---");
        String module = InputUtil.readNonEmptyString("Enter Module (e.g. Module 2): ");
        String topic = InputUtil.readNonEmptyString("Enter Topic (e.g. KMP, Z-Algorithm, Matrix Chain DP, TSP): ");
        String content = InputUtil.readString("Enter Content/Context notes (optional): ");
        int count = InputUtil.readIntInRange("Number of questions to generate (1-10): ", 1, 10);
        QuestionType type = InputUtil.readEnum("Preferred Question Type:", QuestionType.class);
        DifficultyLevel diff = InputUtil.readEnum("Preferred Difficulty:", DifficultyLevel.class);
        BloomLevel bloom = InputUtil.readEnum("Preferred Bloom Level:", BloomLevel.class);

        List<Question> generated = QuestionGenerator.generateQuestions(topic, module, content, count, type, diff, bloom);

        System.out.println("\nGenerated " + generated.size() + " Question(s):");
        for (Question q : generated) {
            System.out.println(q.getFormattedDisplay());
            System.out.println();
        }

        if (InputUtil.readConfirmation("Add these generated questions to the Question Bank?")) {
            int added = 0;
            for (Question q : generated) {
                if (dataManager.getQuestionBank().addQuestion(q)) {
                    added++;
                }
            }
            dataManager.saveAllData();
            System.out.println("  " + added + " question(s) saved to Question Bank.");
        }
        InputUtil.pause();
    }

    // =========================================================================
    // 3. SEARCH QUESTIONS (KMP)
    // =========================================================================
    private static void handleSearchQuestions() {
        System.out.println("\n--- SEARCH QUESTIONS (KMP SEARCH ENGINE) ---");
        String query = InputUtil.readNonEmptyString("Enter search keyword or phrase: ");
        List<Question> matches = dataManager.getQuestionBank().searchQuestion(query);

        System.out.println("\nSearch Results (" + matches.size() + " matches found using KMP):");
        for (Question q : matches) {
            System.out.println(q.getFormattedDisplay());
            System.out.println();
        }
        InputUtil.pause();
    }

    // =========================================================================
    // 4. CLASSIFY QUESTIONS
    // =========================================================================
    private static void handleClassifyQuestions() {
        System.out.println("\n--- QUESTION CLASSIFIER (BLOOM & DIFFICULTY) ---");
        String text = InputUtil.readNonEmptyString("Enter question text to classify: ");
        QuestionType type = InputUtil.readEnum("Select Question Type:", QuestionType.class);

        BloomLevel bloom = BloomClassifier.classify(text);
        String bloomRationale = BloomClassifier.getClassificationRationale(text, bloom);

        DifficultyClassifier.DifficultyAnalysis diffAnalysis = DifficultyClassifier.analyze(text, type, bloom);

        System.out.println("\n==================================================");
        System.out.println("Classification Results:");
        System.out.println("  Bloom Taxonomy Level: " + bloom);
        System.out.println("  Bloom Rationale:      " + bloomRationale);
        System.out.println("  Difficulty Tier:      " + diffAnalysis.getPredictedLevel() + " (Score: " + diffAnalysis.getScore() + "/11)");
        System.out.println("  Difficulty Rationale: " + diffAnalysis.getRationale());
        System.out.println("==================================================");

        InputUtil.pause();
    }

    // =========================================================================
    // 5. DETECT DUPLICATE QUESTIONS
    // =========================================================================
    private static void handleDetectDuplicates() {
        System.out.println("\n--- DUPLICATE QUESTION DETECTOR (TF-IDF & COSINE SIMILARITY) ---");
        System.out.println("1. Scan Question Bank for duplicate/similar pairs");
        System.out.println("2. Compare two custom questions");

        int ch = InputUtil.readIntInRange("Select option (1-2): ", 1, 2);
        if (ch == 1) {
            List<DuplicateDetector.SimilarityReport> reports =
                    DuplicateDetector.scanAllPairs(dataManager.getQuestionBank().getQuestions());
            if (reports.isEmpty()) {
                System.out.println("  No duplicate or highly similar questions found in Question Bank.");
            } else {
                System.out.println("  Found " + reports.size() + " potential duplicate/similar pair(s):");
                for (DuplicateDetector.SimilarityReport rep : reports) {
                    rep.printSummary();
                }
            }
        } else {
            String t1 = InputUtil.readNonEmptyString("Enter Question 1 text: ");
            String t2 = InputUtil.readNonEmptyString("Enter Question 2 text: ");

            Question q1 = new Question();
            q1.setQuestionId("Custom-A");
            q1.setQuestionText(t1);

            Question q2 = new Question();
            q2.setQuestionId("Custom-B");
            q2.setQuestionText(t2);

            DuplicateDetector.SimilarityReport rep = DuplicateDetector.compare(q1, q2);
            rep.printSummary();
        }
        InputUtil.pause();
    }

    // =========================================================================
    // 6. CREATE SMART ASSESSMENT
    // =========================================================================
    private static void handleCreateAssessment() {
        System.out.println("\n--- CREATE SMART ASSESSMENT ---");
        String title = InputUtil.readNonEmptyString("Enter Assessment Title: ");
        String module = InputUtil.readNonEmptyString("Enter Module filter (e.g. Module 2, or 'ALL'): ");
        int totalQ = InputUtil.readIntInRange("Enter total number of questions: ", 1, 50);
        int duration = InputUtil.readIntInRange("Enter duration in minutes (10-180): ", 10, 180);

        System.out.println("\nSpecify Difficulty Distribution (Percentages must sum to 100%):");
        Map<DifficultyLevel, Integer> diffDist = new HashMap<>();
        while (true) {
            int easy = InputUtil.readIntInRange("  Easy %:   ", 0, 100);
            int med = InputUtil.readIntInRange("  Medium %: ", 0, 100);
            int hard = InputUtil.readIntInRange("  Hard %:   ", 0, 100);
            if (easy + med + hard == 100) {
                diffDist.put(DifficultyLevel.EASY, easy);
                diffDist.put(DifficultyLevel.MEDIUM, med);
                diffDist.put(DifficultyLevel.HARD, hard);
                break;
            }
            System.out.println("  [Error] Percentages sum to " + (easy + med + hard) + "%. Must sum to exactly 100%.");
        }

        System.out.println("\nSpecify Bloom Taxonomy Distribution (Percentages must sum to 100%):");
        Map<BloomLevel, Integer> bloomDist = new HashMap<>();
        while (true) {
            int rem = InputUtil.readIntInRange("  REMEMBER %:   ", 0, 100);
            int und = InputUtil.readIntInRange("  UNDERSTAND %: ", 0, 100);
            int app = InputUtil.readIntInRange("  APPLY %:      ", 0, 100);
            int ana = InputUtil.readIntInRange("  ANALYZE %:    ", 0, 100);
            int eva = InputUtil.readIntInRange("  EVALUATE %:   ", 0, 100);
            int cre = InputUtil.readIntInRange("  CREATE %:     ", 0, 100);
            int sum = rem + und + app + ana + eva + cre;
            if (sum == 100) {
                bloomDist.put(BloomLevel.REMEMBER, rem);
                bloomDist.put(BloomLevel.UNDERSTAND, und);
                bloomDist.put(BloomLevel.APPLY, app);
                bloomDist.put(BloomLevel.ANALYZE, ana);
                bloomDist.put(BloomLevel.EVALUATE, eva);
                bloomDist.put(BloomLevel.CREATE, cre);
                break;
            }
            System.out.println("  [Error] Percentages sum to " + sum + "%. Must sum to exactly 100%.");
        }

        System.out.println("\nOptional Question Type Filter:");
        System.out.println("  1. ANY (Mixed MCQ, Short Answer, Descriptive)");
        System.out.println("  2. MCQ Only");
        System.out.println("  3. Short Answer Only");
        System.out.println("  4. Descriptive Only");
        int typeCh = InputUtil.readIntInRange("Select option (1-4): ", 1, 4);
        QuestionType qType = null;
        if (typeCh == 2) qType = QuestionType.MCQ;
        else if (typeCh == 3) qType = QuestionType.SHORT_ANSWER;
        else if (typeCh == 4) qType = QuestionType.DESCRIPTIVE;

        AssessmentGenerator.GenerationResult genRes = AssessmentGenerator.generate(
                dataManager.getQuestionBank(), title, module, null, totalQ, duration, diffDist, bloomDist, qType
        );

        if (genRes.isSuccess()) {
            Assessment a = genRes.getAssessment();
            dataManager.addAssessment(a);
            dataManager.saveAllData();
            System.out.println("\n  SUCCESS! Assessment generated and saved.");
            System.out.println("  " + a);
            System.out.println("\nSelected Questions:");
            for (Question q : genRes.getSelectedQuestions()) {
                System.out.println("  " + q);
            }
        } else {
            System.out.println("\n  ========================================================");
            System.out.println("  Unable to satisfy the requested distribution!");
            System.out.println("  Deficit details:");
            for (String err : genRes.getDeficitErrors()) {
                System.out.println("    - " + err);
            }
            System.out.println("  ========================================================");
        }
        InputUtil.pause();
    }

    // =========================================================================
    // 7. STUDENT ASSESSMENT SESSION
    // =========================================================================
    private static void handleStudentAssessment() {
        System.out.println("\n--- STUDENT ASSESSMENT SESSION ---");
        if (dataManager.getAssessments().isEmpty()) {
            System.out.println("  [Error] No assessments available. Please create or load an assessment first.");
            InputUtil.pause();
            return;
        }

        String sId = InputUtil.readNonEmptyString("Enter Student ID (e.g. S101, or enter a new ID): ");
        Student student = dataManager.findStudentById(sId);
        if (student == null) {
            String name = InputUtil.readNonEmptyString("New student. Enter Student Name: ");
            String email = InputUtil.readString("Enter Email: ");
            String dept = InputUtil.readString("Enter Department: ");
            student = new Student(sId, name, email, dept);
            dataManager.addStudent(student);
        }
        System.out.println("Welcome, " + student.getName() + "!");

        System.out.println("\nAvailable Assessments:");
        List<Assessment> assessments = dataManager.getAssessments();
        for (int i = 0; i < assessments.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + assessments.get(i));
        }
        int aChoice = InputUtil.readIntInRange("Select assessment to start (1-" + assessments.size() + "): ", 1, assessments.size());
        Assessment targetAssessment = assessments.get(aChoice - 1);

        // Fetch questions
        List<Question> paperQuestions = new ArrayList<>();
        for (String qId : targetAssessment.getQuestionIds()) {
            Question q = dataManager.getQuestionBank().findQuestionById(qId);
            if (q != null) paperQuestions.add(q);
        }

        if (paperQuestions.isEmpty()) {
            System.out.println("  [Error] Assessment has no valid questions linked.");
            InputUtil.pause();
            return;
        }

        System.out.println("\nStarting Assessment: " + targetAssessment.getTitle());
        System.out.println("Total Questions: " + paperQuestions.size() + " | Time Limit: " + targetAssessment.getDurationMinutes() + " minutes");
        System.out.println("You can navigate questions using Next, Previous, Review, and Submit.");

        Map<String, String> studentAnswers = new HashMap<>();
        int currentIndex = 0;

        while (true) {
            Question currQ = paperQuestions.get(currentIndex);
            System.out.println("\n------------------------------------------------------------");
            System.out.printf("Question %d of %d  [%s | %s | %d Marks]%n",
                    (currentIndex + 1), paperQuestions.size(), currQ.getDifficulty(), currQ.getBloomLevel(), currQ.getMarks());
            System.out.println(currQ.getQuestionText());

            if (currQ.getQuestionType() == QuestionType.MCQ) {
                System.out.println("  A. " + currQ.getOptionA());
                System.out.println("  B. " + currQ.getOptionB());
                System.out.println("  C. " + currQ.getOptionC());
                System.out.println("  D. " + currQ.getOptionD());
            }

            String existingAns = studentAnswers.get(currQ.getQuestionId());
            if (existingAns != null && !existingAns.isEmpty()) {
                System.out.println("  [Your current answer: " + existingAns + "]");
            }

            System.out.println("\nOptions: [A]nswer | [N]ext | [P]revious | [R]eview summary | [S]ubmit paper");
            String action = InputUtil.readNonEmptyString("Select action: ").toUpperCase();

            if (action.startsWith("A")) {
                if (currQ.getQuestionType() == QuestionType.MCQ) {
                    while (true) {
                        String ans = InputUtil.readNonEmptyString("Enter your choice (A/B/C/D): ").toUpperCase();
                        if (ValidationUtil.isValidOptionChoice(ans)) {
                            studentAnswers.put(currQ.getQuestionId(), ans);
                            break;
                        }
                        System.out.println("  Invalid choice. Enter A, B, C, or D.");
                    }
                } else {
                    String ans = InputUtil.readNonEmptyString("Enter your answer: ");
                    studentAnswers.put(currQ.getQuestionId(), ans);
                }
                if (currentIndex < paperQuestions.size() - 1) {
                    currentIndex++;
                }
            } else if (action.startsWith("N")) {
                if (currentIndex < paperQuestions.size() - 1) {
                    currentIndex++;
                } else {
                    System.out.println("  You are at the last question.");
                }
            } else if (action.startsWith("P")) {
                if (currentIndex > 0) {
                    currentIndex--;
                } else {
                    System.out.println("  You are at the first question.");
                }
            } else if (action.startsWith("R")) {
                System.out.println("\n--- ASSESSMENT REVIEW SUMMARY ---");
                for (int i = 0; i < paperQuestions.size(); i++) {
                    Question q = paperQuestions.get(i);
                    String ans = studentAnswers.get(q.getQuestionId());
                    System.out.printf("  Q%d [%s]: %s%n", (i + 1), q.getQuestionId(),
                            (ans != null && !ans.isEmpty()) ? "Answered (" + ans + ")" : "[UNANSWERED]");
                }
            } else if (action.startsWith("S")) {
                int answeredCount = studentAnswers.size();
                if (answeredCount < paperQuestions.size()) {
                    System.out.printf("  [Warning] You have answered %d of %d questions.%n", answeredCount, paperQuestions.size());
                    if (!InputUtil.readConfirmation("Are you sure you want to submit now?")) {
                        continue;
                    }
                }
                break;
            }
        }

        // Automatic evaluation upon submission
        Performance performance = AssessmentEvaluator.evaluate(targetAssessment, student, paperQuestions, studentAnswers);
        dataManager.addResult(performance);
        dataManager.saveAllData();

        AssessmentEvaluator.displayEvaluationReport(performance, paperQuestions);
        InputUtil.pause();
    }

    // =========================================================================
    // 8. EVALUATE ASSESSMENT (VIEW RESULTS)
    // =========================================================================
    private static void handleEvaluateAssessment() {
        System.out.println("\n--- ASSESSMENT EVALUATION RESULTS ---");
        List<Performance> results = dataManager.getResults();
        if (results.isEmpty()) {
            System.out.println("  No evaluation results recorded yet.");
            InputUtil.pause();
            return;
        }

        for (int i = 0; i < results.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + results.get(i));
        }

        int choice = InputUtil.readIntInRange("Select result to view details (1-" + results.size() + "): ", 1, results.size());
        Performance selected = results.get(choice - 1);
        Assessment assessment = dataManager.findAssessmentById(selected.getAssessmentId());

        List<Question> questions = new ArrayList<>();
        if (assessment != null) {
            for (String qId : assessment.getQuestionIds()) {
                Question q = dataManager.getQuestionBank().findQuestionById(qId);
                if (q != null) questions.add(q);
            }
        }

        AssessmentEvaluator.displayEvaluationReport(selected, questions);
        InputUtil.pause();
    }

    // =========================================================================
    // 9. PERFORMANCE ANALYTICS
    // =========================================================================
    private static void handleAnalytics() {
        AnalyticsService.OverallAnalytics analytics = AnalyticsService.computeAnalytics(dataManager.getResults());
        analytics.printReport();
        InputUtil.pause();
    }

    // =========================================================================
    // 10. ALGORITHM LAB
    // =========================================================================
    private static void handleAlgorithmLab() {
        boolean inLab = true;
        while (inLab) {
            System.out.println("\n=================================");
            System.out.println("          ALGORITHM LAB          ");
            System.out.println("=================================");
            System.out.println(" 1. KMP");
            System.out.println(" 2. Z Algorithm");
            System.out.println(" 3. Rabin-Karp");
            System.out.println(" 4. Edit Distance");
            System.out.println(" 5. Damerau-Levenshtein");
            System.out.println(" 6. Weighted Edit Distance");
            System.out.println(" 7. TF-IDF");
            System.out.println(" 8. Cosine Similarity");
            System.out.println(" 9. Suffix Array");
            System.out.println("10. LCP Kasai");
            System.out.println("11. Aho-Corasick");
            System.out.println("12. Matrix Chain DP");
            System.out.println("13. TSP Bitmask DP");
            System.out.println("14. Hamiltonian Path");
            System.out.println("15. Tree DP");
            System.out.println("16. SOS DP");
            System.out.println("17. Max Flow");
            System.out.println("18. Miller-Rabin");
            System.out.println("19. Back");
            System.out.println("=================================");

            int ch = InputUtil.readIntInRange("Select algorithm (1-19): ", 1, 19);
            System.out.println();

            switch (ch) {
                case 1:
                    runKMPLab();
                    break;
                case 2:
                    runZLab();
                    break;
                case 3:
                    runRabinKarpLab();
                    break;
                case 4:
                    runEditDistanceLab();
                    break;
                case 5:
                    runDamerauLevenshteinLab();
                    break;
                case 6:
                    runWeightedEditDistanceLab();
                    break;
                case 7:
                    runTFIDFLab();
                    break;
                case 8:
                    runCosineSimilarityLab();
                    break;
                case 9:
                    runSuffixArrayLab();
                    break;
                case 10:
                    runLCPKasaiLab();
                    break;
                case 11:
                    runAhoCorasickLab();
                    break;
                case 12:
                    runMatrixChainLab();
                    break;
                case 13:
                    runTSPLab();
                    break;
                case 14:
                    runHamiltonianLab();
                    break;
                case 15:
                    runTreeDPLab();
                    break;
                case 16:
                    runSOSDPLab();
                    break;
                case 17:
                    runMaxFlowLab();
                    break;
                case 18:
                    runMillerRabinLab();
                    break;
                case 19:
                    inLab = false;
                    break;
            }
        }
    }

    private static void printComplexityCard(String info) {
        System.out.println("\n------------------------------------------------------------");
        System.out.println(info);
        System.out.println("------------------------------------------------------------");
    }

    private static void runKMPLab() {
        printComplexityCard(KMP.getComplexityInfo());
        String text = InputUtil.readNonEmptyString("Enter Text (default 'ABABDABACDABABCABAB'): ");
        String pattern = InputUtil.readNonEmptyString("Enter Pattern (default 'ABABCABAB'): ");

        KMP.SearchResult res = KMP.search(text, pattern);
        System.out.print("\nFailure Function (pi table) for pattern '" + pattern + "': [");
        for (int i = 0; i < res.getFailureFunction().length; i++) {
            System.out.print(res.getFailureFunction()[i] + (i < res.getFailureFunction().length - 1 ? ", " : ""));
        }
        System.out.println("]");

        System.out.println("Matching Positions (0-indexed): " + (res.isFound() ? res.getPositions() : "None"));
        System.out.println("Total Character Comparisons:    " + res.getComparisons());
        InputUtil.pause();
    }

    private static void runZLab() {
        printComplexityCard(ZAlgorithm.getComplexityInfo());
        String text = InputUtil.readNonEmptyString("Enter Text: ");
        String pattern = InputUtil.readNonEmptyString("Enter Pattern: ");

        ZAlgorithm.ZResult res = ZAlgorithm.search(text, pattern);
        System.out.println("\nCombined String: " + res.getCombinedString());
        System.out.print("Z-Array: [");
        for (int i = 0; i < res.getZArray().length; i++) {
            System.out.print(res.getZArray()[i] + (i < res.getZArray().length - 1 ? ", " : ""));
        }
        System.out.println("]");
        System.out.println("Pattern Matches at Text Indices: " + res.getMatchPositions());
        InputUtil.pause();
    }

    private static void runRabinKarpLab() {
        printComplexityCard(RabinKarp.getComplexityInfo());
        String text = InputUtil.readNonEmptyString("Enter Text: ");
        String pattern = InputUtil.readNonEmptyString("Enter Pattern: ");

        RabinKarp.RKResult res = RabinKarp.search(text, pattern);
        System.out.println("\nPattern Hash:           " + res.getPatternHash());
        System.out.println("Matching Text Indices:  " + res.getMatchPositions());
        System.out.println("Hash Comparisons Made:  " + res.getHashComparisons());
        System.out.println("Spurious Hash Hits:     " + res.getSpuriousHits());
        InputUtil.pause();
    }

    private static void runEditDistanceLab() {
        printComplexityCard(EditDistance.getComplexityInfo());
        String a = InputUtil.readNonEmptyString("Enter String A (e.g. 'kitten'): ");
        String b = InputUtil.readNonEmptyString("Enter String B (e.g. 'sitting'): ");

        EditDistance.Result res = EditDistance.calculate(a, b);
        res.printDPTable();
        System.out.println("\nMinimum Edit Distance: " + res.getDistance());
        System.out.printf("Breakdown: %d Insertions, %d Deletions, %d Substitutions%n",
                res.getInsertions(), res.getDeletions(), res.getSubstitutions());
        System.out.println("\nOperation Traceback:");
        for (String op : res.getOperations()) {
            System.out.println("  -> " + op);
        }
        InputUtil.pause();
    }

    private static void runDamerauLevenshteinLab() {
        printComplexityCard(DamerauLevenshtein.getComplexityInfo());
        String a = InputUtil.readNonEmptyString("Enter String A (e.g. 'CA'): ");
        String b = InputUtil.readNonEmptyString("Enter String B (e.g. 'AC'): ");

        DamerauLevenshtein.DLResult res = DamerauLevenshtein.calculate(a, b);
        res.printTable();
        System.out.println("\nDamerau-Levenshtein Distance: " + res.getDistance());
        InputUtil.pause();
    }

    private static void runWeightedEditDistanceLab() {
        printComplexityCard(WeightedEditDistance.getComplexityInfo());
        String a = InputUtil.readNonEmptyString("Enter String A: ");
        String b = InputUtil.readNonEmptyString("Enter String B: ");
        int insCost = InputUtil.readIntInRange("Insertion Cost: ", 1, 10);
        int delCost = InputUtil.readIntInRange("Deletion Cost: ", 1, 10);
        int subCost = InputUtil.readIntInRange("Substitution Cost: ", 1, 10);

        WeightedEditDistance.WEDResult res = WeightedEditDistance.calculate(a, b, insCost, delCost, subCost);
        res.printTable();
        System.out.println("\nMinimum Weighted Cost: " + res.getTotalCost());
        InputUtil.pause();
    }

    private static void runTFIDFLab() {
        printComplexityCard(TFIDF.getComplexityInfo());
        System.out.println("Enter documents to build corpus (enter empty line when done):");
        List<String> docs = new ArrayList<>();
        int i = 1;
        while (true) {
            String line = InputUtil.readString("Document #" + (i++) + ": ");
            if (line.isEmpty()) {
                if (docs.size() >= 2) break;
                System.out.println("  Please enter at least 2 documents.");
                continue;
            }
            docs.add(line);
        }

        TFIDF model = new TFIDF(docs);
        System.out.println("\nVocabulary (" + model.getVocabulary().size() + " terms): " + model.getVocabulary());

        String testDoc = InputUtil.readNonEmptyString("Enter text to transform into TF-IDF vector: ");
        double[] vec = model.transform(testDoc);
        System.out.println("\nGenerated TF-IDF Vector:");
        for (int v = 0; v < vec.length; v++) {
            if (vec[v] > 0.0001) {
                System.out.printf("  Term '%s': %.4f%n", model.getVocabulary().get(v), vec[v]);
            }
        }
        InputUtil.pause();
    }

    private static void runCosineSimilarityLab() {
        printComplexityCard(CosineSimilarity.getComplexityInfo());
        String s1 = InputUtil.readNonEmptyString("Enter Text 1: ");
        String s2 = InputUtil.readNonEmptyString("Enter Text 2: ");

        TFIDF model = new TFIDF(Arrays.asList(s1, s2));
        double[] v1 = model.transform(s1);
        double[] v2 = model.transform(s2);
        double sim = CosineSimilarity.compute(v1, v2);

        System.out.printf("%nCosine Similarity: %.4f (%.2f%%)%n", sim, sim * 100);
        InputUtil.pause();
    }

    private static void runSuffixArrayLab() {
        printComplexityCard(SuffixArray.getComplexityInfo());
        String text = InputUtil.readNonEmptyString("Enter Text (e.g. 'banana'): ");

        SuffixArray sa = new SuffixArray(text);
        System.out.println("\nSuffix Array Indices: " + Arrays.toString(sa.getSA()));
        System.out.println("\nSorted Suffixes:");
        for (int i = 0; i < sa.getSA().length; i++) {
            System.out.printf("  SA[%d] = %d  -> %s%n", i, sa.getSA()[i], sa.getSuffix(i));
        }

        String pat = InputUtil.readString("\nEnter pattern to search using binary search (or enter to skip): ");
        if (!pat.isEmpty()) {
            List<Integer> pos = sa.search(pat);
            System.out.println("Pattern occurrences found at text indices: " + pos);
        }
        InputUtil.pause();
    }

    private static void runLCPKasaiLab() {
        printComplexityCard(LCPKasai.getComplexityInfo());
        String text = InputUtil.readNonEmptyString("Enter Text (e.g. 'banana'): ");

        LCPKasai.LCPResult res = LCPKasai.compute(text);
        res.printTable();
        InputUtil.pause();
    }

    private static void runAhoCorasickLab() {
        printComplexityCard(AhoCorasick.getComplexityInfo());
        String text = InputUtil.readNonEmptyString("Enter Text (e.g. 'ushers'): ");
        System.out.println("Enter patterns to search (comma-separated, e.g. 'he,she,his,hers'):");
        String patLine = InputUtil.readNonEmptyString("Patterns: ");
        List<String> patterns = new ArrayList<>();
        for (String p : patLine.split(",")) {
            if (!p.trim().isEmpty()) patterns.add(p.trim());
        }

        AhoCorasick ac = new AhoCorasick(patterns);
        List<AhoCorasick.Match> matches = ac.search(text);

        System.out.println("\nDiscovered Pattern Matches (" + matches.size() + " total):");
        for (AhoCorasick.Match m : matches) {
            System.out.println("  -> " + m);
        }
        InputUtil.pause();
    }

    private static void runMatrixChainLab() {
        printComplexityCard(MatrixChainDP.getComplexityInfo());
        System.out.println("Enter matrix dimensions array p (length n + 1 for n matrices, comma-separated):");
        System.out.println("Example: '10, 100, 5, 50' represents 3 matrices: 10x100, 100x5, 5x50");
        String line = InputUtil.readNonEmptyString("Dimensions: ");
        String[] parts = line.split(",");
        int[] p = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            p[i] = Integer.parseInt(parts[i].trim());
        }

        MatrixChainDP.MCMResult res = MatrixChainDP.solve(p);
        res.printTable();
        System.out.println("\nMinimum Scalar Multiplications: " + res.getMinMultiplications());
        System.out.println("Optimal Parenthesization:       " + res.getOptimalParenthesization());
        InputUtil.pause();
    }

    private static void runTSPLab() {
        printComplexityCard(TSPBitmaskDP.getComplexityInfo());
        System.out.println("Travelling Salesman Problem (Bitmask DP).");
        System.out.println("1. Run default 4-city demonstration");
        System.out.println("2. Enter custom distance matrix (up to 6 cities)");

        int ch = InputUtil.readIntInRange("Select option (1-2): ", 1, 2);
        int[][] dist;
        if (ch == 1) {
            dist = new int[][]{
                    {0, 10, 15, 20},
                    {10, 0, 35, 25},
                    {15, 35, 0, 30},
                    {20, 25, 30, 0}
            };
        } else {
            int n = InputUtil.readIntInRange("Number of cities (3-6): ", 3, 6);
            dist = new int[n][n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (i == j) {
                        dist[i][j] = 0;
                    } else {
                        dist[i][j] = InputUtil.readIntInRange("Distance from City " + i + " to City " + j + ": ", 1, 1000);
                    }
                }
            }
        }

        TSPBitmaskDP.TSPResult res = TSPBitmaskDP.solve(dist);
        res.printTour();
        InputUtil.pause();
    }

    private static void runHamiltonianLab() {
        printComplexityCard(HamiltonianPath.getComplexityInfo());
        System.out.println("1. Run default 4-node graph test (Edges: 0-1, 1-2, 2-3)");
        System.out.println("2. Enter custom graph");

        int ch = InputUtil.readIntInRange("Select option (1-2): ", 1, 2);
        int n;
        boolean[][] adj;

        if (ch == 1) {
            n = 4;
            adj = new boolean[4][4];
            adj[0][1] = adj[1][0] = true;
            adj[1][2] = adj[2][1] = true;
            adj[2][3] = adj[3][2] = true;
        } else {
            n = InputUtil.readIntInRange("Number of vertices (2-8): ", 2, 8);
            adj = new boolean[n][n];
            int e = InputUtil.readIntInRange("Number of undirected edges: ", 0, n * (n - 1) / 2);
            for (int i = 0; i < e; i++) {
                int u = InputUtil.readIntInRange("Edge #" + (i + 1) + " vertex u (0-" + (n - 1) + "): ", 0, n - 1);
                int v = InputUtil.readIntInRange("Edge #" + (i + 1) + " vertex v (0-" + (n - 1) + "): ", 0, n - 1);
                adj[u][v] = adj[v][u] = true;
            }
        }

        HamiltonianPath.HPResult res = HamiltonianPath.findPath(n, adj);
        res.printResult();
        InputUtil.pause();
    }

    private static void runTreeDPLab() {
        printComplexityCard(TreeDP.getComplexityInfo());
        System.out.println("Tree DP & Rerooting Technique.");
        System.out.println("1. Run default 5-node tree (0-1, 0-2, 1-3, 1-4)");
        System.out.println("2. Enter custom tree");

        int ch = InputUtil.readIntInRange("Select option (1-2): ", 1, 2);
        int n;
        List<List<Integer>> adj = new ArrayList<>();

        if (ch == 1) {
            n = 5;
            for (int i = 0; i < n; i++) adj.add(new ArrayList<>());
            adj.get(0).add(1); adj.get(1).add(0);
            adj.get(0).add(2); adj.get(2).add(0);
            adj.get(1).add(3); adj.get(3).add(1);
            adj.get(1).add(4); adj.get(4).add(1);
        } else {
            n = InputUtil.readIntInRange("Number of nodes (2-15): ", 2, 15);
            for (int i = 0; i < n; i++) adj.add(new ArrayList<>());
            System.out.println("Enter " + (n - 1) + " tree edges:");
            for (int i = 0; i < n - 1; i++) {
                int u = InputUtil.readIntInRange("Edge #" + (i + 1) + " node u: ", 0, n - 1);
                int v = InputUtil.readIntInRange("Edge #" + (i + 1) + " node v: ", 0, n - 1);
                adj.get(u).add(v);
                adj.get(v).add(u);
            }
        }

        TreeDP.TreeResult res = TreeDP.analyze(n, adj);
        res.printAnalysis();
        InputUtil.pause();
    }

    private static void runSOSDPLab() {
        printComplexityCard(SOSDP.getComplexityInfo());
        int n = InputUtil.readIntInRange("Number of bits N (2-5, size 2^N): ", 2, 5);
        int total = 1 << n;
        long[] arr = new long[total];

        System.out.println("Enter " + total + " values for array A (or enter 'd' for sequential 1.." + total + "):");
        String opt = InputUtil.readString("Values or 'd': ");
        if (opt.equalsIgnoreCase("d")) {
            for (int i = 0; i < total; i++) arr[i] = i + 1;
        } else {
            for (int i = 0; i < total; i++) {
                arr[i] = InputUtil.readInt("A[" + i + "]: ");
            }
        }

        SOSDP.SOSResult res = SOSDP.compute(n, arr);
        res.printResults();
        InputUtil.pause();
    }

    private static void runMaxFlowLab() {
        printComplexityCard(MaxFlow.getComplexityInfo());
        System.out.println("1. Run default 4-node flow network (Source: 0, Sink: 3)");
        System.out.println("2. Enter custom flow network");

        int ch = InputUtil.readIntInRange("Select option (1-2): ", 1, 2);
        int n, s, t;
        List<MaxFlow.FlowEdge> edges = new ArrayList<>();

        if (ch == 1) {
            n = 4;
            s = 0;
            t = 3;
            edges.add(new MaxFlow.FlowEdge(0, 1, 20));
            edges.add(new MaxFlow.FlowEdge(0, 2, 10));
            edges.add(new MaxFlow.FlowEdge(1, 2, 30));
            edges.add(new MaxFlow.FlowEdge(1, 3, 10));
            edges.add(new MaxFlow.FlowEdge(2, 3, 20));
        } else {
            n = InputUtil.readIntInRange("Number of vertices (2-10): ", 2, 10);
            s = InputUtil.readIntInRange("Source vertex index: ", 0, n - 1);
            t = InputUtil.readIntInRange("Sink vertex index: ", 0, n - 1);
            int m = InputUtil.readIntInRange("Number of directed edges: ", 1, 30);
            for (int i = 0; i < m; i++) {
                int u = InputUtil.readIntInRange("Edge #" + (i + 1) + " from: ", 0, n - 1);
                int v = InputUtil.readIntInRange("Edge #" + (i + 1) + " to: ", 0, n - 1);
                int cap = InputUtil.readIntInRange("Capacity: ", 1, 10000);
                edges.add(new MaxFlow.FlowEdge(u, v, cap));
            }
        }

        MaxFlow.MaxFlowResult res = MaxFlow.computeMaxFlow(n, edges, s, t);
        res.printSummary();
        InputUtil.pause();
    }

    private static void runMillerRabinLab() {
        printComplexityCard(PrimalityTest.getComplexityInfo());
        System.out.println("1. Test standard integer (up to 64-bit long)");
        System.out.println("2. Test large cryptographic BigInteger");

        int ch = InputUtil.readIntInRange("Select option (1-2): ", 1, 2);
        int rounds = InputUtil.readIntInRange("Number of random witness rounds (e.g. 10): ", 1, 50);

        if (ch == 1) {
            long val = InputUtil.readInt("Enter positive integer to test: ");
            PrimalityTest.PrimalityResult res = PrimalityTest.test(val, rounds);
            System.out.println("\nVerdict:        " + (res.isProbablyPrime() ? "PROBABLY PRIME" : "COMPOSITE"));
            System.out.printf("Confidence:     %.6f%%%n", res.getConfidence() * 100);
            System.out.println("Rounds Tested:  " + res.getRoundsTested());
            System.out.println("Details:        " + res.getWitnessDetail());
        } else {
            String bigStr = InputUtil.readNonEmptyString("Enter large integer string: ");
            try {
                BigInteger bigVal = new BigInteger(bigStr);
                PrimalityTest.PrimalityResult res = PrimalityTest.testBigInteger(bigVal, rounds);
                System.out.println("\nVerdict:        " + (res.isProbablyPrime() ? "PROBABLY PRIME" : "COMPOSITE"));
                System.out.printf("Confidence:     %.6f%%%n", res.getConfidence() * 100);
                System.out.println("Rounds Tested:  " + res.getRoundsTested());
                System.out.println("Details:        " + res.getWitnessDetail());
            } catch (Exception e) {
                System.out.println("  [Error] Invalid BigInteger format: " + e.getMessage());
            }
        }
        InputUtil.pause();
    }

    // =========================================================================
    // 11. LOAD SAMPLE DATA
    // =========================================================================
    private static void handleLoadSampleData() {
        if (InputUtil.readConfirmation("Reload comprehensive 60+ sample questions? This will merge/refresh dataset.")) {
            dataManager.loadSampleData();
            dataManager.saveAllData();
            System.out.println("  Sample dataset successfully loaded (" +
                    dataManager.getQuestionBank().getQuestionCount() + " questions total).");
        }
        InputUtil.pause();
    }

    // =========================================================================
    // 12. SAVE DATA
    // =========================================================================
    private static void handleSaveData() {
        dataManager.saveAllData();
        System.out.println("  All questions, students, assessments, and results have been committed to disk.");
        InputUtil.pause();
    }
}
