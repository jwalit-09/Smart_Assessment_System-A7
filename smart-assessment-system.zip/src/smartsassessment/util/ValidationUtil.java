package smartsassessment.util;

import java.util.Map;

/**
 * Utility for input validation across the application.
 */
public class ValidationUtil {

    public static boolean isNonEmpty(String str) {
        return str != null && !str.trim().isEmpty();
    }

    public static boolean isValidMarks(int marks) {
        return marks > 0 && marks <= 100;
    }

    public static boolean validateDistributionPercentages(Map<?, Integer> distribution) {
        if (distribution == null || distribution.isEmpty()) {
            return false;
        }
        int total = 0;
        for (int val : distribution.values()) {
            if (val < 0) return false;
            total += val;
        }
        return total == 100;
    }

    public static boolean isValidOptionChoice(String choice) {
        if (choice == null) return false;
        String clean = choice.trim().toUpperCase();
        return clean.equals("A") || clean.equals("B") || clean.equals("C") || clean.equals("D");
    }

    public static String sanitize(String input) {
        if (input == null) return "";
        // Replace pipe symbols used in file storage delimiters and tabs/newlines with spaces
        return input.replace("|", "/").replace("\r", " ").replace("\n", " ").trim();
    }
}
