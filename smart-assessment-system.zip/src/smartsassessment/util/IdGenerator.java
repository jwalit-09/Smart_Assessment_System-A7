package smartsassessment.util;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Utility for generating unique, formatted identifiers for entities in the system.
 */
public class IdGenerator {
    private static final AtomicInteger questionCounter = new AtomicInteger(100);
    private static final AtomicInteger studentCounter = new AtomicInteger(100);
    private static final AtomicInteger assessmentCounter = new AtomicInteger(100);
    private static final AtomicInteger resultCounter = new AtomicInteger(100);

    public static synchronized String nextQuestionId() {
        return "Q" + questionCounter.incrementAndGet();
    }

    public static synchronized String nextStudentId() {
        return "S" + studentCounter.incrementAndGet();
    }

    public static synchronized String nextAssessmentId() {
        return "A" + assessmentCounter.incrementAndGet();
    }

    public static synchronized String nextResultId() {
        return "R" + resultCounter.incrementAndGet();
    }

    public static synchronized void updateQuestionCounter(int maxIdNum) {
        if (maxIdNum > questionCounter.get()) {
            questionCounter.set(maxIdNum);
        }
    }

    public static synchronized void updateStudentCounter(int maxIdNum) {
        if (maxIdNum > studentCounter.get()) {
            studentCounter.set(maxIdNum);
        }
    }

    public static synchronized void updateAssessmentCounter(int maxIdNum) {
        if (maxIdNum > assessmentCounter.get()) {
            assessmentCounter.set(maxIdNum);
        }
    }

    public static synchronized void updateResultCounter(int maxIdNum) {
        if (maxIdNum > resultCounter.get()) {
            resultCounter.set(maxIdNum);
        }
    }
}
