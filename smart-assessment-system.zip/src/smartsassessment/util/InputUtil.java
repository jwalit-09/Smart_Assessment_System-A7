package smartsassessment.util;

import java.util.Scanner;

/**
 * Robust console input reader that never crashes on invalid user input or stream termination.
 */
public class InputUtil {
    private static final Scanner scanner = new Scanner(System.in);

    public static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            if (!scanner.hasNextLine()) {
                System.out.println("13");
                return 13; // Gracefully default to Exit on stream termination
            }
            String line = scanner.nextLine().trim();
            if (line.isEmpty()) {
                continue;
            }
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("  [Error] Invalid integer. Please enter a valid whole number.");
            }
        }
    }

    public static int readIntInRange(String prompt, int min, int max) {
        while (true) {
            int val = readInt(prompt);
            if (val >= min && val <= max) {
                return val;
            }
            System.out.println("  [Error] Please enter a value between " + min + " and " + max + ".");
        }
    }

    public static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            if (!scanner.hasNextLine()) {
                return 0.0;
            }
            String line = scanner.nextLine().trim();
            if (line.isEmpty()) {
                continue;
            }
            try {
                return Double.parseDouble(line);
            } catch (NumberFormatException e) {
                System.out.println("  [Error] Invalid number. Please enter a valid decimal number.");
            }
        }
    }

    public static double readDoubleInRange(String prompt, double min, double max) {
        while (true) {
            double val = readDouble(prompt);
            if (val >= min && val <= max) {
                return val;
            }
            System.out.printf("  [Error] Please enter a value between %.2f and %.2f.%n", min, max);
        }
    }

    public static String readString(String prompt) {
        System.out.print(prompt);
        if (!scanner.hasNextLine()) {
            return "";
        }
        return scanner.nextLine().trim();
    }

    public static String readNonEmptyString(String prompt) {
        while (true) {
            System.out.print(prompt);
            if (!scanner.hasNextLine()) {
                return "Default";
            }
            String line = scanner.nextLine().trim();
            if (!line.isEmpty()) {
                return line;
            }
            System.out.println("  [Error] Input cannot be empty. Please try again.");
        }
    }

    public static boolean readConfirmation(String prompt) {
        while (true) {
            System.out.print(prompt + " (y/n): ");
            if (!scanner.hasNextLine()) {
                return true;
            }
            String line = scanner.nextLine().trim().toLowerCase();
            if (line.isEmpty()) {
                continue;
            }
            if (line.equals("y") || line.equals("yes")) {
                return true;
            } else if (line.equals("n") || line.equals("no")) {
                return false;
            }
            System.out.println("  [Error] Please enter 'y' for yes or 'n' for no.");
        }
    }

    public static <E extends Enum<E>> E readEnum(String prompt, Class<E> enumClass) {
        E[] constants = enumClass.getEnumConstants();
        System.out.println(prompt);
        for (int i = 0; i < constants.length; i++) {
            System.out.println("  " + (i + 1) + ". " + constants[i].name());
        }
        int choice = readIntInRange("Select option (1-" + constants.length + "): ", 1, constants.length);
        return constants[choice - 1];
    }

    public static void pause() {
        System.out.print("\nPress [Enter] to continue...");
        if (scanner.hasNextLine()) {
            scanner.nextLine();
        }
    }
}
