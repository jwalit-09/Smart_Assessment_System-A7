package smartsassessment.algorithms;

import java.util.ArrayList;
import java.util.List;

/**
 * Tree Dynamic Programming and Rerooting Technique.
 * Demonstrates:
 * 1. Subtree calculations (sizes and depths) via bottom-up DFS.
 * 2. Tree Diameter (longest path between any two nodes) via Tree DP.
 * 3. Rerooting DP: computes sum of distances from every node to all other nodes in O(N) using 2 passes.
 */
public class TreeDP {

    public static class TreeResult {
        private final int diameter;
        private final int[] subtreeSizes;
        private final int[] depths;
        private final long[] sumOfDistances;
        private final int n;

        public TreeResult(int diameter, int[] subtreeSizes, int[] depths, long[] sumOfDistances, int n) {
            this.diameter = diameter;
            this.subtreeSizes = subtreeSizes;
            this.depths = depths;
            this.sumOfDistances = sumOfDistances;
            this.n = n;
        }

        public int getDiameter() { return diameter; }
        public int[] getSubtreeSizes() { return subtreeSizes; }
        public int[] getDepths() { return depths; }
        public long[] getSumOfDistances() { return sumOfDistances; }

        public void printAnalysis() {
            System.out.println("\nTree DP Analysis Results:");
            System.out.println("  Total Vertices (N):    " + n);
            System.out.println("  Tree Diameter:         " + diameter + " edges");
            System.out.println("\nNode Metrics:");
            System.out.printf("  %-6s | %-12s | %-6s | %-16s%n", "Node", "Subtree Size", "Depth", "Sum of Distances");
            System.out.println("  --------------------------------------------------");
            for (int i = 0; i < n; i++) {
                System.out.printf("  %-6d | %-12d | %-6d | %-16d%n",
                        i, subtreeSizes[i], depths[i], sumOfDistances[i]);
            }
        }
    }

    private static int maxDiameter = 0;

    /**
     * Solves tree diameter, subtree sizes, depths, and rerooted distance sums in O(N) time.
     */
    public static TreeResult analyze(int n, List<List<Integer>> adj) {
        if (n <= 0 || adj == null) {
            return new TreeResult(0, new int[0], new int[0], new long[0], 0);
        }

        int[] subtreeSize = new int[n];
        int[] depth = new int[n];
        long[] distSum = new long[n];
        maxDiameter = 0;

        // Pass 1: Bottom-up DFS rooted at node 0
        dfsRooted(0, -1, 0, adj, subtreeSize, depth, distSum);

        // Pass 2: Top-down DFS to reroot and propagate distance sums
        dfsReroot(0, -1, n, adj, subtreeSize, distSum);

        return new TreeResult(maxDiameter, subtreeSize, depth, distSum, n);
    }

    private static int dfsRooted(int u, int p, int d, List<List<Integer>> adj,
                                 int[] subtreeSize, int[] depth, long[] distSum) {
        subtreeSize[u] = 1;
        depth[u] = d;
        int maxChildDepth1 = 0;
        int maxChildDepth2 = 0;

        for (int v : adj.get(u)) {
            if (v != p) {
                int childHeight = dfsRooted(v, u, d + 1, adj, subtreeSize, depth, distSum) + 1;
                subtreeSize[u] += subtreeSize[v];
                distSum[0] += subtreeSize[v]; // add contribution of subtree v to root 0

                if (childHeight > maxChildDepth1) {
                    maxChildDepth2 = maxChildDepth1;
                    maxChildDepth1 = childHeight;
                } else if (childHeight > maxChildDepth2) {
                    maxChildDepth2 = childHeight;
                }
            }
        }

        // Diameter passing through node u as highest point
        maxDiameter = Math.max(maxDiameter, maxChildDepth1 + maxChildDepth2);
        return maxChildDepth1;
    }

    private static void dfsReroot(int u, int p, int totalN, List<List<Integer>> adj,
                                  int[] subtreeSize, long[] distSum) {
        for (int v : adj.get(u)) {
            if (v != p) {
                // When moving root from u to v:
                // All nodes in v's subtree get 1 step closer (- subtreeSize[v])
                // All nodes outside v's subtree get 1 step further (+ (totalN - subtreeSize[v]))
                distSum[v] = distSum[u] - subtreeSize[v] + (totalN - subtreeSize[v]);
                dfsReroot(v, u, totalN, adj, subtreeSize, distSum);
            }
        }
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Tree Dynamic Programming & Rerooting\n" +
               "Time Complexity:  O(N) [Two linear DFS traversals on N nodes and N-1 edges]\n" +
               "Space Complexity: O(N) [Recursion stack and DP arrays]\n" +
               "Core Concept:     Rerooting allows computing global properties for all roots\n" +
               "                  in O(N) total time rather than O(N^2) naive repeated DFS.";
    }
}
