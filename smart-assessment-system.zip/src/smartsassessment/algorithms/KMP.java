package smartsassessment.algorithms;

import java.util.ArrayList;
import java.util.List;

/**
 * Knuth-Morris-Pratt (KMP) Pattern Matching Algorithm.
 * Precomputes the Longest Proper Prefix which is also Suffix (pi / failure function).
 * Avoids backtracking in the text during search.
 */
public class KMP {

    public static class SearchResult {
        private final List<Integer> positions;
        private final int comparisons;
        private final int[] failureFunction;

        public SearchResult(List<Integer> positions, int comparisons, int[] failureFunction) {
            this.positions = positions;
            this.comparisons = comparisons;
            this.failureFunction = failureFunction;
        }

        public List<Integer> getPositions() { return positions; }
        public int getComparisons() { return comparisons; }
        public int[] getFailureFunction() { return failureFunction; }
        public boolean isFound() { return !positions.isEmpty(); }
    }

    /**
     * Builds the prefix function (pi / failure table) for pattern.
     * pi[i] is the length of the longest proper prefix of pattern[0..i] that is also a suffix.
     * Time: O(m), Space: O(m)
     */
    public static int[] buildFailureFunction(String pattern) {
        int m = pattern.length();
        int[] pi = new int[m];
        int j = 0; // length of previous longest prefix suffix

        for (int i = 1; i < m; i++) {
            while (j > 0 && pattern.charAt(i) != pattern.charAt(j)) {
                j = pi[j - 1];
            }
            if (pattern.charAt(i) == pattern.charAt(j)) {
                j++;
            }
            pi[i] = j;
        }
        return pi;
    }

    /**
     * Searches for occurrences of pattern within text using precomputed failure function.
     * Time: O(n + m), Space: O(m)
     */
    public static SearchResult search(String text, String pattern) {
        List<Integer> positions = new ArrayList<>();
        if (text == null || pattern == null || pattern.isEmpty() || text.length() < pattern.length()) {
            return new SearchResult(positions, 0, new int[0]);
        }

        int[] pi = buildFailureFunction(pattern);
        int n = text.length();
        int m = pattern.length();
        int comparisons = 0;
        int j = 0; // index in pattern

        for (int i = 0; i < n; i++) {
            while (j > 0 && text.charAt(i) != pattern.charAt(j)) {
                comparisons++;
                j = pi[j - 1];
            }
            comparisons++;
            if (text.charAt(i) == pattern.charAt(j)) {
                j++;
            }
            if (j == m) {
                positions.add(i - m + 1);
                j = pi[j - 1]; // look for next occurrence
            }
        }

        return new SearchResult(positions, comparisons, pi);
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Knuth-Morris-Pratt (KMP)\n" +
               "Time Complexity:  O(n + m) [Preprocessing: O(m), Matching: O(n)]\n" +
               "Space Complexity: O(m) [Failure Table / Prefix Function]\n" +
               "Core Concept:     Uses the failure function (pi table) to shift the pattern\n" +
               "                  forward without ever backtracking the text index pointer.";
    }
}
