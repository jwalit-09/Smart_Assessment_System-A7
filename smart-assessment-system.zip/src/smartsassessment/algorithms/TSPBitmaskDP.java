package smartsassessment.algorithms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Travelling Salesperson Problem (TSP) using Bitmask Dynamic Programming (Held-Karp Algorithm).
 * State: DP[mask][u] = minimum cost to visit all cities in mask, ending at city u.
 * Mask represents subset of visited cities as bits: bit i is 1 if city i has been visited.
 */
public class TSPBitmaskDP {

    public static final int INF = 1000000000;

    public static class TSPResult {
        private final int minCost;
        private final List<Integer> tour;
        private final int n;
        private final int[][] dist;
        private final int totalStatesEvaluated;

        public TSPResult(int minCost, List<Integer> tour, int n, int[][] dist, int totalStatesEvaluated) {
            this.minCost = minCost;
            this.tour = tour;
            this.n = n;
            this.dist = dist;
            this.totalStatesEvaluated = totalStatesEvaluated;
        }

        public int getMinCost() { return minCost; }
        public List<Integer> getTour() { return tour; }
        public int getTotalStatesEvaluated() { return totalStatesEvaluated; }

        public void printTour() {
            System.out.println("\nOptimal TSP Tour:");
            if (minCost >= INF) {
                System.out.println("  No Hamiltonian Cycle / valid tour found.");
                return;
            }
            System.out.print("  Path: ");
            for (int i = 0; i < tour.size(); i++) {
                System.out.print("City " + tour.get(i));
                if (i < tour.size() - 1) System.out.print(" -> ");
            }
            System.out.println("\n  Total Tour Cost: " + minCost);
            System.out.println("  States evaluated (2^N * N): " + totalStatesEvaluated);
        }
    }

    /**
     * Solves TSP starting and ending at city 0.
     * Time: O(2^n * n^2), Space: O(2^n * n)
     */
    public static TSPResult solve(int[][] dist) {
        if (dist == null || dist.length == 0) {
            return new TSPResult(0, new ArrayList<>(), 0, dist, 0);
        }

        int n = dist.length;
        if (n == 1) {
            List<Integer> single = new ArrayList<>();
            single.add(0);
            single.add(0);
            return new TSPResult(0, single, 1, dist, 1);
        }

        int numStates = 1 << n;
        int[][] dp = new int[numStates][n];
        int[][] parent = new int[numStates][n];

        for (int i = 0; i < numStates; i++) {
            Arrays.fill(dp[i], INF);
            Arrays.fill(parent[i], -1);
        }

        // Base case: starting at city 0, mask = 1 (only city 0 visited)
        dp[1][0] = 0;

        int evaluatedStates = 0;

        // Iterate over all subset masks
        for (int mask = 1; mask < numStates; mask++) {
            // Must contain starting city 0
            if ((mask & 1) == 0) continue;

            for (int u = 0; u < n; u++) {
                if ((mask & (1 << u)) == 0 || dp[mask][u] >= INF) continue;
                evaluatedStates++;

                // Transition to next unvisited city v
                for (int v = 0; v < n; v++) {
                    if ((mask & (1 << v)) == 0 && dist[u][v] < INF) {
                        int nextMask = mask | (1 << v);
                        int newDist = dp[mask][u] + dist[u][v];
                        if (newDist < dp[nextMask][v]) {
                            dp[nextMask][v] = newDist;
                            parent[nextMask][v] = u;
                        }
                    }
                }
            }
        }

        // Close the tour by returning from last city u back to city 0
        int fullMask = (1 << n) - 1;
        int minCost = INF;
        int lastCity = -1;

        for (int u = 1; u < n; u++) {
            if (dp[fullMask][u] < INF && dist[u][0] < INF) {
                int total = dp[fullMask][u] + dist[u][0];
                if (total < minCost) {
                    minCost = total;
                    lastCity = u;
                }
            }
        }

        // Reconstruct tour
        List<Integer> tour = new ArrayList<>();
        if (minCost < INF) {
            int currMask = fullMask;
            int currCity = lastCity;
            tour.add(0); // return to start

            while (currCity != -1) {
                tour.add(0, currCity);
                int prev = parent[currMask][currCity];
                currMask ^= (1 << currCity);
                currCity = prev;
            }
        }

        return new TSPResult(minCost, tour, n, dist, evaluatedStates);
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Travelling Salesperson Problem (TSP) with Bitmask DP\n" +
               "Time Complexity:  O(2^n * n^2) [Subsets of cities * transitions]\n" +
               "Space Complexity: O(2^n * n) [DP table indexed by bitmask and last visited node]\n" +
               "Core Concept:     Replaces brute force O(n!) permutation search with dynamic\n" +
               "                  programming over 2^n subset states.";
    }
}
