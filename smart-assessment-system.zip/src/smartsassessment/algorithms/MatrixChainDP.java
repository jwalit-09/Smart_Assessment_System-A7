package smartsassessment.algorithms;

/**
 * Matrix Chain Multiplication using Interval Dynamic Programming.
 * Determines the optimal parenthesization of a product of n matrices to minimize scalar multiplications.
 */
public class MatrixChainDP {

    public static class MCMResult {
        private final long minMultiplications;
        private final String optimalParenthesization;
        private final long[][] mTable;
        private final int[][] sTable;
        private final int[] dimensions;

        public MCMResult(long minMultiplications, String optimalParenthesization,
                         long[][] mTable, int[][] sTable, int[] dimensions) {
            this.minMultiplications = minMultiplications;
            this.optimalParenthesization = optimalParenthesization;
            this.mTable = mTable;
            this.sTable = sTable;
            this.dimensions = dimensions;
        }

        public long getMinMultiplications() { return minMultiplications; }
        public String getOptimalParenthesization() { return optimalParenthesization; }
        public long[][] getMTable() { return mTable; }
        public int[][] getSTable() { return sTable; }

        public void printTable() {
            int n = dimensions.length - 1;
            System.out.println("\nDynamic Programming Cost Matrix m[i][j]:");
            System.out.print("     ");
            for (int j = 1; j <= n; j++) {
                System.out.printf("   M%d   ", j);
            }
            System.out.println();

            for (int i = 1; i <= n; i++) {
                System.out.printf("M%d: ", i);
                for (int j = 1; j <= n; j++) {
                    if (j < i) {
                        System.out.print("    -   ");
                    } else {
                        System.out.printf("%8d", mTable[i][j]);
                    }
                }
                System.out.println();
            }
        }
    }

    /**
     * Solves Matrix Chain Multiplication.
     * dimensions array p of length n + 1: Matrix i has dimension p[i-1] x p[i] for i = 1..n.
     */
    public static MCMResult solve(int[] p) {
        if (p == null || p.length < 2) {
            return new MCMResult(0, "", new long[0][0], new int[0][0], new int[0]);
        }

        int n = p.length - 1; // Number of matrices
        long[][] m = new long[n + 1][n + 1];
        int[][] s = new int[n + 1][n + 1];

        // Length of chain l = 2..n
        for (int l = 2; l <= n; l++) {
            for (int i = 1; i <= n - l + 1; i++) {
                int j = i + l - 1;
                m[i][j] = Long.MAX_VALUE;

                for (int k = i; k < j; k++) {
                    long cost = m[i][k] + m[k + 1][j] + (long) p[i - 1] * p[k] * p[j];
                    if (cost < m[i][j]) {
                        m[i][j] = cost;
                        s[i][j] = k;
                    }
                }
            }
        }

        String parens = buildParenthesization(s, 1, n);
        return new MCMResult(m[1][n], parens, m, s, p);
    }

    private static String buildParenthesization(int[][] s, int i, int j) {
        if (i == j) {
            return "A" + i;
        } else {
            return "(" + buildParenthesization(s, i, s[i][j]) + " x " + buildParenthesization(s, s[i][j] + 1, j) + ")";
        }
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Matrix Chain Multiplication (Interval DP)\n" +
               "Time Complexity:  O(n^3) [n matrices, O(n^2) subproblems, O(n) split iterations]\n" +
               "Space Complexity: O(n^2) [Cost matrix m and split matrix s]\n" +
               "Core Concept:     Evaluates all partition points k in subchain [i..j]:\n" +
               "                  m[i][j] = min_{i<=k<j} (m[i][k] + m[k+1][j] + p_{i-1}*p_k*p_j).";
    }
}
