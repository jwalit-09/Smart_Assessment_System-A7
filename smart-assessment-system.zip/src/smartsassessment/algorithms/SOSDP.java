package smartsassessment.algorithms;

/**
 * Sum Over Subsets Dynamic Programming (SOS DP).
 * Computes F[mask] = Σ_{submask ⊆ mask} A[submask] for all masks in O(N * 2^N) time,
 * where N is the number of bits.
 *
 * Improvement over alternatives:
 * 1. Naive subset check: O(4^N)
 * 2. Submask enumeration (sub = (sub - 1) & mask): O(3^N)
 * 3. SOS DP: O(N * 2^N) via bitwise prefix relaxation.
 */
public class SOSDP {

    public static class SOSResult {
        private final int n; // number of bits
        private final long[] original;
        private final long[] sosSum;

        public SOSResult(int n, long[] original, long[] sosSum) {
            this.n = n;
            this.original = original;
            this.sosSum = sosSum;
        }

        public int getN() { return n; }
        public long[] getOriginal() { return original; }
        public long[] getSosSum() { return sosSum; }

        public void printResults() {
            System.out.println("\nSum Over Subsets (SOS DP) Results (N = " + n + " bits, " + (1 << n) + " masks):");
            System.out.printf("  %-10s | %-12s | %-12s%n", "Mask (Bin)", "Original A", "SOS Sum F");
            System.out.println("  --------------------------------------");
            int totalMasks = 1 << n;
            for (int mask = 0; mask < totalMasks; mask++) {
                String bin = String.format("%" + n + "s", Integer.toBinaryString(mask)).replace(' ', '0');
                System.out.printf("  %-10s | %-12d | %-12d%n", bin, original[mask], sosSum[mask]);
            }
        }
    }

    /**
     * Computes SOS DP for an array of size 2^n.
     * Time: O(n * 2^n), Space: O(2^n)
     */
    public static SOSResult compute(int n, long[] a) {
        int totalMasks = 1 << n;
        long[] original = new long[totalMasks];
        long[] dp = new long[totalMasks];

        for (int i = 0; i < totalMasks; i++) {
            original[i] = (i < a.length) ? a[i] : 0;
            dp[i] = original[i];
        }

        // SOS DP bitwise state transition:
        // For each bit position i from 0 to n - 1, if bit i is ON in mask,
        // add the submask with bit i turned OFF.
        for (int i = 0; i < n; i++) {
            for (int mask = 0; mask < totalMasks; mask++) {
                if ((mask & (1 << i)) != 0) {
                    dp[mask] += dp[mask ^ (1 << i)];
                }
            }
        }

        return new SOSResult(n, original, dp);
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Sum Over Subsets Dynamic Programming (SOS DP)\n" +
               "Time Complexity:  O(n * 2^n) [n bit dimensions over 2^n masks]\n" +
               "Space Complexity: O(2^n) in-place array\n" +
               "Comparison:       - Direct submask iteration: O(3^n) ≈ 14.3 million operations for n=15\n" +
               "                  - SOS DP: O(n * 2^n) ≈ 491,520 operations for n=15 (30x faster!).";
    }
}
