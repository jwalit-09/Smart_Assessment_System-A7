package smartsassessment.algorithms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Suffix Array construction and binary search pattern matcher.
 * Constructed via the standard Prefix Doubling (Manber-Myers style) algorithm in O(n log^2 n) time.
 *
 * Conceptual SA-IS Note:
 * SA-IS (Suffix Array Induced Sorting) achieves linear O(n) construction by classifying
 * suffixes into S-type and L-type, identifying LMS (Leftmost S-type) suffixes, recursively
 * sorting LMS substrings, and inducing the full suffix order via bucket pointers.
 */
public class SuffixArray {

    private final String text;
    private final int n;
    private final int[] sa;

    public static class SuffixEntry {
        int index;
        int rankFirst;
        int rankSecond;

        public SuffixEntry(int index, int rankFirst, int rankSecond) {
            this.index = index;
            this.rankFirst = rankFirst;
            this.rankSecond = rankSecond;
        }
    }

    public SuffixArray(String text) {
        this.text = text != null ? text : "";
        this.n = this.text.length();
        this.sa = new int[n];
        if (n > 0) {
            buildSuffixArray();
        }
    }

    /**
     * Builds Suffix Array using O(n log^2 n) prefix doubling.
     */
    private void buildSuffixArray() {
        SuffixEntry[] suffixes = new SuffixEntry[n];

        // Initial ranking based on first character
        for (int i = 0; i < n; i++) {
            suffixes[i] = new SuffixEntry(i, (int) text.charAt(i), (i + 1 < n) ? (int) text.charAt(i + 1) : -1);
        }

        // Custom comparator for suffix entries
        Comparator<SuffixEntry> comp = (a, b) -> {
            if (a.rankFirst != b.rankFirst) {
                return Integer.compare(a.rankFirst, b.rankFirst);
            }
            return Integer.compare(a.rankSecond, b.rankSecond);
        };

        // Initial sort on 2 characters
        mergeSortSuffixes(suffixes, 0, n - 1, comp);

        int[] ind = new int[n]; // mapping from original suffix index to position in suffixes[]

        // Double prefix length k = 4, 8, 16 ...
        for (int k = 4; k < 2 * n; k *= 2) {
            int rank = 0;
            int prevRank = suffixes[0].rankFirst;
            suffixes[0].rankFirst = rank;
            ind[suffixes[0].index] = 0;

            for (int i = 1; i < n; i++) {
                if (suffixes[i].rankFirst == prevRank && suffixes[i].rankSecond == suffixes[i - 1].rankSecond) {
                    prevRank = suffixes[i].rankFirst;
                    suffixes[i].rankFirst = rank;
                } else {
                    prevRank = suffixes[i].rankFirst;
                    suffixes[i].rankFirst = ++rank;
                }
                ind[suffixes[i].index] = i;
            }

            // Update second ranks for length k
            for (int i = 0; i < n; i++) {
                int nextIndex = suffixes[i].index + k / 2;
                suffixes[i].rankSecond = (nextIndex < n) ? suffixes[ind[nextIndex]].rankFirst : -1;
            }

            // Re-sort with updated ranks
            mergeSortSuffixes(suffixes, 0, n - 1, comp);
        }

        for (int i = 0; i < n; i++) {
            sa[i] = suffixes[i].index;
        }
    }

    /**
     * In-place manual merge sort for SuffixEntry array to avoid library sorting dependence.
     */
    private void mergeSortSuffixes(SuffixEntry[] arr, int left, int right, Comparator<SuffixEntry> comp) {
        if (left >= right) return;
        int mid = left + (right - left) / 2;
        mergeSortSuffixes(arr, left, mid, comp);
        mergeSortSuffixes(arr, mid + 1, right, comp);
        merge(arr, left, mid, right, comp);
    }

    private void merge(SuffixEntry[] arr, int left, int mid, int right, Comparator<SuffixEntry> comp) {
        int n1 = mid - left + 1;
        int n2 = right - mid;
        SuffixEntry[] L = new SuffixEntry[n1];
        SuffixEntry[] R = new SuffixEntry[n2];

        System.arraycopy(arr, left, L, 0, n1);
        System.arraycopy(arr, mid + 1, R, 0, n2);

        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2) {
            if (comp.compare(L[i], R[j]) <= 0) {
                arr[k++] = L[i++];
            } else {
                arr[k++] = R[j++];
            }
        }
        while (i < n1) arr[k++] = L[i++];
        while (j < n2) arr[k++] = R[j++];
    }

    /**
     * Binary search pattern in text using the Suffix Array.
     * Time: O(m * log n)
     */
    public List<Integer> search(String pattern) {
        List<Integer> occurrences = new ArrayList<>();
        if (pattern == null || pattern.isEmpty() || n == 0) {
            return occurrences;
        }

        int m = pattern.length();
        int low = 0, high = n - 1;
        int start = -1;

        // Find lower bound
        while (low <= high) {
            int mid = low + (high - low) / 2;
            int suffixIndex = sa[mid];
            String suffixSub = text.substring(suffixIndex, Math.min(n, suffixIndex + m));
            int cmp = suffixSub.compareTo(pattern);

            if (cmp >= 0) {
                if (cmp == 0) start = mid;
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }

        if (start == -1) return occurrences;

        // Find upper bound
        low = start;
        high = n - 1;
        int end = start;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            int suffixIndex = sa[mid];
            String suffixSub = text.substring(suffixIndex, Math.min(n, suffixIndex + m));
            int cmp = suffixSub.compareTo(pattern);

            if (cmp <= 0) {
                if (cmp == 0) end = mid;
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        for (int i = start; i <= end; i++) {
            occurrences.add(sa[i]);
        }
        return occurrences;
    }

    public int[] getSA() { return sa; }
    public String getText() { return text; }

    public String getSuffix(int i) {
        return text.substring(sa[i]);
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Suffix Array (Prefix Doubling / Manber-Myers)\n" +
               "Time Complexity:  Construction: O(n log^2 n), Binary Search: O(m log n)\n" +
               "Space Complexity: O(n) for suffix indices and ranks\n" +
               "Linear Note:      Linear-time O(n) construction can be achieved via SA-IS\n" +
               "                  (Induced Sorting using LMS characters & bucket sorting).";
    }
}
