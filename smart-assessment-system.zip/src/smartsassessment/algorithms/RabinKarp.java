package smartsassessment.algorithms;

import java.util.ArrayList;
import java.util.List;

/**
 * Rabin-Karp String Searching Algorithm using Polynomial Rolling Hash.
 * Computes initial window hash and rolls in O(1) by subtracting outgoing character and adding incoming.
 */
public class RabinKarp {

    public static final int DEFAULT_BASE = 256;
    public static final long DEFAULT_MOD = 1000000007L;

    public static class RKResult {
        private final long patternHash;
        private final List<Long> windowHashes;
        private final List<Integer> matchPositions;
        private final int hashComparisons;
        private final int spuriousHits;

        public RKResult(long patternHash, List<Long> windowHashes, List<Integer> matchPositions,
                        int hashComparisons, int spuriousHits) {
            this.patternHash = patternHash;
            this.windowHashes = windowHashes;
            this.matchPositions = matchPositions;
            this.hashComparisons = hashComparisons;
            this.spuriousHits = spuriousHits;
        }

        public long getPatternHash() { return patternHash; }
        public List<Long> getWindowHashes() { return windowHashes; }
        public List<Integer> getMatchPositions() { return matchPositions; }
        public int getHashComparisons() { return hashComparisons; }
        public int getSpuriousHits() { return spuriousHits; }
        public boolean isFound() { return !matchPositions.isEmpty(); }
    }

    /**
     * Executes Rabin-Karp pattern search.
     */
    public static RKResult search(String text, String pattern) {
        return search(text, pattern, DEFAULT_BASE, DEFAULT_MOD);
    }

    public static RKResult search(String text, String pattern, int base, long mod) {
        List<Integer> matches = new ArrayList<>();
        List<Long> windowHashes = new ArrayList<>();
        int hashComparisons = 0;
        int spuriousHits = 0;

        if (text == null || pattern == null || pattern.isEmpty() || text.length() < pattern.length()) {
            return new RKResult(0, windowHashes, matches, 0, 0);
        }

        int n = text.length();
        int m = pattern.length();

        // Calculate h = base^(m-1) % mod
        long h = 1;
        for (int i = 0; i < m - 1; i++) {
            h = (h * base) % mod;
        }

        long patternHash = 0;
        long windowHash = 0;

        // Compute initial hash of pattern and first window of text
        for (int i = 0; i < m; i++) {
            patternHash = (base * patternHash + pattern.charAt(i)) % mod;
            windowHash = (base * windowHash + text.charAt(i)) % mod;
        }
        windowHashes.add(windowHash);

        // Slide the pattern over text
        for (int i = 0; i <= n - m; i++) {
            hashComparisons++;
            if (patternHash == windowHash) {
                // Potential match: verify character-by-character to eliminate collisions
                boolean match = true;
                for (int j = 0; j < m; j++) {
                    if (text.charAt(i + j) != pattern.charAt(j)) {
                        match = false;
                        break;
                    }
                }
                if (match) {
                    matches.add(i);
                } else {
                    spuriousHits++;
                }
            }

            // Calculate hash value for next window
            if (i < n - m) {
                windowHash = (base * (windowHash - text.charAt(i) * h) + text.charAt(i + m)) % mod;
                if (windowHash < 0) {
                    windowHash += mod;
                }
                windowHashes.add(windowHash);
            }
        }

        return new RKResult(patternHash, windowHashes, matches, hashComparisons, spuriousHits);
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Rabin-Karp String Matching\n" +
               "Time Complexity:  Average / Best: O(n + m), Worst: O(n * m) [in case of hash collisions]\n" +
               "Space Complexity: O(1) auxiliary space\n" +
               "Core Concept:     Uses polynomial rolling hash (base 256, prime mod 10^9+7)\n" +
               "                  to update text window hashes in O(1) time before verifying character equality.";
    }
}
