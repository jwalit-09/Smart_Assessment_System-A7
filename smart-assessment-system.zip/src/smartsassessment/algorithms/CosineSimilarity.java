package smartsassessment.algorithms;

/**
 * Cosine Similarity computation between two numerical vectors.
 * Implemented manually without numerical or linear algebra libraries.
 *
 * Formula:
 * cosine(A, B) = (A · B) / (||A|| * ||B||)
 */
public class CosineSimilarity {

    /**
     * Calculates cosine similarity between two double vectors.
     * Returns a normalized value in range [0.0, 1.0] for non-negative TF-IDF vectors.
     */
    public static double compute(double[] a, double[] b) {
        if (a == null || b == null || a.length == 0 || b.length == 0) {
            return 0.0;
        }

        int len = Math.min(a.length, b.length);
        double dotProduct = 0.0;
        double normA = 0.0;
        double normB = 0.0;

        for (int i = 0; i < len; i++) {
            dotProduct += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }

        // Account for remaining elements if lengths differ
        for (int i = len; i < a.length; i++) {
            normA += a[i] * a[i];
        }
        for (int i = len; i < b.length; i++) {
            normB += b[i] * b[i];
        }

        if (normA <= 1e-12 || normB <= 1e-12) {
            return 0.0; // Avoid division by zero on empty or zero vectors
        }

        double similarity = dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
        // Clamp to [0, 1] to avoid float precision anomalies
        return Math.max(0.0, Math.min(1.0, similarity));
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Cosine Similarity\n" +
               "Time Complexity:  O(V) where V is vector dimensionality\n" +
               "Space Complexity: O(1) auxiliary space\n" +
               "Core Concept:     Measures the cosine of the angle between two multi-dimensional\n" +
               "                  vectors, invariant to document length.";
    }
}
