package smartsassessment.algorithms;

import java.util.HashMap;
import java.util.Map;

/**
 * Damerau-Levenshtein Distance Algorithm (Restricted / Optimal String Alignment & True Damerau).
 * Accounts for:
 * 1. Insertions
 * 2. Deletions
 * 3. Substitutions
 * 4. Transpositions of two adjacent characters (e.g. "CA" -> "AC" costs 1).
 */
public class DamerauLevenshtein {

    public static class DLResult {
        private final int distance;
        private final String a;
        private final String b;
        private final int[][] dp;

        public DLResult(int distance, String a, String b, int[][] dp) {
            this.distance = distance;
            this.a = a;
            this.b = b;
            this.dp = dp;
        }

        public int getDistance() { return distance; }
        public String getA() { return a; }
        public String getB() { return b; }
        public int[][] getDp() { return dp; }

        public void printTable() {
            System.out.println("\nDamerau-Levenshtein DP Matrix:");
            int n = a.length();
            int m = b.length();
            System.out.print("      ε  ");
            for (int j = 0; j < m; j++) {
                System.out.printf("  %c", b.charAt(j));
            }
            System.out.println();

            for (int i = 0; i <= n; i++) {
                if (i == 0) System.out.print("  ε ");
                else System.out.printf("  %c ", a.charAt(i - 1));
                for (int j = 0; j <= m; j++) {
                    System.out.printf("%3d", dp[i][j]);
                }
                System.out.println();
            }
        }
    }

    /**
     * Calculates the Damerau-Levenshtein distance (Optimal String Alignment distance).
     * Time: O(n * m), Space: O(n * m)
     */
    public static DLResult calculate(String a, String b) {
        if (a == null) a = "";
        if (b == null) b = "";

        int n = a.length();
        int m = b.length();
        int[][] dp = new int[n + 1][m + 1];

        for (int i = 0; i <= n; i++) dp[i][0] = i;
        for (int j = 0; j <= m; j++) dp[0][j] = j;

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                int cost = (a.charAt(i - 1) == b.charAt(j - 1)) ? 0 : 1;
                // Standard Wagner-Fischer operations
                dp[i][j] = Math.min(
                        dp[i - 1][j] + 1,                     // deletion
                        Math.min(dp[i][j - 1] + 1,             // insertion
                                 dp[i - 1][j - 1] + cost)     // substitution
                );

                // Adjacent transposition check
                if (i > 1 && j > 1 &&
                    a.charAt(i - 1) == b.charAt(j - 2) &&
                    a.charAt(i - 2) == b.charAt(j - 1)) {
                    dp[i][j] = Math.min(dp[i][j], dp[i - 2][j - 2] + 1);
                }
            }
        }

        return new DLResult(dp[n][m], a, b, dp);
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Damerau-Levenshtein Distance\n" +
               "Time Complexity:  O(n * m)\n" +
               "Space Complexity: O(n * m)\n" +
               "Operations:       Insertion, Deletion, Substitution, and Adjacent Transposition (cost 1).\n" +
               "Example:          'CA' -> 'AC' distance = 1 (Standard Levenshtein requires 2 operations).";
    }
}
