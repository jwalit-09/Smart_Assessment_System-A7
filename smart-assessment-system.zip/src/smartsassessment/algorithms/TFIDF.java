package smartsassessment.algorithms;

import java.util.*;

/**
 * Manual implementation of Term Frequency - Inverse Document Frequency (TF-IDF).
 * Implemented without external ML libraries.
 *
 * Formulas:
 * TF(t, d) = count(t, d) / totalTerms(d)
 * IDF(t)   = log(N / DF(t)) + 1 (smoothed to prevent division by zero and negative logs)
 * TF-IDF(t, d) = TF(t, d) * IDF(t)
 */
public class TFIDF {

    private final List<String> vocabulary;
    private final Map<String, Integer> vocabIndex;
    private final Map<String, Double> idfMap;
    private final int totalDocuments;

    public TFIDF(List<String> documents) {
        this.totalDocuments = Math.max(1, documents.size());
        this.vocabulary = new ArrayList<>();
        this.vocabIndex = new HashMap<>();
        this.idfMap = new HashMap<>();

        buildModel(documents);
    }

    private void buildModel(List<String> documents) {
        Map<String, Integer> docFrequency = new HashMap<>();

        for (String doc : documents) {
            List<String> tokens = tokenize(doc);
            Set<String> uniqueTokens = new HashSet<>(tokens);
            for (String token : uniqueTokens) {
                docFrequency.put(token, docFrequency.getOrDefault(token, 0) + 1);
            }
        }

        // Build sorted vocabulary for deterministic index mapping
        List<String> sortedTerms = new ArrayList<>(docFrequency.keySet());
        Collections.sort(sortedTerms);

        for (int i = 0; i < sortedTerms.size(); i++) {
            String term = sortedTerms.get(i);
            vocabulary.add(term);
            vocabIndex.put(term, i);
            int df = docFrequency.get(term);
            // IDF formula with smooth log: ln((N + 1) / (df + 1)) + 1
            double idf = Math.log((double) (totalDocuments + 1) / (df + 1)) + 1.0;
            idfMap.put(term, idf);
        }
    }

    /**
     * Splits text into lowercase alphanumeric tokens, stripping punctuation.
     */
    public static List<String> tokenize(String text) {
        List<String> tokens = new ArrayList<>();
        if (text == null) return tokens;

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                sb.append(Character.toLowerCase(c));
            } else {
                if (sb.length() > 0) {
                    tokens.add(sb.toString());
                    sb.setLength(0);
                }
            }
        }
        if (sb.length() > 0) {
            tokens.add(sb.toString());
        }
        return tokens;
    }

    /**
     * Computes raw Term Frequency: count(t, d) / totalTerms(d)
     */
    public static Map<String, Double> computeTF(List<String> tokens) {
        Map<String, Double> tf = new HashMap<>();
        if (tokens == null || tokens.isEmpty()) return tf;

        int totalTerms = tokens.size();
        for (String t : tokens) {
            tf.put(t, tf.getOrDefault(t, 0.0) + 1.0);
        }
        for (Map.Entry<String, Double> entry : tf.entrySet()) {
            entry.setValue(entry.getValue() / totalTerms);
        }
        return tf;
    }

    /**
     * Converts a document string into a TF-IDF vector corresponding to the model vocabulary.
     */
    public double[] transform(String document) {
        double[] vector = new double[vocabulary.size()];
        List<String> tokens = tokenize(document);
        if (tokens.isEmpty() || vocabulary.isEmpty()) {
            return vector;
        }

        Map<String, Double> tf = computeTF(tokens);

        for (Map.Entry<String, Double> entry : tf.entrySet()) {
            String term = entry.getKey();
            Integer idx = vocabIndex.get(term);
            if (idx != null) {
                double termTf = entry.getValue();
                double termIdf = idfMap.getOrDefault(term, 1.0);
                vector[idx] = termTf * termIdf;
            }
        }
        return vector;
    }

    public List<String> getVocabulary() { return vocabulary; }
    public Map<String, Double> getIdfMap() { return idfMap; }

    public static String getComplexityInfo() {
        return "Algorithm:        TF-IDF (Term Frequency - Inverse Document Frequency)\n" +
               "Time Complexity:  Vocabulary Building: O(D * L) where D = num documents, L = average length\n" +
               "                  Vector Transform:    O(L + V) where V = vocabulary size\n" +
               "Space Complexity: O(V) per document vector\n" +
               "Core Concept:     Weights words proportionally to frequency within document\n" +
               "                  and inversely proportional to occurrence across corpus.";
    }
}
