package smartsassessment.algorithms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Hamiltonian Path determination in an undirected/directed graph.
 * Uses Bitmask Dynamic Programming: DP[mask][u] = true if there exists a valid path
 * visiting the subset of vertices in mask and ending at vertex u.
 */
public class HamiltonianPath {

    public static class HPResult {
        private final boolean exists;
        private final List<Integer> path;
        private final int numVertices;

        public HPResult(boolean exists, List<Integer> path, int numVertices) {
            this.exists = exists;
            this.path = path;
            this.numVertices = numVertices;
        }

        public boolean exists() { return exists; }
        public List<Integer> getPath() { return path; }
        public int getNumVertices() { return numVertices; }

        public void printResult() {
            if (exists) {
                System.out.println("\nHamiltonian Path Found!");
                System.out.print("  Path: ");
                for (int i = 0; i < path.size(); i++) {
                    System.out.print(path.get(i));
                    if (i < path.size() - 1) System.out.print(" -> ");
                }
                System.out.println();
            } else {
                System.out.println("\nNo Hamiltonian Path exists in this graph.");
            }
        }
    }

    /**
     * Finds a Hamiltonian Path in an adjacency matrix graph.
     * Time: O(2^n * n^2), Space: O(2^n * n)
     */
    public static HPResult findPath(int n, boolean[][] adj) {
        if (n <= 0) return new HPResult(false, new ArrayList<>(), 0);
        if (n == 1) {
            List<Integer> p = new ArrayList<>();
            p.add(0);
            return new HPResult(true, p, 1);
        }

        int numStates = 1 << n;
        boolean[][] dp = new boolean[numStates][n];
        int[][] parent = new int[numStates][n];

        for (int i = 0; i < numStates; i++) {
            Arrays.fill(parent[i], -1);
        }

        // Base cases: single vertex paths
        for (int i = 0; i < n; i++) {
            dp[1 << i][i] = true;
        }

        // Fill DP table
        for (int mask = 1; mask < numStates; mask++) {
            for (int u = 0; u < n; u++) {
                if (!dp[mask][u]) continue;

                for (int v = 0; v < n; v++) {
                    if ((mask & (1 << v)) == 0 && adj[u][v]) {
                        int nextMask = mask | (1 << v);
                        dp[nextMask][v] = true;
                        parent[nextMask][v] = u;
                    }
                }
            }
        }

        int fullMask = (1 << n) - 1;
        int endVertex = -1;
        for (int u = 0; u < n; u++) {
            if (dp[fullMask][u]) {
                endVertex = u;
                break;
            }
        }

        if (endVertex == -1) {
            return new HPResult(false, new ArrayList<>(), n);
        }

        // Reconstruct path
        List<Integer> path = new ArrayList<>();
        int currMask = fullMask;
        int currVertex = endVertex;

        while (currVertex != -1) {
            path.add(0, currVertex);
            int prev = parent[currMask][currVertex];
            currMask ^= (1 << currVertex);
            currVertex = prev;
        }

        return new HPResult(true, path, n);
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Hamiltonian Path (Bitmask DP)\n" +
               "Time Complexity:  O(2^n * n^2) [vs O(n!) brute-force backtracking]\n" +
               "Space Complexity: O(2^n * n)\n" +
               "Core Concept:     A path visiting every vertex in the graph exactly once.\n" +
               "                  State dp[mask][u] tracks whether mask subset can be traversed ending at u.";
    }
}
