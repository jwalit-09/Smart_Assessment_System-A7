package smartsassessment.algorithms;

import java.util.ArrayList;
import java.util.List;

/**
 * Wagner-Fischer Dynamic Programming Algorithm for Levenshtein Distance.
 * Computes minimum insertions, deletions, and substitutions to transform string A into string B.
 */
public class EditDistance {

    public static class Result {
        private final int distance;
        private final int insertions;
        private final int deletions;
        private final int substitutions;
        private final int[][] dpTable;
        private final String strA;
        private final String strB;
        private final List<String> operations;

        public Result(int distance, int insertions, int deletions, int substitutions,
                      int[][] dpTable, String strA, String strB, List<String> operations) {
            this.distance = distance;
            this.insertions = insertions;
            this.deletions = deletions;
            this.substitutions = substitutions;
            this.dpTable = dpTable;
            this.strA = strA;
            this.strB = strB;
            this.operations = operations;
        }

        public int getDistance() { return distance; }
        public int getInsertions() { return insertions; }
        public int getDeletions() { return deletions; }
        public int getSubstitutions() { return substitutions; }
        public int[][] getDpTable() { return dpTable; }
        public List<String> getOperations() { return operations; }

        public void printDPTable() {
            System.out.println("\nDynamic Programming Matrix (Wagner-Fischer):");
            int n = strA.length();
            int m = strB.length();

            System.out.print("      ε  ");
            for (int j = 0; j < m; j++) {
                System.out.printf("  %c", strB.charAt(j));
            }
            System.out.println();

            for (int i = 0; i <= n; i++) {
                if (i == 0) {
                    System.out.print("  ε ");
                } else {
                    System.out.printf("  %c ", strA.charAt(i - 1));
                }
                for (int j = 0; j <= m; j++) {
                    System.out.printf("%3d", dpTable[i][j]);
                }
                System.out.println();
            }
        }
    }

    public static Result calculate(String a, String b) {
        if (a == null) a = "";
        if (b == null) b = "";

        int n = a.length();
        int m = b.length();
        int[][] dp = new int[n + 1][m + 1];

        for (int i = 0; i <= n; i++) dp[i][0] = i;
        for (int j = 0; j <= m; j++) dp[0][j] = j;

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    int del = dp[i - 1][j] + 1;
                    int ins = dp[i][j - 1] + 1;
                    int sub = dp[i - 1][j - 1] + 1;
                    dp[i][j] = Math.min(del, Math.min(ins, sub));
                }
            }
        }

        // Traceback operations
        int i = n, j = m;
        int insCount = 0, delCount = 0, subCount = 0;
        List<String> ops = new ArrayList<>();

        while (i > 0 || j > 0) {
            if (i > 0 && j > 0 && a.charAt(i - 1) == b.charAt(j - 1)) {
                ops.add(0, "Keep '" + a.charAt(i - 1) + "'");
                i--;
                j--;
            } else if (i > 0 && j > 0 && dp[i][j] == dp[i - 1][j - 1] + 1) {
                ops.add(0, "Substitute '" + a.charAt(i - 1) + "' with '" + b.charAt(j - 1) + "'");
                subCount++;
                i--;
                j--;
            } else if (i > 0 && dp[i][j] == dp[i - 1][j] + 1) {
                ops.add(0, "Delete '" + a.charAt(i - 1) + "'");
                delCount++;
                i--;
            } else {
                ops.add(0, "Insert '" + b.charAt(j - 1) + "'");
                insCount++;
                j--;
            }
        }

        return new Result(dp[n][m], insCount, delCount, subCount, dp, a, b, ops);
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Wagner-Fischer Levenshtein Edit Distance\n" +
               "Time Complexity:  O(n * m)\n" +
               "Space Complexity: O(n * m) [Full Matrix for Traceback]\n" +
               "Core Concept:     Dynamic programming recurrence:\n" +
               "                  dp[i][j] = dp[i-1][j-1] if match else 1 + min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]).";
    }
}
