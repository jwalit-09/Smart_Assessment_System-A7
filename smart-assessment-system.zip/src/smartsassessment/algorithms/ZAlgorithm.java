package smartsassessment.algorithms;

import java.util.ArrayList;
import java.util.List;

/**
 * Linear-time Z-Algorithm for exact pattern matching and substring analysis.
 * Computes Z[i]: length of the longest substring starting from s[i] that is also a prefix of s.
 */
public class ZAlgorithm {

    public static class ZResult {
        private final String combinedString;
        private final int[] zArray;
        private final List<Integer> matchPositions;

        public ZResult(String combinedString, int[] zArray, List<Integer> matchPositions) {
            this.combinedString = combinedString;
            this.zArray = zArray;
            this.matchPositions = matchPositions;
        }

        public String getCombinedString() { return combinedString; }
        public int[] getZArray() { return zArray; }
        public List<Integer> getMatchPositions() { return matchPositions; }
    }

    /**
     * Computes the Z-array for string s in O(n) time using [L, R] window intervals.
     */
    public static int[] computeZArray(String s) {
        int n = s.length();
        int[] z = new int[n];
        if (n == 0) return z;
        z[0] = n;

        int l = 0, r = 0;
        for (int i = 1; i < n; i++) {
            if (i <= r) {
                z[i] = Math.min(r - i + 1, z[i - l]);
            }
            while (i + z[i] < n && s.charAt(z[i]) == s.charAt(i + z[i])) {
                z[i]++;
            }
            if (i + z[i] - 1 > r) {
                l = i;
                r = i + z[i] - 1;
            }
        }
        return z;
    }

    /**
     * Searches for pattern in text using the Z-algorithm with delimiter '$'.
     * Time: O(n + m), Space: O(n + m)
     */
    public static ZResult search(String text, String pattern) {
        List<Integer> matches = new ArrayList<>();
        if (text == null || pattern == null || pattern.isEmpty() || text.length() < pattern.length()) {
            return new ZResult("", new int[0], matches);
        }

        String combined = pattern + "$" + text;
        int[] z = computeZArray(combined);
        int m = pattern.length();

        for (int i = m + 1; i < combined.length(); i++) {
            if (z[i] == m) {
                matches.add(i - (m + 1));
            }
        }

        return new ZResult(combined, z, matches);
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Z-Algorithm\n" +
               "Time Complexity:  O(n + m) [Linear time using [L, R] matching segment]\n" +
               "Space Complexity: O(n + m) [Z-array storage]\n" +
               "Core Concept:     Maintains a segment [L, R] that is the prefix of the string\n" +
               "                  with the highest R reached so far, achieving strict O(n) runtime.";
    }
}
