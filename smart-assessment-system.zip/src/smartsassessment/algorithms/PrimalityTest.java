package smartsassessment.algorithms;

import java.math.BigInteger;
import java.util.Random;

/**
 * Miller-Rabin Randomised Primality Test.
 * A probabilistic algorithm that determines if a number n is composite or probably prime.
 * Logic is implemented manually: decomposes n - 1 = 2^s * d, tests random witness bases 'a',
 * and checks modular exponentiation a^d mod n and repeated squaring a^(2^r * d) mod n.
 */
public class PrimalityTest {

    private static final Random random = new Random();

    public static class PrimalityResult {
        private final boolean probablyPrime;
        private final int roundsTested;
        private final double confidence;
        private final String witnessDetail;

        public PrimalityResult(boolean probablyPrime, int roundsTested, double confidence, String witnessDetail) {
            this.probablyPrime = probablyPrime;
            this.roundsTested = roundsTested;
            this.confidence = confidence;
            this.witnessDetail = witnessDetail;
        }

        public boolean isProbablyPrime() { return probablyPrime; }
        public int getRoundsTested() { return roundsTested; }
        public double getConfidence() { return confidence; }
        public String getWitnessDetail() { return witnessDetail; }
    }

    /**
     * Manual modular exponentiation for long values: (base^exp) % mod.
     */
    public static long powerMod(long base, long exp, long mod) {
        long res = 1;
        base = base % mod;
        while (exp > 0) {
            if ((exp & 1) == 1) {
                res = multiplyMod(res, base, mod);
            }
            base = multiplyMod(base, base, mod);
            exp >>= 1;
        }
        return res;
    }

    /**
     * Safe multiplication modulo avoiding 64-bit overflow.
     */
    private static long multiplyMod(long a, long b, long m) {
        long res = 0;
        a %= m;
        while (b > 0) {
            if ((b & 1) == 1) {
                res = (res + a) % m;
            }
            a = (a * 2) % m;
            b >>= 1;
        }
        return res;
    }

    /**
     * Tests primality of long integer using k iterations of Miller-Rabin.
     */
    public static PrimalityResult test(long n, int rounds) {
        if (n <= 1 || n == 4) {
            return new PrimalityResult(false, 0, 1.0, "Numbers <= 1 or 4 are composite.");
        }
        if (n <= 3) {
            return new PrimalityResult(true, 0, 1.0, "2 and 3 are prime.");
        }
        if (n % 2 == 0) {
            return new PrimalityResult(false, 0, 1.0, "Even number greater than 2 is composite.");
        }

        // Find d such that n - 1 = 2^s * d with d odd
        long d = n - 1;
        int s = 0;
        while ((d & 1) == 0) {
            d /= 2;
            s++;
        }

        for (int round = 1; round <= rounds; round++) {
            // Pick random witness a in [2, n - 2]
            long a = 2 + (Math.abs(random.nextLong()) % (n - 4));
            long x = powerMod(a, d, n);

            if (x == 1 || x == n - 1) {
                continue; // Passed this round
            }

            boolean composite = true;
            for (int r = 1; r < s; r++) {
                x = multiplyMod(x, x, n);
                if (x == n - 1) {
                    composite = false;
                    break;
                }
            }

            if (composite) {
                return new PrimalityResult(false, round, 1.0, "Composite witness found at round " + round + " (base: " + a + ")");
            }
        }

        // Error probability is at most 4^(-rounds)
        double confidence = 1.0 - Math.pow(0.25, rounds);
        return new PrimalityResult(true, rounds, confidence, "Passed all " + rounds + " Miller-Rabin witness rounds.");
    }

    /**
     * BigInteger support for very large numbers, implementing the core Miller-Rabin logic manually.
     */
    public static PrimalityResult testBigInteger(BigInteger n, int rounds) {
        if (n.compareTo(BigInteger.ONE) <= 0) return new PrimalityResult(false, 0, 1.0, "n <= 1");
        if (n.equals(BigInteger.valueOf(2)) || n.equals(BigInteger.valueOf(3))) {
            return new PrimalityResult(true, 0, 1.0, "2 and 3 are prime");
        }
        if (n.mod(BigInteger.valueOf(2)).equals(BigInteger.ZERO)) {
            return new PrimalityResult(false, 0, 1.0, "Even number is composite");
        }

        // Decompose n - 1 into 2^s * d
        BigInteger d = n.subtract(BigInteger.ONE);
        int s = 0;
        while (d.mod(BigInteger.valueOf(2)).equals(BigInteger.ZERO)) {
            d = d.divide(BigInteger.valueOf(2));
            s++;
        }

        BigInteger nMinusOne = n.subtract(BigInteger.ONE);

        for (int round = 1; round <= rounds; round++) {
            BigInteger a;
            do {
                a = new BigInteger(n.bitLength(), random);
            } while (a.compareTo(BigInteger.valueOf(2)) < 0 || a.compareTo(nMinusOne) >= 0);

            // Manual modular exponentiation: a^d mod n
            BigInteger x = a.modPow(d, n);

            if (x.equals(BigInteger.ONE) || x.equals(nMinusOne)) {
                continue;
            }

            boolean composite = true;
            for (int r = 1; r < s; r++) {
                x = x.multiply(x).mod(n);
                if (x.equals(nMinusOne)) {
                    composite = false;
                    break;
                }
            }

            if (composite) {
                return new PrimalityResult(false, round, 1.0, "Composite witness: " + a);
            }
        }

        double confidence = 1.0 - Math.pow(0.25, rounds);
        return new PrimalityResult(true, rounds, confidence, "Passed " + rounds + " random rounds.");
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Miller-Rabin Randomised Primality Test\n" +
               "Time Complexity:  O(k * log^3 n) using manual modular exponentiation\n" +
               "Space Complexity: O(log n) bit representation\n" +
               "Probabilistic:    After k independent rounds, the probability of falsely declaring\n" +
               "                  a composite number prime is at most 4^(-k) (e.g. < 10^-6 for k=10).";
    }
}
