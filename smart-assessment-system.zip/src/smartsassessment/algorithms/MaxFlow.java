package smartsassessment.algorithms;

import java.util.*;

/**
 * Edmonds-Karp Algorithm for Maximum Network Flow.
 * Implements Ford-Fulkerson using Breadth-First Search (BFS) for shortest augmenting paths.
 * Time Complexity: O(V * E^2).
 */
public class MaxFlow {

    public static class FlowEdge {
        private final int u;
        private final int v;
        private final int capacity;
        private int flow;

        public FlowEdge(int u, int v, int capacity) {
            this.u = u;
            this.v = v;
            this.capacity = capacity;
            this.flow = 0;
        }

        public int getU() { return u; }
        public int getV() { return v; }
        public int getCapacity() { return capacity; }
        public int getFlow() { return flow; }
        public void setFlow(int flow) { this.flow = flow; }
    }

    public static class MaxFlowResult {
        private final int maxFlow;
        private final List<String> augmentingPaths;
        private final List<FlowEdge> edges;
        private final int source;
        private final int sink;

        public MaxFlowResult(int maxFlow, List<String> augmentingPaths, List<FlowEdge> edges, int source, int sink) {
            this.maxFlow = maxFlow;
            this.augmentingPaths = augmentingPaths;
            this.edges = edges;
            this.source = source;
            this.sink = sink;
        }

        public int getMaxFlow() { return maxFlow; }
        public List<String> getAugmentingPaths() { return augmentingPaths; }
        public List<FlowEdge> getEdges() { return edges; }

        public void printSummary() {
            System.out.println("\nMaximum Flow Result (Edmonds-Karp):");
            System.out.println("  Source Node: " + source + ", Sink Node: " + sink);
            System.out.println("  Total Max Flow: " + maxFlow);
            System.out.println("\nAugmenting Paths Discovered:");
            if (augmentingPaths.isEmpty()) {
                System.out.println("  (None / No flow path exists)");
            } else {
                for (int i = 0; i < augmentingPaths.size(); i++) {
                    System.out.println("  " + (i + 1) + ". " + augmentingPaths.get(i));
                }
            }
            System.out.println("\nFlow per Directed Edge:");
            for (FlowEdge e : edges) {
                System.out.printf("  Node %d -> Node %d | Flow: %d / Capacity: %d%n",
                        e.getU(), e.getV(), e.getFlow(), e.getCapacity());
            }
        }
    }

    /**
     * Solves Maximum Flow using Edmonds-Karp BFS on residual graph.
     */
    public static MaxFlowResult computeMaxFlow(int numVertices, List<FlowEdge> originalEdges, int source, int sink) {
        int[][] capacity = new int[numVertices][numVertices];
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i < numVertices; i++) {
            adj.add(new ArrayList<>());
        }

        for (FlowEdge edge : originalEdges) {
            int u = edge.getU();
            int v = edge.getV();
            capacity[u][v] += edge.getCapacity();
            if (!adj.get(u).contains(v)) adj.get(u).add(v);
            if (!adj.get(v).contains(u)) adj.get(v).add(u); // reverse residual edge
        }

        int maxFlow = 0;
        List<String> pathLogs = new ArrayList<>();
        int[] parent = new int[numVertices];

        while (bfsFindPath(numVertices, capacity, adj, source, sink, parent)) {
            // Find bottleneck capacity along discovered path
            int push = Integer.MAX_VALUE;
            int curr = sink;
            StringBuilder pathStr = new StringBuilder();
            List<Integer> nodesOnPath = new ArrayList<>();

            while (curr != source) {
                nodesOnPath.add(0, curr);
                int p = parent[curr];
                push = Math.min(push, capacity[p][curr]);
                curr = p;
            }
            nodesOnPath.add(0, source);

            for (int i = 0; i < nodesOnPath.size(); i++) {
                pathStr.append(nodesOnPath.get(i));
                if (i < nodesOnPath.size() - 1) pathStr.append(" -> ");
            }
            pathStr.append(" [Bottleneck: ").append(push).append("]");
            pathLogs.add(pathStr.toString());

            // Augment flow and update residual capacities
            curr = sink;
            while (curr != source) {
                int p = parent[curr];
                capacity[p][curr] -= push;
                capacity[curr][p] += push;
                curr = p;
            }

            maxFlow += push;
        }

        // Compute edge flows
        for (FlowEdge edge : originalEdges) {
            int u = edge.getU();
            int v = edge.getV();
            // Original capacity minus remaining residual forward capacity
            int flow = edge.getCapacity() - Math.max(0, capacity[u][v]);
            edge.setFlow(Math.max(0, flow));
        }

        return new MaxFlowResult(maxFlow, pathLogs, originalEdges, source, sink);
    }

    private static boolean bfsFindPath(int n, int[][] capacity, List<List<Integer>> adj,
                                       int s, int t, int[] parent) {
        Arrays.fill(parent, -1);
        parent[s] = s;
        Queue<Integer> queue = new LinkedList<>();
        queue.add(s);

        while (!queue.isEmpty()) {
            int u = queue.poll();
            if (u == t) return true;

            for (int v : adj.get(u)) {
                if (parent[v] == -1 && capacity[u][v] > 0) {
                    parent[v] = u;
                    queue.add(v);
                }
            }
        }
        return parent[t] != -1;
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Edmonds-Karp Maximum Flow (BFS Ford-Fulkerson)\n" +
               "Time Complexity:  O(V * E^2) [Guaranteed polynomial time via shortest augmenting paths]\n" +
               "Space Complexity: O(V^2) or O(V + E) for residual capacity tracking\n" +
               "Core Concept:     Repeatedly finds augmenting paths with positive residual capacity\n" +
               "                  via BFS until the min-cut capacity is reached.";
    }
}
