package smartsassessment.algorithms;

/**
 * Kasai's Algorithm for Longest Common Prefix (LCP) Array construction in O(n) time.
 * Computes the length of the longest common prefix between consecutive lexicographical suffixes.
 */
public class LCPKasai {

    public static class LCPResult {
        private final String text;
        private final int[] sa;
        private final int[] lcp;

        public LCPResult(String text, int[] sa, int[] lcp) {
            this.text = text;
            this.sa = sa;
            this.lcp = lcp;
        }

        public String getText() { return text; }
        public int[] getSa() { return sa; }
        public int[] getLcp() { return lcp; }

        public void printTable() {
            System.out.println("\nSuffix Array and LCP Table (Kasai's Algorithm):");
            System.out.printf("%-5s | %-5s | %-5s | %s%n", "Rank", "SA", "LCP", "Suffix");
            System.out.println("--------------------------------------------------");
            int n = sa.length;
            for (int i = 0; i < n; i++) {
                String sfx = text.substring(sa[i]);
                if (sfx.length() > 40) sfx = sfx.substring(0, 37) + "...";
                System.out.printf("%-5d | %-5d | %-5d | %s%n", i, sa[i], lcp[i], sfx);
            }
        }
    }

    /**
     * Builds the LCP array using Kasai's linear-time algorithm.
     * Time: O(n), Space: O(n)
     */
    public static int[] buildLCP(String text, int[] sa) {
        int n = text.length();
        if (n == 0 || sa == null || sa.length == 0) return new int[0];

        int[] rank = new int[n];
        for (int i = 0; i < n; i++) {
            rank[sa[i]] = i;
        }

        int[] lcp = new int[n];
        int h = 0; // length of previous common prefix

        for (int i = 0; i < n; i++) {
            if (rank[i] > 0) {
                int prevSuffixIndex = sa[rank[i] - 1];
                while (i + h < n && prevSuffixIndex + h < n &&
                        text.charAt(i + h) == text.charAt(prevSuffixIndex + h)) {
                    h++;
                }
                lcp[rank[i]] = h;
                if (h > 0) {
                    h--; // h decreases by at most 1 in the next step
                }
            } else {
                lcp[0] = 0;
            }
        }

        return lcp;
    }

    public static LCPResult compute(String text) {
        SuffixArray suffixArray = new SuffixArray(text);
        int[] sa = suffixArray.getSA();
        int[] lcp = buildLCP(text, sa);
        return new LCPResult(text, sa, lcp);
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Kasai's LCP Array Construction\n" +
               "Time Complexity:  O(n) [Linear time because h decreases by at most 1 per step]\n" +
               "Space Complexity: O(n) for inverse rank and LCP arrays\n" +
               "Core Concept:     LCP between suffixes starting at i and its predecessor in SA\n" +
               "                  satisfies LCP[rank[i]] >= LCP[rank[i-1]] - 1.";
    }
}
