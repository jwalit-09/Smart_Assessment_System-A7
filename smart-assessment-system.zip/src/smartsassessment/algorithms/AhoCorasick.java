package smartsassessment.algorithms;

import java.util.*;

/**
 * Aho-Corasick Multi-Pattern String Matching Automaton.
 * Constructs a trie with BFS-computed failure links and dictionary output links.
 * Locates all occurrences of multiple patterns in text in O(n + sum(m) + z) time.
 */
public class AhoCorasick {

    public static class Node {
        Map<Character, Node> children = new HashMap<>();
        Node fail = null;
        List<String> output = new ArrayList<>();
    }

    public static class Match {
        private final int position;
        private final String pattern;

        public Match(int position, String pattern) {
            this.position = position;
            this.pattern = pattern;
        }

        public int getPosition() { return position; }
        public String getPattern() { return pattern; }

        @Override
        public String toString() {
            return "'" + pattern + "' at index " + position;
        }
    }

    private final Node root;
    private final List<String> patterns;

    public AhoCorasick(List<String> patterns) {
        this.root = new Node();
        this.patterns = patterns != null ? patterns : new ArrayList<>();
        buildTrie();
        buildFailureLinks();
    }

    private void buildTrie() {
        for (String pat : patterns) {
            if (pat == null || pat.isEmpty()) continue;
            Node curr = root;
            for (int i = 0; i < pat.length(); i++) {
                char c = pat.charAt(i);
                curr.children.putIfAbsent(c, new Node());
                curr = curr.children.get(c);
            }
            curr.output.add(pat);
        }
    }

    private void buildFailureLinks() {
        Queue<Node> queue = new LinkedList<>();

        // Set failure links for depth 1 nodes to root
        for (Node child : root.children.values()) {
            child.fail = root;
            queue.add(child);
        }

        // BFS to propagate failure links and output links
        while (!queue.isEmpty()) {
            Node curr = queue.poll();

            for (Map.Entry<Character, Node> entry : curr.children.entrySet()) {
                char ch = entry.getKey();
                Node child = entry.getValue();

                Node failNode = curr.fail;
                while (failNode != null && !failNode.children.containsKey(ch)) {
                    failNode = failNode.fail;
                }

                if (failNode != null) {
                    child.fail = failNode.children.get(ch);
                } else {
                    child.fail = root;
                }

                // Merge output patterns from failure node
                child.output.addAll(child.fail.output);

                queue.add(child);
            }
        }
    }

    /**
     * Searches all pattern occurrences within the provided text.
     */
    public List<Match> search(String text) {
        List<Match> matches = new ArrayList<>();
        if (text == null || text.isEmpty()) return matches;

        Node curr = root;

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);

            while (curr != root && !curr.children.containsKey(ch)) {
                curr = curr.fail;
            }

            if (curr.children.containsKey(ch)) {
                curr = curr.children.get(ch);
            } else {
                curr = root;
            }

            for (String pattern : curr.output) {
                matches.add(new Match(i - pattern.length() + 1, pattern));
            }
        }

        return matches;
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Aho-Corasick Multi-Pattern Search Automaton\n" +
               "Time Complexity:  Trie Construction & Failure Links: O(Σ |patterns|)\n" +
               "                  Search Runtime: O(n + z) where n = |text|, z = total matches found\n" +
               "Space Complexity: O(Σ |patterns| * Alphabet Size)\n" +
               "Core Concept:     Combines a Trie with BFS-derived KMP failure transitions,\n" +
               "                  allowing simultaneous matching of an entire dictionary in one pass.";
    }
}
