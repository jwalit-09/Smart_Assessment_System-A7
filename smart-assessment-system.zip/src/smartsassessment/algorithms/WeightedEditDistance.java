package smartsassessment.algorithms;

/**
 * Weighted Edit Distance Algorithm.
 * Allows custom costs for insertion, deletion, and substitution operations.
 */
public class WeightedEditDistance {

    public static class WEDResult {
        private final int totalCost;
        private final int insertCost;
        private final int deleteCost;
        private final int substituteCost;
        private final int[][] dp;
        private final String a;
        private final String b;

        public WEDResult(int totalCost, int insertCost, int deleteCost, int substituteCost,
                         int[][] dp, String a, String b) {
            this.totalCost = totalCost;
            this.insertCost = insertCost;
            this.deleteCost = deleteCost;
            this.substituteCost = substituteCost;
            this.dp = dp;
            this.a = a;
            this.b = b;
        }

        public int getTotalCost() { return totalCost; }
        public int getInsertCost() { return insertCost; }
        public int getDeleteCost() { return deleteCost; }
        public int getSubstituteCost() { return substituteCost; }
        public int[][] getDp() { return dp; }

        public void printTable() {
            System.out.printf("\nWeighted Edit Distance Matrix (Ins=%d, Del=%d, Sub=%d):%n",
                    insertCost, deleteCost, substituteCost);
            int n = a.length();
            int m = b.length();
            System.out.print("      ε  ");
            for (int j = 0; j < m; j++) {
                System.out.printf("  %c", b.charAt(j));
            }
            System.out.println();

            for (int i = 0; i <= n; i++) {
                if (i == 0) System.out.print("  ε ");
                else System.out.printf("  %c ", a.charAt(i - 1));
                for (int j = 0; j <= m; j++) {
                    System.out.printf("%3d", dp[i][j]);
                }
                System.out.println();
            }
        }
    }

    public static WEDResult calculate(String a, String b, int insertCost, int deleteCost, int substituteCost) {
        if (a == null) a = "";
        if (b == null) b = "";

        int n = a.length();
        int m = b.length();
        int[][] dp = new int[n + 1][m + 1];

        dp[0][0] = 0;
        for (int i = 1; i <= n; i++) dp[i][0] = dp[i - 1][0] + deleteCost;
        for (int j = 1; j <= m; j++) dp[0][j] = dp[0][j - 1] + insertCost;

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    int del = dp[i - 1][j] + deleteCost;
                    int ins = dp[i][j - 1] + insertCost;
                    int sub = dp[i - 1][j - 1] + substituteCost;
                    dp[i][j] = Math.min(del, Math.min(ins, sub));
                }
            }
        }

        return new WEDResult(dp[n][m], insertCost, deleteCost, substituteCost, dp, a, b);
    }

    public static String getComplexityInfo() {
        return "Algorithm:        Weighted Edit Distance\n" +
               "Time Complexity:  O(n * m)\n" +
               "Space Complexity: O(n * m)\n" +
               "Core Concept:     Generalization of Levenshtein allowing asymmetric penalty weights\n" +
               "                  for insertions, deletions, and substitutions (e.g. OCR or spell check).";
    }
}
